# Upload the research code using your own GitHub account

You do not need to connect GitHub to ChatGPT. Sign in to your own nouman47 account at https://github.com using your normal browser. Complete GitHub account verification if GitHub itself requests it.

## 1. Create the repository

Open https://github.com/new . Select nouman47 as the owner. Enter grid-planner-selection as the repository name. Description: Audited grid planner selection experiments with measured decision costs and reproducible evidence. Select Public. Leave the optional README, .gitignore and license choices unselected because this package supplies its own README and .gitignore and does not invent a licence grant. Click Create repository. If that name is already in use, use grid-planner-selection-revision and retain the actual resulting URL.

## 2. Upload the code

Extract this ZIP on your computer. On the new repository page, select uploading an existing file (or Add file > Upload files). Open upload_these_files and drag its CONTENTS onto the upload page, including the revision_work folder. Do not upload the outer ZIP as the only code file. Enter the commit message Add audited research source and click Commit changes. The README.md and revision_work folder should appear at the repository root. The source package contains fewer than 100 files and each is below the browser file-size limit.

## 3. Send the actual repository URL back here

Copy the browser address of the created repository and send it in this chat. The repository link can then be checked and the manuscript and reviewer response updated. A profile link alone is not proof that this code has been published.

## 4. Publish the evidence release

After the public package contents are checked, open Releases in the repository and choose Create a new release (or Draft a new release). Choose Create new tag, enter revision-v3 and target the branch containing your upload. Title: Audited research revision v3. Attach the final Supplementary_Material_S1.zip using the release asset box, rather than the ordinary Add file upload. That archive is approximately 169 MB and is too large for an ordinary browser code upload. It includes the submission manuscript and reviewer-response documents in addition to the computational evidence; inspect those contents before choosing to make the complete archive public. A public evidence-only release can be prepared if you want those editorial documents kept out of the repository. Publish only the intended final assets. Do not call the evidence publicly available until the upload and release publication have completed.

## Verification

The code matches the prepared revision-v3 source tree, apart from this package README clarifying its publication status. SOURCE_MANIFEST.json lists each source file hash. Full numerical evidence remains in the final Supplementary_Material_S1.zip already supplied with the manuscript. Most original fitted model binaries are intentionally omitted as described there; twelve extension binaries and their recorded evidence are included in S1. This small code-only package does not replace S1 and does not independently include the raw data or models.

No passwords, authenticator codes or personal access tokens need to be sent in this chat. No physical robot trials or public DOI are represented as completed.

Official GitHub instructions:
https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository
