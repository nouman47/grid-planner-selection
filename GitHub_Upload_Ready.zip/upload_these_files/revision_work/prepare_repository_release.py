"""Prepare a source tree for an eventual authenticated public deposit."""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parent
DEST=ROOT/'repository_ready'
DEST.mkdir(exist_ok=True)
def copy(source,relative):
 target=DEST/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
for p in (ROOT/'project').iterdir():
 if p.is_file() and p.suffix in {'.py','.md','.txt','.json'}:copy(p,Path('revision_work/project')/p.name)
for p in (ROOT/'project/extensions_v2').iterdir():
 if p.is_file() and p.suffix in {'.py','.md','.csv'}:copy(p,Path('revision_work/project/extensions_v2')/p.name)
for p in (ROOT/'history').glob('*.py'):copy(p,Path('revision_work/history')/p.name)
for name in ['build_revision.py','build_responses.py','extend_manuscript.py','extend_responses.py','strengthen_manuscript.py','strengthen_responses.py','make_revision_figures.py','export_publication_figures.py','validate_submission.py','validate_extension_submission.py','validate_strengthened_submission.py','prepare_repository_release.py']:
 copy(ROOT/name,Path('revision_work')/name)
(DEST/'README.md').write_text('''# Grid planner selection revision

Author: Nouman Shahzad. Prepared source version: revision-v3.
Manuscript: Decision Costs and Utility Tradeoffs in Explainable Grid Planner Selection.
This folder is a repository-ready source tree, not an already published repository.
No public URL, DOI, or release date is claimed.

The project audits selection among Dijkstra, A*, Weighted A*, Bidirectional A*,
JPS and a cell-centre Theta* adaptation. The primary evidence consists of 50,580
audited searches, repeated map-disjoint learning comparisons, measured selection
costs and accepted explanation arrays. The exploratory extension adds 3,408
executed offline planning transactions and 639 closed-loop simulation episodes.
The calibrated guard switches zero times, incurs overhead, and does not establish
superiority. Its timing budget fails to transfer to isolated workers. Simulation
contains moving-obstacle collisions. There are zero physical robot observations.
The current contribution includes a retrospective exact decision-cost diagnostic
reconstructing 21,300 saved charged decisions. Physical trials are future work.

## Get the evidence

The complete Supplementary_Material_S1.zip is supplied with the revision.
An authenticated public deposit is still pending. When publishing, attach that
archive as a release asset, retain its SHA-256, and add the real release URL here.
Do not put its large binary archive in ordinary Git history.

Extract S1 into an empty working directory. Its revision_work/project contains
all maps, scenarios, complete benchmark records, splits, predictions and outputs.
This source tree uses the same paths and may be overlaid on that extracted tree.
It deliberately does not duplicate the raw evidence in Git.

## Inspect and reproduce

Use Python 3.12 and the pinned requirements. Preserve an untouched copy: fitting
and summary scripts overwrite outputs. All timing is CPU/environment specific.

```bash
cd revision_work/project
python -m pip install -r requirements-analysis.txt
python validate_planners.py
python validate_features.py
python validate_analysis_core.py
python extensions_v2/validate_extension.py
python analyse_cost_limits.py
```

For full original re-execution, follow the S1 README and the frozen
EXPERIMENT_PROTOCOL.md and ANALYSIS_PROTOCOL.md. Most original fitted binaries
are omitted; fitting sources, input/split keys, predictions and model hashes are
retained. The extension includes ten guarded models and the two seed-42 original
classifiers reconstructed to match saved probabilities.

For new extension measurements in a separate output working copy:

```bash
python extensions_v2/cost_aware.py
python extensions_v2/robot_simulation.py
python extensions_v2/robot_common_horizon.py
python extensions_v2/pipeline.py
python extensions_v2/validate_extension.py
```

Keep pipeline timing sequential and free of concurrent training, simulation or
document rendering. Supplied immutable transactions resume only with matching
source/model hashes; use a fresh result directory for an independent timed run.
See extensions_v2/S2_METHOD_AND_REPRODUCTION.md for the switching score,
conditional accepted-switch implication, negative findings and exact limitations.
The hardware procedure and empty observation schema are in extensions_v2/.

## Documents

S1 includes the supplied manuscript/reviewer sources, final documents and numeric
validation. build_revision.py builds the prior computational revision. For the
extension, retain history/pre_extension_Revised_Manuscript.docx from S1,
then run extend_manuscript.py, render the
manuscript, run extend_responses.py, render the response and run
validate_extension_submission.py. For the latest contribution framing, retain
history/pre_cost_limits_Revised_Manuscript.docx and
history/pre_strengthening_response_content.json from S1, run strengthen_manuscript.py,
render to the expected manuscript_render PDF, run strengthen_responses.py, render
the response, then run validate_strengthened_submission.py. The current Word files
include explicit physical-trial future work and computational assistance disclosure.
The final PDFs are reading copies; Word files
remain editable. Rendering requires LibreOffice/Poppler and the document runtime.

## Attribution and reuse

Contains information from the Moving AI Lab 2D Pathfinding Benchmarks,
https://movingai.com/benchmarks/grids.html, under the Open Data Commons Attribution
License v1.0 https://opendatacommons.org/licenses/by/1-0/ . Retain that attribution.
Cite Sturtevant NR (2012), Benchmarks for Grid-Based Pathfinding,
IEEE TCIAIG 4(2):144–148, https://doi.org/10.1109/TCIAIG.2012.2197681 .
The site credits BioWare for game-map research redistribution permission,
Konstantin Yakovlev and Anton Andreychuk for Street maps and Nathan Sturtevant/HOG2
for Maze maps. Original rights remain with their owners.

No software license grant is invented by this package. The rights holder must
choose the code reuse license before representing this as licensed open source.
''')
(DEST/'CITATION.cff').write_text('''cff-version: 1.2.0
message: "Please cite the accompanying revised manuscript and original benchmark sources."
type: software
title: "Grid planner selection revision"
authors:
  - family-names: Shahzad
    given-names: Nouman
version: revision-v3
abstract: "Audited planner-selection experiments with explicit cost and simulation limitations."
''')
(DEST/'.gitignore').write_text('__pycache__/\n*.pyc\n*.joblib\n*.zip\nrevision_work/project/data/\nrevision_work/project/results/\nrevision_work/project/analyses/\nrevision_work/project/extensions_v2/results/\nrevision_work/submission_revision/\n')
manifest=[{'path':str(p.relative_to(DEST)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(DEST.rglob('*')) if p.is_file() and p.name!='SOURCE_MANIFEST.json']
(DEST/'SOURCE_MANIFEST.json').write_text(json.dumps({'published':False,'files':manifest},indent=2))
print('Prepared',len(manifest),'source files; publication remains pending')
