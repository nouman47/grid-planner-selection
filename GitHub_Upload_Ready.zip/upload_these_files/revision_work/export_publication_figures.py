"""Export journal figure formats from the unchanged original vector PDFs."""
from pathlib import Path
import subprocess,json,hashlib
import fitz
from PIL import Image
ROOT=Path(__file__).resolve().parent;SRC=ROOT/'submission_revision/figures';OUT=ROOT/'submission_revision/publication_figures';OUT.mkdir(exist_ok=True)
names=['model_comparison','confidence','weight_sensitivity','shap_global','shap_local','ablations'];manifest=[]
for n,name in enumerate(names,1):
 source=SRC/(name+'.pdf');eps=OUT/f'Fig{n}.eps';tiff=OUT/f'Fig{n}.tif'
 subprocess.run(['pdftops','-eps',str(source),str(eps)],check=True,capture_output=True)
 with fitz.open(source) as doc:pix=doc[0].get_pixmap(matrix=fitz.Matrix(600/72,600/72),alpha=False)
 im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);im.save(tiff,compression='tiff_lzw',dpi=(600,600));del im,pix
 with Image.open(tiff) as check:assert check.mode=='RGB' and check.info['dpi']==(600.,600.)
 manifest.append({'figure':n,'source':source.name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'vector_eps':eps.name,'rgb_tiff':tiff.name,'tiff_dpi':600,'numerical_content_changed':False})
(OUT/'FIGURE_FORMATS.json').write_text(json.dumps(manifest,indent=2));print('Exported six vector EPS and six RGB 600 dpi TIFF files from original vector PDFs')
