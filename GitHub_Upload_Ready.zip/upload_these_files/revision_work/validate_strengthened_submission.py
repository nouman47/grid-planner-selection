"""Retain all prior numerical checks and independently audit cost-limit Table 18."""
from pathlib import Path
import json,re,hashlib
import pandas as pd,numpy as np
from docx import Document
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'submission_revision';P=ROOT/'project'
old=(ROOT/'validate_extension_submission.py').read_text().replace('len(doc.tables)==17','len(doc.tables)==18')
exec(compile(old,str(ROOT/'validate_extension_submission.py'),'exec'),{'__file__':str(ROOT/'validate_extension_submission.py'),'__name__':'__main__'})
report=json.loads((OUT/'submission_validation.json').read_text());doc=Document(OUT/'Revised_Manuscript.docx');table=doc.tables[17];KEYS=['map','start_x','start_y','goal_x','goal_y'];checks=0
models={'Extra Trees':'ExtraTrees','Logistic':'LogisticRegression','Gradient boost.':'GradientBoosting'}
for row in list(table.rows)[1:]:
 shown=[c.text for c in row.cells];policy=shown[0].lower();method=models[shown[1]];scope='cached' if shown[2]=='Cached' else 'cold';folder='selection_timing' if method=='ExtraTrees' else 'comparator_timing'
 original=pd.read_csv(P/f'analyses/{policy}/planner_utilities.csv',float_precision='round_trip')
 saved=pd.read_csv(P/f'analyses/{folder}/{policy}_42_{method}_{scope}_outcomes.csv',float_precision='round_trip')
 reference=pd.read_csv(P/f'analyses/{policy}/seed_42/TrainingSingleBest_outcomes.csv',float_precision='round_trip')[KEYS+['utility']].rename(columns={'utility':'reference_utility'})
 joined=saved[KEYS+['planner','utility','overhead_ms']].rename(columns={'utility':'charged_utility'}).merge(original[KEYS+['planner','utility','runtime_score']],on=KEYS+['planner'],validate='one_to_one').merge(reference,on=KEYS,validate='one_to_one')
 spans=original[original.success_rate>0].groupby(KEYS).runtime_ms.agg(lambda x:float(max(x)-min(x))).rename('span').reset_index();joined=joined.merge(spans,on=KEYS,how='left',validate='one_to_one').fillna({'span':0})
 advantage=joined.utility-joined.reference_utility;wins=advantage>1e-12;retained=joined.charged_utility-joined.reference_utility>1e-12;finite=wins&(joined.span>0)&(advantage<=.5*joined.runtime_score+1e-12)
 expected=[[retained.sum(),wins.sum()],[finite.sum(),np.median(2*joined.loc[finite,'span']*advantage[finite])],[np.median(joined.overhead_ms)]]
 assert len(joined)==355
 for column,values in zip([3,4,5],expected):
  numbers=[float(n) for n in re.findall(r'\d+(?:\.\d+)?',shown[column])];assert len(numbers)==len(values) and np.allclose(numbers,values,rtol=0,atol=.000501),(shown,numbers,values);checks+=1
body='\n'.join(p.text for p in doc.paragraphs);assert doc.paragraphs[0].text=='Decision Costs and Utility Tradeoffs in Explainable Grid Planner Selection'
abstract=next(doc.paragraphs[i+1].text for i,p in enumerate(doc.paragraphs) if p.text=='Abstract');assert 150<=len(abstract.split())<=250
assert '6.2 Future work and physical robot trials' in body
future=body.split('6.2 Future work and physical robot trials')[1].split('7 Conclusion')[0]
assert 'has not been performed in this study' in future and 'contain no physical observations' in future
assert 'OpenAI ChatGPT with Codex assisted' in body
assert 'public repository publication remains pending' in body
for name in ['Revised_Manuscript.docx','Response_to_Reviewers.docx']:
 assert hashlib.sha256((OUT/name).read_bytes()).hexdigest()==report['document_sha256'][name]
limits=json.loads((P/'analyses/cost_limits/validation.json').read_text());assert limits['passed'] and limits['aligned_task_decisions']==21300
for name,digest in limits['sources'].items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest
assert len(doc.tables)==18
report.update({'displayed_numeric_cells_checked':report['displayed_numeric_cells_checked']+checks,'tables_checked':report['tables_checked']+[18],'cost_limit_analysis_decisions':21300,'cost_limit_displayed_cells_independently_checked':checks,'abstract_words':len(abstract.split()),'physical_trials_explicitly_future_work':True,'AI_assistance_disclosed':True,'current_title_consistent':True})
(OUT/'submission_validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
