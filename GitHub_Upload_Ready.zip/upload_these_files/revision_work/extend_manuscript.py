"""Targeted additions to the verified manuscript; preserve earlier results."""
import copy,json,sys
from pathlib import Path
import pandas as pd
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches
ROOT=Path(__file__).parent;sys.path.insert(0,str(ROOT));import build_revision as base
OUT=ROOT/'submission_revision';E=ROOT/'project/extensions_v2/results'
def before(doc,text,fragment):
 widths={'Table 15':[.8,.8,.8,.75,1.1,1.3], 'Table 16':[.75,.55,.9,.6,.7,1.55,.65], 'Table 17':[.95,1.1,.65,.75,.7,.7,.65]}
 for caption in fragment.doc.paragraphs:
  for prefix,values in widths.items():
   if caption.text.startswith(prefix+' '):
    table=next(t for t in fragment.doc.tables if t._tbl is caption._p.getnext());table.autofit=False
    for col,w in zip(table.columns,values):col.width=Inches(w)
    for row in table.rows:
     for cell,w in zip(row.cells,values):cell.width=Inches(w)
 anchor=next(p for p in doc.paragraphs if p.text==text)
 for e in list(fragment.doc._element.body):
  if e.tag.endswith('sectPr'):continue
  anchor._p.addprevious(copy.deepcopy(e))
def main():
 assert json.loads((E/'pipeline/audit.json').read_text())['passed'];assert json.loads((E/'robot_simulation/manifest.json').read_text())['episodes_unique_validated']==639
 source=ROOT/'history/pre_extension_Revised_Manuscript.docx'
 # The materialized native file is the authoritative previously delivered version.
 if not source.exists():raise FileNotFoundError(source)
 doc=Document(source);loc=json.loads((OUT/'document_locations.json').read_text());cost=pd.read_csv(E/'cost_policy_summary.csv');coverage=pd.read_csv(E/'map_coverage.csv');pipe=pd.read_csv(E/'pipeline/summary.csv');paired=pd.read_csv(E/'pipeline/paired_intervals.csv');sim=pd.read_csv(E/'robot_simulation/summary.csv')
 a=base.Article();a.h('3.8 Additional selection and robot simulation experiments',2,key='extension_methods')
 a.p('After inspecting the corrected primary results, an explicitly exploratory extension tests whether reducing feature cost and calibrating switching margins changes the practical conclusion. It is not an independent confirmatory evaluation. Cost-sensitive portfolio selection, feature-cost handling and conformal regulation of routing/policies are established ideas [43–45]. The proposed extension contributes a portfolio-specific decision rule and its evaluation; no first-ever or fundamental-novelty claim is made.')
 a.p('Eight inexpensive descriptors use start/goal coordinates, Euclidean and Manhattan separation, and map dimensions. Seven gradient-boosted regressors predict six planner utilities and log runtime span: 100 trees each, depth 2, learning rate 0.05 and minimum leaf size 10. Within each original map partition, 20% of training maps are reserved for calibration using seed + 1,000. Proper-training mean utility selects the fixed reference. No test-set threshold or hyperparameter is tuned. The unguarded cheap-utility policy and calibrated guard share the fitted predictor.')
 a.p('A proper-training decision-cost profile defines an operational budget as the 99th percentile of per-query median cost from three calls. Predicted utility gains relative to the fixed reference are reduced by estimated runtime-score cost. Calibration measures the maximum optimistic net-gain error across all six planners and all five queries within each calibration map. The finite-sample upper map-score quantile at α = 0.1 defines the switching margin; a positive lower net-gain margin is required to switch. Otherwise the reference is executed. S1 gives the exact score, rule, assumptions and proof of the accepted-switch implication.')
 a.p('Under exchangeable map/query blocks and the operational cost-budget event, the joint map-score bound protects accepted switches. This is marginal map coverage, not coverage conditional on being selected. It is not an overall non-degradation theorem: rejected decisions still pay selector cost. The empirical cost quantile is not a deterministic latency bound, and related maps/convenience queries weaken transfer of exchangeability assumptions. Actual map coverage, budget exceedance, switching and utility are all reported.')
 a.p('A separate complete-transaction experiment executes one canonical coordinate-sorted query per primary held-out map: 71 tasks per rule. Four methods, two cache states and three repetitions yield 3,408 fresh transactions. Method/cache order is shuffled within paired task/repetition blocks. The parent timer includes child-process launch, fresh occupancy/context construction when applicable, task features, inference/routing, actual planner search, returned-path checking and result transfer. Cached Extra Trees has a prepared feature context; other cached methods have occupancy. Resident model loading and physical sensing/control are excluded. The external 10 s search budget ends at a search-completion signal; post-search validation is timed separately within the transaction. Fresh parsing does not flush OS caches. These new wall-clock observations do not replace the original benchmark labels.')
 a.p('A simulated differential-drive transfer study uses the same 71 strict held-out-map queries. A circular radius of 0.4 grid cells, conservative obstacle inflation, 0.1 s control steps, maximum forward speed 2 cells/s, turn rate 1.2 rad/s and acceleration 0.8 cells/s² define the model. Nominal tracking, independent localization noise (position SD 0.1 cells, heading SD 0.02 rad) and a fully observed moving-circle condition test three methods, producing 639 episodes. Every method/condition on a map receives the same time horizon. The moving circle follows one shared per-map trajectory anchored to the fixed-JPS reference route, with identical phase for all methods. Invalid endpoints after inflation are retained as failures. True-pose collision is evaluated at sampled motion substeps; it is not continuous-time collision certification. Existing selectors are reused on altered geometry without retraining, so this is a transfer stress test. Grid units have no calibrated physical resolution, and no hardware observation is implied.')
 before(doc,'4 Results',a);loc['sections'].update(a.sections)
 b=base.Article();b.number=14;b.h('4.9 Lightweight utility prediction and calibrated switching',2,key='extension_results')
 rows=[]
 for policy in ['strict','relaxed']:
  for method in ['CheapUtility','GuardedCheapUtility']:
   d=cost[(cost.policy==policy)&(cost.method==method)];g=coverage[coverage.policy==policy]
   rows.append([policy.title(),'Unguarded' if method=='CheapUtility' else 'Guarded',base.f(d.mean_selection_ms.mean(),3),base.f(d.switch_rate.mean()),base.f(d.utility_difference.mean()),f'{g.map_coverage.min():.3f}–{g.map_coverage.max():.3f}'])
 b.table('cost_extension','Exploratory cheap-policy results across the five original partitions',['Rule','Policy','Decision ms','Switch rate','Mean U difference','Guard map coverage'],rows)
 b.p('The calibrated guard makes no switches on any evaluated partition. Its predictions are too uncertain relative to the required margin, and fallback still incurs decision cost. The unguarded cheap policy also has a negative mean charged-utility difference from its proper-training-selected fixed reference. The coverage ranges are descriptive observed proportions, not proof that deployment maps satisfy exchangeability or that selected actions have a conditional guarantee. These results expose conservatism and decision cost; they do not resolve the practical-superiority concern by adding a favorable new method.')
 b.h('4.10 Direct complete planning transactions',2,key='pipeline_results');rows=[]
 names={'FixedJPS':'Fixed JPS','OriginalExtraTrees':'Original ET','CheapUtility':'Cheap utility','GuardedCheapUtility':'Guarded'}
 for r in pipe.itertuples():
  ci=paired[(paired.policy==r.policy)&(paired.scope==r.scope)&(paired.method==r.method)&(paired.metric=='parent_wall_ms')].iloc[0]
  rows.append([r.policy.title(),r.scope.title(),names[r.method],base.f(r.success_rate),base.f(r.mean_parent_wall_ms,2),f'{ci.difference:.2f} [{ci.ci_low:.2f}, {ci.ci_high:.2f}]',base.f(r.conditional_path_length,2)])
 b.table('pipeline_extension','Freshly executed complete planning transactions on 71 maps per rule',['Rule','Cache','Method','Success','Total ms','Total minus JPS and 95% map interval','Path cells'],rows)
 b.p('All 3,408 expected transaction keys are present. Successful returned paths pass an independent occupied-square segment audit. Total values are means of three-repetition task medians; intervals resample the same 71 maps in paired comparisons. The experiment directly executes search after selection, so its total is not formed by adding separately timed historical search medians. It nevertheless remains an offline planning transaction with resident models, process isolation and no physical sensing or control. Complete task-level stage timings, paths and paired success/path differences are supplied in S1. Numerical changes from historical timing summaries can reflect the new session, sampled cohort and broader timer boundary; they are not pooled into the original labels.')
 b.p('The calibration cost budget does not transfer to the isolated-worker timing environment. Guarded decision costs exceed their frozen parent-profile budgets in all 852 guarded transactions: 100% exceedance under both collision rules and both cache states. Mean worker decision costs range from 3.93 to 4.19 ms, against strict and relaxed budgets of 1.55 and 1.88 ms. Consequently, the cost-budget assumption needed for the accepted-switch implication is unsupported here; zero accepted switches also makes a positive-action guarantee vacuous on these observations. The policy is retained unchanged to report this limitation rather than recalibrated after seeing the test outcomes.')
 b.h('4.11 Footprint and motion constrained simulation',2,key='robot_results');rows=[]
 for r in sim.itertuples():rows.append([names[r.method],r.condition.replace('_',' '),f'{int(round(r.goal_rate_all*71))}/71',f'{int(round(r.goal_rate_eligible*r.eligible_maps))}/{int(r.eligible_maps)}',str(int(round(r.collision_rate_all*71))),str(int(r.invalid_inflated_endpoints)),str(int(r.planning_failures))])
 b.table('robot_extension','Simulated closed-loop outcomes with one common horizon per map',['Policy','Condition','Goals all','Goals eligible','Collisions','Invalid endpoints','Plan failures'],rows)
 b.p('Conservative inflation invalidates 24 of the 71 start/goal pairs; 47 remain endpoint-eligible. The guard produces the same planner choices and simulated tracking outcomes as fixed JPS. The shared moving-obstacle condition includes sampled true-pose collisions. This rejects any interpretation of the selector or braking preview as a safety certificate. Conservative inflation can remove physically feasible narrow passages, while reuse of models on altered geometry is a distribution shift. The single noise realization per map/condition, simple fully observed moving obstacle, discrete simulation and absence of sensor/hardware logs limit generalization. Final trajectories use common map horizons and one shared dynamic world; superseded route-relative simulations are excluded. These are simulation findings, not physical robot validation.')
 before(doc,'5 Discussion',b);loc['sections'].update(b.sections);loc['tables'].update(b.tables)
 replacements={
  'The experiment concerns static, fully observed, two-dimensional occupancy grids and point agents.':'The primary benchmark concerns static, fully observed, two-dimensional occupancy grids and point agents. The separate simulation adds a circular footprint and constrained closed-loop tracking but remains a simplified computational transfer test.',
  'Dynamic obstacles and localization/map uncertainty are untested.':'Dynamic obstacles and localization/map uncertainty are untested in the primary benchmark. The additional simulation tests one specified localization-noise model and a fully observed moving circle; it does not establish robustness to real sensing or dynamic scenes.',
  'Total policy runtime is reconstructed by adding measured selection to benchmark search medians.':'The initial overhead study reconstructs total policy runtime by adding measured selection to benchmark search medians. Section 4.10 separately measures complete executed planning transactions on a canonical 71-map cohort per rule.',
  'No physical robot trial, sensor-derived deployment validation or closed-loop execution result is claimed.':'No physical robot trial, sensor-derived deployment validation or physical closed-loop execution result is claimed.',
 }
 for p in doc.paragraphs:
  for old,new in replacements.items():
   if old in p.text:p.text=p.text.replace(old,new)
  if p.text.startswith('Per-instance planner selection must be assessed'):
   p.text+=' An exploratory calibrated switching extension, complete planning transactions and footprint-aware closed-loop simulations further test cost and applicability without establishing universal improvement or physical validation.'
 # Add a bounded extension statement in the discussion, retaining prior claims.
 conclusion=next(p for p in doc.paragraphs if p.text=='7 Conclusion')
 conclusion.insert_paragraph_before('The additional calibrated switching rule provides an inspectable application-specific extension, not evidence of fundamental novelty. Established feature-cost-aware selection and conformal routing precede it [43–45]. Its zero-switch result and negative decision-cost adjustment illustrate a limitation worth reporting. Complete-transaction timing closes the earlier measurement gap for the stated offline cohort; the robot simulation supplies a constrained transfer test while preserving the need for actual hardware evidence.')
 refs=[
 '43. Xu L, Hutter F, Shen J, Hoos HH, Leyton-Brown K (2012) SATzilla2012: Improved algorithm selection based on cost-sensitive classification models. In: Proceedings of SAT Challenge 2012, pp 57–58. https://www.cs.ubc.ca/labs/algorithms/Projects/SATzilla/SATzilla2012final.pdf',
 '44. Prinster D, Fannjiang C, Park JW, Cho K, Liu A, Saria S, Stanton SD (2026) Conformal policy control. In: Proceedings of the 43rd International Conference on Machine Learning. PMLR 306:99772–99824. https://proceedings.mlr.press/v306/prinster26a.html',
 '45. Uddin I, Bauer A (2026) Conformal LLM routing with distribution-free safety guarantees. In: Proceedings of the 64th Annual Meeting of the Association for Computational Linguistics, Volume 4: Student Research Workshop, pp 791–799. https://doi.org/10.18653/v1/2026.acl-srw.70']
 for text in refs:doc.add_paragraph(text).alignment=WD_ALIGN_PARAGRAPH.LEFT
 doc.save(OUT/'Revised_Manuscript.docx');(OUT/'document_locations.json').write_text(json.dumps(loc,indent=2));print('Added three results tables, simulation, policy and complete-transaction methods')

if __name__=='__main__':main()
