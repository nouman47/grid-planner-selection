"""Build the revision from audited artifacts; no numerical result is hardcoded."""
import copy,json,math,re,hashlib
from pathlib import Path
import numpy as np,pandas as pd
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).parent;PROJECT=ROOT/'project';OUT=ROOT/'submission_revision';OUT.mkdir(exist_ok=True)
SOURCE=ROOT.parent/'manuscript_line_review/Manuscript.docx'
NAMES={'dijkstra':'Dijkstra','astar':'A*','weighted_astar':'Weighted A*','bidirectional_astar':'Bidirectional A*','jps':'JPS','theta_star':'Theta*',
 'ExtraTrees':'Extra Trees','ExtraTreesBalanced':'Balanced Extra Trees','RandomForest':'Random Forest','RandomForestBalanced':'Balanced Random Forest','GradientBoosting':'Gradient Boosting','LogisticRegression':'Logistic Regression','UtilityRegression':'Utility regression','TrainingSingleBest':'Training single best','TrainingMajority':'Training majority','UniformRandomExpected':'Uniform random','VirtualBest':'Virtual best','FixedWeightedFallback_0.5':'ET with fixed fallback'}
PLANNERS=['dijkstra','astar','weighted_astar','bidirectional_astar','jps','theta_star'];SEEDS=[42,52,62,72,82]
def read(name,policy='strict'):return pd.read_csv(PROJECT/'analyses'/policy/(name+'.csv'))
def js(path):return json.loads(Path(path).read_text())
def f(value,n=4):return 'NA' if pd.isna(value) else f'{value:.{n}f}'
def mean_sd(values,n=4):return f'{np.mean(values):.{n}f} ± {np.std(values,ddof=1):.{n}f}'
def ci(row,key='mean_policy_minus_baseline'):return f"{f(row[key])} [{f(row.ci_low)}, {f(row.ci_high)}]"

class Article:
 def __init__(self):
  self.original=Document(SOURCE);self.doc=Document(SOURCE);self.tables={};self.sections={};self.number=0
  body=self.doc._element.body
  for child in list(body):
   if child.tag!=qn('w:sectPr'):body.remove(child)
  for name in ['Normal','Title','Heading 1','Heading 2','Heading 3','Table Caption','Figure Caption']:
   if name in self.doc.styles:
    style=self.doc.styles[name];style.font.color.rgb=RGBColor(0,0,0)
  normal=self.doc.styles['Normal'];normal.font.name='Times New Roman';normal.font.size=Pt(11)
  normal.paragraph_format.space_after=Pt(6);normal.paragraph_format.line_spacing=1.1
  for section in self.doc.sections:
   ln=OxmlElement('w:lnNumType');ln.set(qn('w:countBy'),'1');ln.set(qn('w:restart'),'continuous');section._sectPr.append(ln)
   for p in section.footer.paragraphs:
    p.clear();p.style=self.doc.styles['Normal'];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p._p.get_or_add_pPr().append(OxmlElement('w:suppressLineNumbers'))
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');p._p.append(field)
 def p(self,text,style=None):return self.doc.add_paragraph(str(text),style)
 def h(self,text,level=1,key=None):
  self.doc.add_heading(text,level)
  if key:self.sections[key]=text
 def old(self,index):
  element=copy.deepcopy(self.original.paragraphs[index]._p);self.doc._element.body.insert(-1,element)
 def eq(self,text,number):
  p=self.doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
  mathpara=OxmlElement('m:oMathPara');mathobj=OxmlElement('m:oMath')
  def run(parent,value):
   r=OxmlElement('m:r');t=OxmlElement('m:t');t.text=value;r.append(t);parent.append(r)
  def sub(parent,base,index):
   obj=OxmlElement('m:sSub');e=OxmlElement('m:e');run(e,base);s=OxmlElement('m:sub');run(s,index);obj.append(e);obj.append(s);parent.append(obj)
  def extrema(parent,fun,variable):
   run(parent,fun+'(');sub(parent,variable,'t');run(parent,')')
  if number in [1,2]:
   target,var=('R','T') if number==1 else ('L','D');sub(mathobj,target,'t,p');run(mathobj,' = ')
   frac=OxmlElement('m:f');num=OxmlElement('m:num');den=OxmlElement('m:den')
   extrema(num,'max',var);run(num,' − ');sub(num,var,'t,p')
   extrema(den,'max',var);run(den,' − ');extrema(den,'min',var)
   frac.append(num);frac.append(den);mathobj.append(frac)
  elif number==3:
   sub(mathobj,'U','t,p');run(mathobj,' = 0.2 ');sub(mathobj,'S','t,p');run(mathobj,' + 0.5 ');sub(mathobj,'R','t,p');run(mathobj,' + 0.3 ');sub(mathobj,'L','t,p');run(mathobj,'   (p ∈ ');sub(mathobj,'C','t');run(mathobj,')')
  else:
   sub(mathobj,'Regret','t');run(mathobj,' = ');sub(mathobj,'max','p');run(mathobj,' ');sub(mathobj,'U','t,p');run(mathobj,' − ');sub(mathobj,'U','t,selected')
  run(mathobj,f'     ({number})');mathpara.append(mathobj);p._p.append(mathpara)
 def table(self,key,title,headers,rows):
  self.number+=1;self.tables[key]=self.number
  caption=self.p(f'Table {self.number} {title}','Table Caption');caption.paragraph_format.keep_with_next=True
  table=self.doc.add_table(rows=1,cols=len(headers));table.alignment=WD_TABLE_ALIGNMENT.CENTER;table.autofit=True
  for cell,text in zip(table.rows[0].cells,headers):cell.text=str(text)
  head=table.rows[0]._tr.get_or_add_trPr();repeat=OxmlElement('w:tblHeader');head.append(repeat)
  for row in rows:
   cells=table.add_row().cells
   for cell,value in zip(cells,row):cell.text=str(value)
  for i,row in enumerate(table.rows):
   row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
   for j,cell in enumerate(row.cells):
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
    pr=cell._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
    for edge in ['top','left','bottom','right']:
     e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    pr.append(borders)
    if i==0:
     shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E7E6E6');pr.append(shade)
    for p in cell.paragraphs:
     p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(3)
     p.alignment=WD_ALIGN_PARAGRAPH.LEFT if j==0 else WD_ALIGN_PARAGRAPH.CENTER
     for run in p.runs:run.font.size=Pt(9);run.bold=i==0
  widths={'class_report':[1.3]+[.625]*8,'planning':[1.6]+[.94]*5,'paired':[.65,1.2,1,.65,2.8],'families':[.75,.7,.9,.9,.9,2.15]}.get(key)
  if widths:
   table.autofit=False
   for column,width in zip(table.columns,widths):column.width=Inches(width)
   for row in table.rows:
    for cell,width in zip(row.cells,widths):cell.width=Inches(width)
  self.p('')
 def figure(self,name,caption):
  p=self.doc.add_paragraph();p.paragraph_format.keep_with_next=True;p.alignment=WD_ALIGN_PARAGRAPH.CENTER
  p.add_run().add_picture(str(OUT/'figures'/name),width=Inches(6.1));self.p(caption,'Figure Caption')

def methods(a):
 a.h('3 Experimental methods',key='methods')
 a.h('3.1 Benchmark and collision geometry',2,key='geometry')
 a.p('The revised experiments use the same 1,405 retained start–goal tasks on 281 Moving AI maps [26, 40], with five queries per map. The complete scenario file is supplied so the task selection can be reproduced. These queries represent a fixed convenience benchmark; neither the map families nor the task-distance strata are probability samples of real robot deployments. Map identity, family and the supplied difficulty tag are evaluation metadata and never classifier inputs.')
 frame=pd.read_csv(PROJECT/'data/features_strict.csv');rows=[]
 for family,g in frame.groupby('family'):rows.append([family.upper() if family=='dao' else family.title(),g['map'].nunique(),len(g)])
 a.table('dataset','Benchmark composition',['Family','Maps','Tasks'],rows+[['Total',281,1405]])
 a.p('Coordinates are zero-based (column, row), with the origin at the upper left; arrays use [row, column]. Free cells are vertices at cell centres. Orthogonal steps cost 1 and diagonal steps cost √2. The primary strict rule permits a diagonal only when both adjoining orthogonal cells are free, matching the no-corner-cutting convention of the benchmark format. A separate relaxed analysis permits a diagonal whenever its destination is free. All source maps in this cohort contain only free ground and blocked/tree cells; no terrain-dependent traversal cost is inferred.')
 a.p('Any-angle visibility is checked between cell centres against occupied unit squares. Strict visibility excludes contact with blocked-cell boundaries or corners; relaxed visibility excludes penetration of blocked interiors but permits point contact at corners. These are point-agent geometries. The cell-centre Basic Theta* adaptation should not be conflated with a vertex-based configuration-space planner for a finite robot [13, 14].')
 a.h('3.2 Planner implementation and independent validation',2,key='validation')
 a.p('The six implementations share occupancy and path-validation conventions. Dijkstra is implemented as zero-heuristic search; A* and Weighted A* use Euclidean goal distance, with heuristic weight 1.5 for Weighted A*. Bidirectional A* uses balanced consistent Euclidean potentials and an incumbent/lower-bound stopping rule. JPS uses directional pruning and jump scans, rather than ordinary neighbour expansion under a different name [11, 12, 41]. Theta* uses line-of-sight parent relaxation and the Euclidean length of each relaxed segment. All implementations are Python implementations; their relative timings do not establish rankings among optimized C++ libraries.')
 a.p('Correction of the submitted implementation was necessary before reanalysis. The historical runner interpreted a returned result dictionary as a path, which produced invalid success flags and the constant path length 5.00. The JPS, Theta* and bidirectional implementations also required correction. No historical planner outcomes, labels, trained models or explanation arrays are used in the revised numerical results. The correction history and frozen source hashes accompany the reproducibility archive.')
 a.p('Before full execution, 14,748 planner searches and 11,988 independent line-of-sight checks passed exhaustive small-grid and randomized tests; a 72-run real-map pilot passed an independent shortest-path and segment audit. The full benchmark contains 1,405 tasks × 6 planners × 2 collision rules × 3 repetitions = 50,580 searches. Planner order is shuffled within each task using seed 20261030. Searches run sequentially in isolated child processes with an externally enforced 10 s budget. Worker setup is reported separately. A timeout is censored at 10,000 ms and is not a proof that no path exists; a no-path result requires termination without a route.')
 a.p('Search timing starts after map/worker setup and stops when the raw search result is available; returned-path verification is outside that timer. The parent deadline conservatively includes result transfer. Each result retains its path, status, success, geometric length and source/configuration identity. Completed records are published atomically. The independent full audit verifies complete task keys, map/source hashes, reachability and exact discrete shortest-path costs using separately constructed SciPy sparse graphs, and Theta* segments using a separate slab-intersection calculation. Tests are finite empirical checks, not a general proof of every implementation property.')
 a.h('3.3 Features and task alignment',2,key='features')
 a.p('There is exactly one feature row per complete map/start/goal key. Nineteen descriptors are available before search. Navigation features are start and goal coordinates, Euclidean distance and Manhattan distance (six). Environment features are map width and height, free-space ratio, obstacle density, and start/goal clearance and local density (eight). Topology features are map area, aspect ratio, free-cell count, start-component ratio and mean orthogonal free-cell degree (five).')
 a.p('Local density uses a radius-five square window (11 × 11 cells), with the exterior treated as occupied. Clearance is Euclidean distance to the nearest blocked-cell centre, including a blocked exterior ring. The start-component ratio is the start component divided by all free cells: four-connectivity is used for strict movement and eight-connectivity for relaxed movement. Mean free degree counts orthogonal free/free edges only, including in the relaxed analysis. Width, height and occupancy describe the map; coordinates, clearance, neighbourhood and component values are joined separately for each query. Free-space ratio and obstacle density sum to one and are intentionally tested for redundancy.')
 a.h('3.4 Utility labels and failure handling',2,key='utility')
 a.p('For task t and planner p, S is the fraction of three repetitions returning a validated path; T is median budget-capped search runtime; and D is the common geometric path length conditional on success. Successful repetitions of these deterministic planners must agree in D. The successful-candidate set C contains planners with at least one successful repetition. Runtime and path scores are inverse min–max normalizations within C. When all values of a component coincide, that component equals one. Planners outside C receive zero utility; failed runs never receive an artificial zero-length reward.')
 a.eq('Rₜ,ₚ = [max(Tₜ) − Tₜ,ₚ] / [max(Tₜ) − min(Tₜ)]',1)
 a.eq('Lₜ,ₚ = [max(Dₜ) − Dₜ,ₚ] / [max(Dₜ) − min(Dₜ)]',2)
 a.eq('Uₜ,ₚ = 0.2 Sₜ,ₚ + 0.5 Rₜ,ₚ + 0.3 Lₜ,ₚ   for p in Cₜ; otherwise Uₜ,ₚ = 0',3)
 a.p('The weights specify a runtime-oriented preference with a smaller reward for path quality and empirical reliability; they are not universal safety requirements or empirically optimized constants. The label is the maximum-utility successful candidate, breaking ties by lower runtime, shorter path and then the fixed portfolio order Dijkstra, A*, Weighted A*, Bidirectional A*, JPS, Theta*. All-failure tasks have no class label but remain in planning evaluation with utility and oracle utility zero. The virtual-best oracle maximizes this same utility separately on every test task; regret is its utility minus the policy utility, not a classification error rate.')
 a.eq('Regretₜ = maxₚ Uₜ,ₚ − Uₜ,selected',4)
 a.p('A prespecified grid varies success weight from 0 to 0.4 in steps of 0.1 and runtime weight from 0 to the remaining mass in steps of 0.1; path weight is the remainder. The 45 settings include the original weights. On seed 42, test maps remain fixed while the same Extra Trees configuration is refitted on training maps for each weighting. We report preferred-label agreement over label-valid tasks and held-out regret for both retaining the default model and retraining. This is preference sensitivity over that grid, not evidence for weights outside it.')
 a.h('3.5 Models and map-disjoint evaluation',2,key='models')
 a.p('Seeds 42, 52, 62, 72 and 82 define GroupShuffleSplit partitions with 25% of maps held out. Every split has 210 training maps (1,050 tasks) and 71 test maps (355 tasks). The same map lists are used by every classifier, utility regressor, feature ablation and collision-policy comparison. All maps are split before all-failure tasks are excluded from classifier fitting/scoring. Model inputs contain only the 19 feature columns. No test outcome is used to tune a model, calibration parameter or operating threshold. Extra Trees is the primary classifier specified before inspecting corrected test results; it is not selected because it has the largest test score.')
 a.table('config','Learning configurations used on every map partition',['Model','Configuration'],[
 ['Logistic Regression','Standard scaling; maximum 5,000 iterations; default regularization'],['Random Forest and Extra Trees','500 trees; square-root feature sampling; one CPU thread'],['Balanced forest variants','Same configuration; class_weight = balanced'],['Gradient Boosting','Scikit-learn default configuration; recorded seed'],['Utility regression','500-tree Extra Trees regressor; six utility outputs; square-root feature sampling']])
 a.p('Class weighting is estimated only from training labels. Utility regression learns all six per-task utility values, including all-failure training tasks, and selects the largest predicted utility. The comparison also includes all six fixed planners, the training-majority class, a single-best planner selected by mean training utility, exact expected uniform-random selection and the virtual-best oracle. The random baseline averages planner outcomes analytically; it does not rely on a favorable random draw.')
 a.h('3.6 Confidence calibration and statistical analysis',2,key='confidence')
 a.p('Confidence is maximum predicted class probability. Selective accuracy is evaluated only among retained label-valid cases, with the accepted count and denominator reported; empty acceptance has undefined accuracy. Fixed Weighted A* fallback replaces predictions below τ = 0.5, while thresholds 0.5–0.9 are diagnostic settings. Whole-policy accuracy and planning outcomes include the fallback decisions and are distinct from selective accuracy. No best test-set threshold is chosen. The earlier rule-based adaptive fallback is not reported as the fixed fallback.')
 a.p('Temperature scaling [37] is fitted on a map-disjoint calibration subset comprising 20% of training maps. A separate Extra Trees model is fitted on the remaining proper-training maps. A positive scalar temperature, bounded between 0.05 and 20, minimizes calibration negative log likelihood. Raw and temperature-transformed probabilities from that same model are compared on untouched test maps. This avoids attributing a change in training sample size to calibration. Calibration is not assumed to improve accuracy, planning utility or safety.')
 a.p('Classification results include accuracy, fixed-six-class macro-F1, per-class support/precision/recall, confusion matrices, multiclass Brier score and 10-bin equal-width ECE. Macro-F1 assigns zero to a class with zero precision/recall, including an absent preferred-planner class; a supported-class macro-F1 is supplied separately. Planning results include success frequency, mean capped-median runtime, path length conditional on success, utility and regret. Conditional path summaries are weighted by success frequency; paired path differences use tasks on which both policies have some successful repetition, so their denominator can differ from the full test set.')
 a.p('Ninety-five-percent percentile intervals use 1,000 bootstrap resamples of whole maps. Paired policy differences use the same tasks, and paired classifier differences use the same map resamples and per-map confusion matrices. These intervals account for within-map correlation. Results averaged over the five overlapping map partitions are descriptive means and sample standard deviations; they are not five independent geographical replications. Multiple comparisons are reported descriptively without uncorrected significance claims.')
 a.h('3.7 Direct selection overhead and explanations',2,key='timing')
 a.p('For every split-specific held-out query, three direct measurements time task-feature extraction, vector construction, probability inference and the decision rule. These measurements use raw maps and per-query features, not repeated planner CSV rows. Map parsing and global-feature preparation are timed separately. Cached selection assumes those arrays already exist; the cold-feature charge adds the measured median map-preparation cost. Models are already loaded and operating-system disk caches are not flushed. Thus cold-feature timing is not cold-disk or model-startup latency.')
 a.p('The initial timing study covers the primary Extra Trees model and its proper-training calibration model (21,300 measurements). It charges measured median per-query selection overhead to the corresponding benchmark search runtime and reduces the runtime utility component using the original task normalization, clipped to [0,1]. A tied runtime component becomes zero when positive overhead is charged. The charged total is a reconstruction from directly measured selection and benchmark-search components, not a live sensor-to-actuator navigation test. A separately identified exploratory extension times the already fitted Logistic Regression and Gradient Boosting comparators; it does not change the primary model or fit new hyperparameters.')
 a.p('SHAP explanations [33, 34, 42] use the saved primary models and one canonical query per held-out map: 71 cases per split, 710 split-specific cases in total. Backgrounds contain 25 training queries sampled with the split seed. Permutation SHAP calls the model probabilities directly with max_evals = 390 per query. An exact-equality invariant mask evaluates small genuine feature changes rather than treating nearly equal values as identical. Every explanation must reconstruct its predicted probabilities within 10⁻⁹. The initial TreeExplainer and default-invariance attempts failed this external gate and are excluded.')
 a.p('Global importance averages absolute attributions across explained cases and six output classes. Split-to-split Spearman correlations and top-five Jaccard overlap describe ranking stability; signed local explanations retain task identity, feature values, baseline probabilities and class outputs. Spearman feature correlations and occupancy-removal ablations assess redundancy. A small repeat check holds the model/background fixed and varies permutation seeds on one canonical case per family. Exact additivity does not prove Monte Carlo convergence, and independent masking of correlated descriptors can create unrealistic feature combinations. Attributions describe the classifier, not causal map effects or planner guarantees.')

def results(a):
 a.h('4 Results',key='results')
 a.h('4.1 Benchmark integrity and preferred-planner support',2,key='integrity_results')
 audit=js(PROJECT/'results/full_v2/audit.json');runs=pd.read_csv(PROJECT/'results/full_v2/audited_runs.csv')
 a.p(f"The complete audit passed with {audit['records']:,} unique expected records, no missing keys, no duplicates and no recorded validation errors. It checked {audit['segments_checked']:,} path segments and {audit['independent_oracle_tasks_with_policy']:,} task/collision-rule reference distances. Table {a.number+1} separates solved, no-path and timeout statuses. Success therefore is not assumed to equal one, and path length is a geometric quantity rather than a dictionary size.")
 status=[]
 for policy,g in runs.groupby('policy'):
  lengths=g.loc[g.success.astype(bool),'path_length']
  status.append([policy.title(),int((g.status=='solved').sum()),int((g.status=='no_path').sum()),int((g.status=='timeout').sum()),f'{lengths.min():.2f}–{lengths.max():.2f}'])
 a.table('integrity','Validated full-benchmark outcomes',['Rule','Solved','No path','Timeout','Successful length range'],status)
 a.p('The length unit is one grid-cell width. A no-path task can have a short search runtime without being a successful navigation outcome. All six policies are retained in the comparison even when they are never the preferred label. Dijkstra has zero preferred-label examples under the strict rule and one under the relaxed rule; neither primary test partition contains a Dijkstra label. Its zero primary-test class score must therefore be interpreted alongside support.')
 rows=[]
 for planner in PLANNERS:
  row=[NAMES[planner]]
  for policy in ['strict','relaxed']:
   labels=read('task_labels',policy);s=js(PROJECT/'analyses'/policy/'seed_42/split.json')
   row.extend([int((labels.best_planner==planner).sum()),s['train_label_counts'][planner],s['test_label_counts'][planner]])
  rows.append(row)
 for key,name in [('all_failure_tasks','All failure')]:
  row=[name]
  for policy in ['strict','relaxed']:
   s=js(PROJECT/'analyses'/policy/'seed_42/split.json');d=js(PROJECT/'analyses'/policy/'utility_diagnostics.json')
   row.extend([d[key],s['train_tasks']-s['train_valid_labels'],s['test_tasks']-s['test_valid_labels']])
  rows.append(row)
 a.table('support','Preferred-label counts and primary partition support',['Label','Strict all','Strict train','Strict test','Relaxed all','Relaxed train','Relaxed test'],rows)
 a.p('All-failure tasks are excluded only from classification. The primary strict classifier is scored on 340 label-valid test tasks, whereas planning policies are compared on all 355 tasks. The relaxed denominators are 341 and 355. These differing denominators are retained throughout the tables. Class imbalance is substantial, and a six-class accuracy alone does not summarize minority-class performance.')
 a.h('4.2 Fair model comparison and class imbalance',2,key='model_results')
 rows=[]
 for model in ['LogisticRegression','RandomForest','ExtraTrees','GradientBoosting','ExtraTreesBalanced','RandomForestBalanced','UtilityRegression']:
  row=[NAMES[model]]
  for policy in ['strict','relaxed']:
   g=read('model_comparison',policy);g=g[g.model==model];row.extend([mean_sd(g.accuracy),mean_sd(g.macro_f1)])
  rows.append(row)
 a.table('models','Classification across five identical map-disjoint partitions',['Model','Strict accuracy','Strict macro-F1','Relaxed accuracy','Relaxed macro-F1'],rows)
 m=read('model_comparison');primary=m[(m.seed==42)&(m.model=='ExtraTrees')].iloc[0]
 a.p(f"On the primary strict split, Extra Trees achieved accuracy {f(primary.accuracy)} (map-bootstrap 95% interval {f(primary.accuracy_ci_low)}–{f(primary.accuracy_ci_high)}) and fixed-six-class macro-F1 {f(primary.macro_f1)} ({f(primary.macro_f1_ci_low)}–{f(primary.macro_f1_ci_high)}). Figure 1 shows that no classifier dominates every metric. Class weighting and utility regression change the error distribution, but class weighting does not establish uniform minority-class improvement. All per-class reports, paired model-difference intervals and supported-class macro-F1 values are supplied in Supplementary Material S1.")
 a.figure('model_comparison.png','Fig. 1 Model comparison under identical map-disjoint partitions. Points are five-split means; error bars are sample standard deviations across overlapping partitions, not independent-sample confidence intervals. Macro-F1 averages all six fixed portfolio classes.')
 rows=[]
 for planner in PLANNERS:
  row=[NAMES[planner]]
  for policy in ['strict','relaxed']:
   report=pd.read_csv(PROJECT/'analyses'/policy/'seed_42/ExtraTrees_classification.csv',index_col=0).loc[planner]
   row.extend([int(report.support),f(report.precision,3),f(report.recall,3),f(report['f1-score'],3)])
  rows.append(row)
 a.table('class_report','Primary Extra Trees class performance',['Planner','Strict n','P','R','F1','Relaxed n','P','R','F1'],rows)
 a.p('P denotes precision and R recall. Scores are zero when their denominator is undefined under the declared zero-division convention. Rare A* and Bidirectional A* labels remain difficult. Their small support limits conclusions about population-level recall, even when a class-weighted model changes the aggregate macro-F1. Resampling cannot create evidence for Dijkstra under the strict rule, where no preferred-label examples exist.')
 a.h('4.3 Planning outcomes and paired fixed-planner comparisons',2,key='planning_results')
 names=['Fixed_'+n for n in PLANNERS]+['ExtraTrees','LogisticRegression','GradientBoosting','UtilityRegression','FixedWeightedFallback_0.5','TrainingSingleBest','TrainingMajority','UniformRandomExpected','VirtualBest']
 rows=[]
 d=read('planning_only_policy_comparison')
 for name in names:
  r=d[(d.seed==42)&(d.method==name)].iloc[0]
  label=NAMES.get(name,NAMES.get(name.removeprefix('Fixed_'),name))
  rows.append([label,f(r.success_rate),f(r.mean_capped_median_runtime_ms,2),f(r.conditional_mean_path_length,2),f(r.mean_utility),f(r.mean_oracle_regret)])
 a.table('planning','Primary strict planning-only comparison on 355 common test tasks',['Method','Success','Time ms','Path length','Utility','Regret'],rows)
 et=d[(d.seed==42)&(d.method=='ExtraTrees')].iloc[0];base=d[(d.seed==42)&(d.method=='TrainingSingleBest')].iloc[0];oracle=d[(d.seed==42)&(d.method=='VirtualBest')].iloc[0]
 a.p(f"The primary Extra Trees policy has utility {f(et.mean_utility)} and regret {f(et.mean_oracle_regret)}, compared with {f(base.mean_utility)} for training-selected JPS and {f(oracle.mean_utility)} for the virtual-best oracle. It does not reproduce the oracle: its runtime is {f(et.mean_capped_median_runtime_ms,2)} ms versus {f(base.mean_capped_median_runtime_ms,2)} ms for JPS, and its success frequency is {f(et.success_rate)} versus {f(base.success_rate)}. The former zero-regret interpretation is withdrawn. Utility regret and label error are different quantities, but both are now computed from the same task-keyed test decisions.")
 rows=[]
 for policy in ['strict','relaxed']:
  paired=read('paired_cluster_comparisons',policy)
  for method in ['ExtraTrees','FixedWeightedFallback_0.5']:
   for metric in ['runtime_ms','path_length','utility','success_rate']:
    r=paired[(paired.seed==42)&(paired.method==method)&(paired.metric==metric)].iloc[0]
    rows.append([policy.title(),NAMES[method],metric.replace('_',' '),int(r.paired_tasks),ci(r)])
 a.table('paired','Primary paired differences from training-selected single best',['Rule','Policy','Metric','Paired n','Difference and 95% map interval'],rows)
 a.p('Positive differences favor the selector for utility and success; negative differences favor it for runtime and path length. Path-length differences use the paired-success subset, whereas the conditional mean path lengths in the preceding table can use different success sets. The two summaries answer different questions. Utility improves before overhead in some settings without a corresponding speed or success improvement. The uncertainty intervals and direct overhead results therefore qualify practical claims.')
 a.h('4.4 Generalization across map families',2,key='family_results')
 family=read('family_policy_comparison');charged=pd.read_csv(PROJECT/'analyses/additional_statistics/charged_family_comparisons.csv');rows=[]
 for policy in ['strict','relaxed']:
  d=read('family_policy_comparison',policy)
  for fam in ['dao','maze','street']:
   r=d[(d.seed==42)&(d.method=='ExtraTrees')&(d.family==fam)].iloc[0];b=d[(d.seed==42)&(d.method=='TrainingSingleBest')&(d.family==fam)].iloc[0]
   c=charged[(charged.policy==policy)&(charged.seed==42)&(charged.method=='ExtraTrees')&(charged.scope=='cached')&(charged.family==fam)&(charged.metric=='utility')].iloc[0]
   rows.append([policy.title(),fam.upper() if fam=='dao' else fam.title(),f'{int(r.maps)}/{int(r.tasks)}',f(r.mean_utility),f(b.mean_utility),ci(c,'difference')])
 a.table('families','Primary family utility and the cached overhead adjustment',['Rule','Family','Maps/tasks','ET planning U','Fixed planning U','Cached ET minus fixed U and 95% interval'],rows)
 a.p('Family results do not show a uniform advantage. The primary strict maze decisions coincide with the fixed JPS policy before overhead, so selection adds cost without changing those routes. Street-map utility can favor a learned preference for shorter any-angle routes while search latency increases. DAO tasks include many short, inexpensive searches for which even modest selection cost matters. Supplementary family tables report classification, support, success, runtime and path outcomes on every split. Holding out map filenames tests new-map transfer within these families; it does not demonstrate transfer to an unseen map family or a new physical environment. Related city/map variants may occur on opposite sides of a filename-based split.')
 a.h('4.5 Confidence filtering, fallback and calibration',2,key='fallback_results')
 rows=[]
 for policy in ['strict','relaxed']:
  curve=pd.read_csv(PROJECT/'analyses'/policy/'seed_42/selective_risk_coverage.csv');fallback=read('fixed_fallback_whole_policy',policy);policies=read('planning_only_policy_comparison',policy)
  for threshold in [.5,.6,.7,.8,.9]:
   r=curve[np.isclose(curve.threshold,threshold)].iloc[0];w=fallback[(fallback.seed==42)&np.isclose(fallback.threshold,threshold)].iloc[0];u=policies[(policies.seed==42)&(policies.method=='FixedWeightedFallback_'+str(threshold))].iloc[0]
   rows.append([policy.title(),f(threshold,1),f'{int(r.n_accepted)}/{int(r.n_total)}',f(r.coverage),f(r.selective_accuracy),f(w.whole_policy_accuracy),f(u.mean_utility)])
 a.table('confidence','Selective metrics and separately scored fixed fallback',['Rule','τ','Accepted/valid','Coverage','Selective acc','Whole-policy acc','Fallback U'],rows)
 a.p('Coverage and selective accuracy in this table refer only to label-valid cases. Whole-policy classification scores use all label-valid decisions after fallback; planning utility uses all 355 tasks, including all-failure tasks. Figure 2 shows the same retained-case calculation as the selective columns. The corrected curves generally reduce error as coverage decreases, with some local non-monotonicity and small accepted sets. The submitted Table 9 had instead mixed fallback-applied accuracy with selective-accuracy terminology, which created the apparent contradiction.')
 a.figure('confidence.png','Fig. 2 Primary-split reliability and selective risk–coverage curves. Reliability points summarize nonempty confidence bins; marker size reflects bin count. Risk is the error fraction among accepted label-valid tasks, not the accuracy of a fallback-applied policy. No empty acceptance set is plotted as zero risk.')
 rows=[]
 for policy in ['strict','relaxed']:
  d=read('temperature_calibration',policy)
  for method in ['ProperTrainRaw','ProperTrainTemperature']:
   g=d[d.method==method];rows.append([policy.title(),'Raw proper-training' if method=='ProperTrainRaw' else 'Temperature scaled',mean_sd(g.ece),mean_sd(g.brier),mean_sd(g.accuracy)])
 a.table('calibration','Controlled temperature-scaling comparison',['Rule','Same fitted model','ECE','Brier score','Accuracy'],rows)
 a.p('Temperature scaling is evaluated against the raw probabilities of the identical proper-training model. It is a calibration experiment, not a second claim of classifier superiority. A positive scalar transformation preserves the probability argmax but can alter which cases cross the fallback threshold. The saved outputs report those resulting planning policies as well as probability scores. A probability threshold is not a certificate of collision avoidance, task solvability or bounded navigation risk.')
 a.h('4.6 Sensitivity to utility preferences',2,key='weight_results')
 rows=[]
 for policy in ['strict','relaxed']:
  d=read('weight_sensitivity',policy)
  rows.append([policy.title(),f'{d.valid_label_agreement_with_default.min():.3f}–{d.valid_label_agreement_with_default.max():.3f}',f'{d.default_model_mean_regret.min():.4f}–{d.default_model_mean_regret.max():.4f}',f'{d.retrained_mean_regret.min():.4f}–{d.retrained_mean_regret.max():.4f}'])
 a.table('weights','Range across the 45 utility settings',['Rule','Label agreement','Default-model regret','Retrained-model regret'],rows)
 a.p('Preferred labels are sensitive to the optimization preference. Retaining a runtime-oriented default classifier for a path-dominated objective can incur substantial regret, whereas retraining reduces regret on the same held-out maps. This result supports declaring weights as application preferences and retraining when those preferences change; it does not support presenting 0.2/0.5/0.3 as a universal robotics objective. Figure 3 shows the deterioration when the default model is kept unchanged. Per-setting intervals and label agreements are supplied in S1.')
 a.figure('weight_sensitivity.png','Fig. 3 Seed-42 sensitivity of default-model utility regret to the success and runtime weights; path weight is the remaining mass. White cells lie outside the nonnegative weight simplex. These are planning-only diagnostics on the fixed held-out maps.')
 a.h('4.7 Measured overhead and practical trade-offs',2,key='overhead_results')
 timing=pd.concat([pd.read_csv(PROJECT/'analyses'/source/'charged_policy_summary.csv') for source in ['selection_timing','comparator_timing']],ignore_index=True);rows=[]
 for policy in ['strict','relaxed']:
  for method in ['ExtraTrees','LogisticRegression','GradientBoosting']:
   cached=timing[(timing.policy==policy)&(timing.method==method)&(timing.scope=='cached')];cold=timing[(timing.policy==policy)&(timing.method==method)&(timing.scope=='cold')]
   rows.append([policy.title(),NAMES[method],f(cached.mean_selection_ms.mean(),3),f(cold.mean_selection_ms.mean(),3),f(cached.mean_utility.mean()),f(cold.mean_utility.mean())])
 a.table('overhead','Selection overhead and charged policy utility',['Rule','Model','Cached ms','Cold-feature ms','Cached U','Cold-feature U'],rows)
 a.p('Timing values are five-split means of per-query median selection costs. The two stages contain 42,600 directly measured query/model/repetition records in total. A recording interruption was recovered by measuring only missing keys; existing per-map setup medians and query measurements were retained. Model loading and scientific explanation are outside the selection timer. The fixed-planner reference includes search only; cold-feature charging additionally includes parsing within feature preparation and is therefore a conservative extra charge rather than a matched cold-start application benchmark.')
 a.p('Charging overhead changes the interpretation of the primary Extra Trees results: average utility can fall below the training-selected fixed planner, even when planning-only utility is larger. The exploratory cheaper-model comparison isolates the contribution of selector implementation cost without promoting a test-selected model to the primary method. Runtime, path quality and utility must be considered jointly; no universal computational-efficiency, reliability or oracle-equivalence claim is supported. Paired charged differences and family-level intervals are provided in S1.')
 g=charged[(charged.method=='GradientBoosting')&(charged.scope=='cached')&(charged.family=='street')&(charged.metric=='utility')]
 ranges=[]
 for policy in ['strict','relaxed']:
  x=g[g.policy==policy];ranges.append(f"{policy} {x.difference.min():.4f}–{x.difference.max():.4f}")
 a.p('One bounded exploratory condition is cached Gradient Boosting on Street maps: its utility-difference point estimates relative to the training-selected fixed planner are positive on all five partitions under both collision rules ('+'; '.join(ranges)+'). Several map-bootstrap intervals include zero, however, and the family/model comparison was exploratory. This is a candidate cost–quality operating condition, not confirmatory evidence of consistent population-level superiority or a reason to replace the prespecified primary model.')
 a.h('4.8 Explanation stability and feature redundancy',2,key='explanation_results')
 stable=pd.read_csv(PROJECT/'analyses/shap/ranking_stability.csv');repeat=pd.read_csv(PROJECT/'analyses/shap/small_cohort_permutation_repeat_check.csv');rows=[]
 for policy in ['strict','relaxed']:
  g=stable[stable.policy==policy];r=repeat[repeat.policy==policy]
  rows.append([policy.title(),f'{g.spearman_rho.min():.3f}–{g.spearman_rho.max():.3f}',f'{g.top5_jaccard.min():.3f}–{g.top5_jaccard.max():.3f}',f'{r.rank_spearman.min():.3f}–{r.rank_spearman.max():.3f}'])
 a.table('shap','Descriptive attribution-ranking stability',['Rule','Across-split Spearman','Top-five Jaccard','Small-cohort repeat Spearman'],rows)
 a.p('Figure 4 summarizes the corrected global importance. Distance and mean orthogonal free degree are prominent, rather than reproducing the historical transition-complexity claim from a different feature pipeline. Occupancy and free-cell descriptors remain correlated; ranking them separately does not establish independent mechanisms. Across-split variation includes changes in training maps, test cohorts, backgrounds and permutation sampling. The repeat check isolates only a small part of sampling variability and is not a convergence guarantee for all attributions.')
 a.figure('shap_global.png','Fig. 4 Corrected global permutation-SHAP importance. Bars average absolute probability contributions over 71 cases and six classes within each split, then over five splits. Error bars describe split standard deviations; only the ten largest mean importances are shown.')
 a.figure('shap_local.png','Fig. 5 Signed local probability explanations for canonical DAO, Maze and Street cases on strict seed 42. The six largest absolute contributions are shown individually and all remaining contributions are summed. These explain the raw classifier preference; the DAO example has confidence below 0.5 and would activate the fixed fallback. Task keys, feature values and all class contributions are supplied in S1.')
 a.p('Feature-group and occupancy-redundancy ablations are shown in Figure 6. Removing one occupancy variable leaves its complement available, while map area and free-cell count retain related information. These comparisons therefore assess the fitted representation, not the causal effect of physical map changes. The supplementary correlation matrices make these dependencies explicit.')
 a.figure('ablations.png','Fig. 6 Extra Trees feature-group and redundancy ablations using identical train/test keys and the same 500-tree configuration. Points and error bars are five-split means and sample standard deviations. The full feature group has 19 descriptors; occupancy removals are explicitly named.')

def discussion(a):
 a.h('5 Discussion',key='discussion')
 a.h('5.1 Contribution relative to established selection methods',2,key='novelty')
 a.p('Rice’s mapping from instance features to algorithm performance [16], later meta-learning and selection surveys [17, 18, 20], and the ASlib benchmark methodology [19] already establish the central selection problem and strong single-best/oracle comparisons. Extra Trees [27], probability thresholds, calibration [37] and SHAP [33, 34] are also established techniques. The contribution here is an audited empirical evaluation of their combination for a particular grid-planner portfolio: complete path validation, controlled collision/budget comparisons, identical held-out-map model comparisons, explicit failure-aware utility and measured decision costs. It is not a fundamentally new search algorithm or selection-learning mechanism.')
 a.p('The comparative experiments delimit what that integration achieves. Balanced learning, utility regression, feature ablations and cheaper classifiers provide tests of alternative explanations for observed performance. They also prevent an unsupported attribution of all performance differences to Extra Trees or to explainability. The correction of the original oracle comparison is consequential: a selector with nonzero class error can have small utility regret, but it cannot be assigned zero regret by interpreting malformed path/success fields or by using an unverified model producer.')
 a.h('5.2 Conditions under which selection is useful',2,key='benefit')
 a.p('The data support a cost–quality trade-off rather than consistent computational superiority. JPS is a strong training-selected fixed reference. A learned policy can prefer a shorter any-angle route, but Theta* visibility checks can make that preference slower. On inexpensive tasks, the 500-tree selection cost is large relative to the planner differences used in within-task normalization. Cached, cheaper classifiers preserve more of the planning-only utility difference, whereas newly preparing map features can remove it. The primary paired comparisons and their intervals do not establish a universal deployment advantage, and the primary cheaper-model utility intervals can include zero.')
 a.p('Practical use therefore depends on the optimization preference, the available map-feature cache, the implementation’s per-decision cost and the task distribution. A system whose only objective is low search latency should consider the strong direct fixed planner rather than incur selection cost automatically. A system willing to spend additional time for path quality can inspect the reported paired path and utility differences. Success rate and realized geometry must remain visible, because a favorable average utility does not certify a collision-free route for a finite robot or successful execution.')
 a.h('5.3 Confidence and interpretability',2)
 a.p('Confidence filtering and fixed fallback are different policies. The corrected retained-case curves improve substantially as coverage falls, while fallback can change the class distribution and planning choices in a different direction. Neither ECE nor macro-F1 alone determines operational usefulness. Temperature scaling modifies probabilities on a separate calibration split and is assessed with the same base model; its planning consequences are reported separately. This preserves an empirical rather than prescriptive interpretation of confidence.')
 a.p('The explanation analysis now traces model probabilities to specific task features with verified additivity. Stable high-level rankings across splits can coexist with substantial redundancy and task-level changes in signed attribution. The observed distance/orthogonal-degree pattern and the occupancy ablations are properties of this fitted representation. They should guide model inspection, not be treated as proof that physically changing one correlated map descriptor would cause the attributed response.')
 a.h('6 Limitations and practical applicability',key='limitations')
 a.p('The experiment concerns static, fully observed, two-dimensional occupancy grids and point agents. Strict corner checking prevents a particular point-path geometry error; it does not account for vehicle width, swept volume, orientation, curvature, acceleration, wheel slip or tracking error. A finite robot would require footprint inflation or configuration-space collision checking and a motion-feasibility layer. The portfolio and its labels would then need rebenchmarking under that geometry, rather than assuming the current preferences transfer unchanged [1–3, 13, 14].')
 a.p('Dynamic obstacles and localization/map uncertainty are untested. A physical system needs sensing, state estimation, safety margins, replanning and a local controller, together with failure recovery. The 10 s search cap standardizes this computational experiment; it is not a hard real-time navigation deadline or a guarantee of meeting a robot’s control period. Budget-capped medians conceal the natural completion time of censored searches, so the timeout counts and empirical success frequencies are essential. No physical robot trial, sensor-derived deployment validation or closed-loop execution result is claimed.')
 a.p('The task collection contains five retained queries per map and only three benchmark families. Filename-disjoint testing does not ensure that city variants or related maze generators are independent, nor does it establish leave-one-family-out or geographical transfer. The map-level intervals account for queries sharing a map, but not every higher-level correlation. The five partitions overlap, the primary sensitivity analysis uses one partition and the class distribution is sparse. Dijkstra has zero strict and only one relaxed preferred-label example; rare populated classes cannot support strong class-specific conclusions.')
 a.p('The latency results are specific to the recorded Linux cloud CPU environment and these Python implementations. Search timing excludes common map/worker setup and post-search path validation. Selection timing excludes model loading and uses operating-system caches; the conservative cold-feature charge includes parsing. Total policy runtime is reconstructed by adding measured selection to benchmark search medians. This is more informative than timing repeated CSV rows, but it is not a live end-to-end robot benchmark. Optimized libraries, different hardware, learned features or a different portfolio can change both planner and selector costs.')
 a.p('Utility uses empirical success frequency and within-task min–max normalization. The normalization is sensitive to close planner runtimes and to portfolio membership; charging even a small cost can change normalized utility sharply. The success weight is not a safety constraint, and changing preferences can substantially relabel the data. SHAP uses a limited background and finite permutation sampling; correlated-feature masking can generate unrealistic combinations, and the small repeat check does not prove attribution convergence. All these restrictions are reflected in the conclusions rather than presented as completed real-world validation.')
 a.h('7 Conclusion',key='conclusion')
 m=read('model_comparison');primary=m[(m.seed==42)&(m.model=='ExtraTrees')].iloc[0]
 a.p(f"This study evaluates an explainable per-instance selector for six grid-based planners using corrected, independently audited measurements. All 50,580 searches are accounted for under strict and relaxed collision rules with a common 10 s budget and three repetitions. On the primary strict map partition, Extra Trees achieves accuracy {f(primary.accuracy)} and six-class macro-F1 {f(primary.macro_f1)}. The selector has nonzero utility regret and does not match the oracle. Planning-only utility gains can be accompanied by slower searches and can disappear when selection and map-feature costs are charged. Cheaper comparator models expose a different cost–quality trade-off without establishing universal superiority. Confidence, fallback and calibration are evaluated as distinct decisions, and signed SHAP explanations pass a direct probability-additivity check. The resulting evidence supports careful, application-specific assessment of planner portfolios; it does not establish a new search mechanism, a safety guarantee or readiness for physical robot deployment.")

def front_and_related(a):
 for i in range(8):a.old(i)
 a.doc.add_page_break();a.h('Abstract')
 m=read('model_comparison');et=m[m.model=='ExtraTrees'];rel=read('model_comparison','relaxed');rel=rel[rel.model=='ExtraTrees']
 a.p(f"Per-instance planner selection must be assessed by realized planning outcomes and decision cost, rather than classification accuracy alone. We evaluate an explainable selection framework for Dijkstra, A*, Weighted A*, Bidirectional A*, Jump Point Search and a cell-centre Theta* adaptation on 1,405 fixed tasks from 281 Moving AI maps. Corrected implementations produce 50,580 searches under two collision rules, three repetitions and an external 10 s budget. An independent audit checks complete task coverage, discrete optimality and 21,058,724 path segments. Logistic Regression, Random Forest, Extra Trees, Gradient Boosting, class-weighted forests and utility regression use identical map-disjoint partitions. Extra Trees attains five-split accuracy {mean_sd(et.accuracy)} and six-class macro-F1 {mean_sd(et.macro_f1)} under strict collision checking. The selector has nonzero oracle regret; higher planning-only utility does not consistently imply lower runtime or greater reliability. Direct unique-query timing shows that feature and inference costs can remove its utility advantage, while cheaper classifiers retain a different cost–quality trade-off. Forty-five utility settings demonstrate substantial preference sensitivity. Selective prediction, fixed fallback and held-out-map temperature scaling are scored separately. Permutation-SHAP explanations on 710 held-out cases pass probability-additivity checks and show correlated, partly stable feature influences. The contribution is a reproducible empirical assessment with explicit failure handling and scope limits, not a new search algorithm or evidence of physical robot readiness.")
 a.old(11)
 for i in range(12,19):a.old(i)
 a.p('The study asks whether a learned pre-search choice improves task-level utility over direct planner use after evaluation maps, collision conventions, failures and decision costs are controlled. The analysis retains negative outcomes, compares alternative classifiers and reports the circumstances in which selection cost outweighs its planning-only benefit. A physical navigation claim requires additional evidence beyond this computational setting.')
 a.h('1.1 Contributions',2)
 a.p('The contributions are an independently validated six-planner benchmark with controlled geometry and budgets; a task-aligned, failure-aware utility protocol; fair classifier, class-weighting and utility-regression comparisons on repeated map-disjoint partitions; direct confidence/fallback and selection-cost analyses; and reproducible local/global explanations with ranking and redundancy checks. These are empirical and evaluation contributions built from established planning, algorithm-selection and explainability methods.')
 for i in range(22,32):
  if i==27:
   a.p('The primary selector in this work is based on extremely randomized trees [27]. Tree ensembles model nonlinear interactions without feature scaling, but their decision cost must be measured against the available planning benefit. Random forests [28], gradient boosting [29], and scalable boosted trees such as XGBoost [30] provide related alternatives. Standard treatments of statistical learning clarify why linear models and tree ensembles behave differently under correlated, nonlinear descriptors [31, 32].')
  else:a.old(i)
 a.p('Existing algorithm-selection frameworks already provide instance-to-algorithm mappings and single-best/oracle comparisons [16–20]. The question addressed here is the reliability and practical cost of applying that methodology to this grid-planner portfolio. A useful assessment must align query features with validated paths, retain failed and censored searches, prevent map overlap, distinguish selective and fallback metrics, and charge the cost of the decision layer. The revised experiments test those requirements jointly without claiming that combining established components creates a fundamental new algorithm.')

def declarations_and_references(a):
 a.h('Statements and Declarations')
 for i in [167,168,169,170,171,172]:a.old(i)
 a.h('Data availability',2)
 a.p('Source occupancy maps are available from the Moving AI 2D Pathfinding Benchmarks (https://movingai.com/benchmarks/grids.html). The complete retained query list, corrected per-run results, returned paths, feature tables, split lists and derived analysis outputs accompany this revision in Supplementary Material S1. Map attribution and the applicable Moving AI data-licence notice are included in the reproducibility instructions.')
 a.h('Code availability',2)
 a.p('Supplementary Material S1 contains planner and validation implementations, feature and utility code, training/calibration scripts, direct timing and explanation code, document/figure generation scripts, dependency versions and reproducibility commands. Input/source/model hashes and the correction/recovery records are retained. A public repository URL is not claimed because no repository has yet been released; the supplied archive permits inspection without relying on a future deposit.')
 a.h('References')
 replacements={12:'12. Harabor D, Grastien A (2014) Improving jump point search. In: Proceedings of the International Conference on Automated Planning and Scheduling 24(1):128–135. https://doi.org/10.1609/icaps.v24i1.13633',14:'14. Nash A, Koenig S (2013) Any-angle path planning. AI Mag 34(4):85–107. https://doi.org/10.1609/aimag.v34i4.2512'}
 for i in range(178,218):
  text=a.original.paragraphs[i].text;n=int(text.split('.')[0]);text=replacements.get(n,text)
  if n==19:text=text.replace('Bischl M,','Bischl B,')
  p=a.p(text);p.alignment=WD_ALIGN_PARAGRAPH.LEFT
 a.p('41. Harabor D, Grastien A (2012) The JPS pathfinding system. In: Proceedings of the International Symposium on Combinatorial Search 3(1):207–208. https://doi.org/10.1609/socs.v3i1.18254').alignment=WD_ALIGN_PARAGRAPH.LEFT
 a.p('42. SHAP developers (2026) PermutationExplainer documentation. https://shap.readthedocs.io/en/latest/generated/shap.PermutationExplainer.html Accessed 31 October 2026').alignment=WD_ALIGN_PARAGRAPH.LEFT

def main():
 for path in [PROJECT/'results/full_v2/audit.json',PROJECT/'analyses/shap/manifest.json',PROJECT/'analyses/selection_timing/manifest.json',PROJECT/'analyses/comparator_timing/manifest.json']:
  data=js(path);assert data.get('passed',data.get('completed',False)),path
 a=Article();front_and_related(a);methods(a);results(a);discussion(a);declarations_and_references(a)
 for p in a.doc.paragraphs:
  if p.style.name.startswith('Heading') or p.style.name=='Title':
   for run in p.runs:run.font.color.rgb=RGBColor(0,0,0)
 path=OUT/'Revised_Manuscript.docx';a.doc.save(path)
 (OUT/'document_locations.json').write_text(json.dumps({'tables':a.tables,'sections':a.sections},indent=2))
 (OUT/'manuscript_table_cells.json').write_text(json.dumps([[[c.text for c in row.cells] for row in table.rows] for table in a.doc.tables],indent=2))
 print('Created',path,'tables',len(a.doc.tables),'paragraphs',len(a.doc.paragraphs))

if __name__=='__main__':main()

