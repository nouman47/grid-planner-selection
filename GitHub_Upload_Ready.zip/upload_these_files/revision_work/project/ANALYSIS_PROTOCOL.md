# Analysis definitions fixed before the completed benchmark is inspected

Model fitting is blocked until audit_benchmark.py verifies complete expected
coverage, graph reachability/optimality, returned path geometry and provenance.
The audit uses an independently constructed sparse graph and SciPy shortest
paths, rather than treating one of the evaluated planners as infallible.

## Repetitions and utility

For each task, planner and collision policy, runtime is the median of three
budget-capped search observations. A timeout contributes the 10-second cap;
it is not treated as an observed natural completion time. Success is the fraction
of repetitions returning a validated path. Path cost is conditional on success
and must agree across successful repetitions for these deterministic planners.

Utility uses weights 0.2 success, 0.5 runtime and 0.3 path cost. Runtime and path
components are inversely normalized among candidates with at least one successful
repetition. A planner with no success receives zero utility; failed runs never
receive a shorter-path reward. Equal-valued components map to one, with these
degeneracies reported. Ties use lower runtime, then shorter path and fixed
planner order. An all-failure task has no classification label, but remains in
the planning-outcome evaluation. This is explicitly different from the invalid
historical success/path fields.

## Models and held-out maps

Seeds 42,52,62,72,82 define 25-percent map-disjoint test partitions. Split all
281 maps before excluding all-failure tasks from classification. Save all map
lists and task keys. There is one feature row per task, never one duplicate row
per planner. Only the 19 named preplanning features enter the models.

Compare Logistic Regression, Random Forest, Extra Trees and Gradient Boosting
on identical partitions. Additionally evaluate balanced-class RF/Extra Trees
and an established multi-output utility-regression comparator. Model settings
are fixed; none is chosen or tuned using the held-out test scores. Extra Trees
is the prespecified primary classifier, not automatically declared the winner.
Record if any model requires a constant-label fallback due to one-class training.

Report accuracy, six-class macro-F1, per-class reports, confusion matrices and
DAO/Street/Maze results. Map-cluster bootstrap intervals resample entire maps,
not repeated planner records or individual correlated queries. The five split
summaries are descriptive; they are not five independent samples of geography.

## Planning policies

Use the same held-out tasks for all policies. Report every fixed planner, the
training-selected single-best planner, training-majority label, an exact uniform
random expected baseline, learned choices and the virtual-best oracle. All-failure
tasks have zero oracle utility and are reported, not hidden by dropping them.

For each policy report success frequency, mean budget-capped median runtime,
path cost conditional on success, utility and nonnegative oracle regret. Paired
differences against the training-selected single-best planner include map-cluster
intervals. Path differences use only pairs with successful outcomes and state
their denominator. A fast failure is not presented as successful navigation.

The first policy tables are explicitly planning-only. Direct per-task feature
and inference profiling must subsequently charge the selector's overhead and
state map-cache assumptions. They cannot be presented as end-to-end deployment
results until that step is complete.

## Confidence and calibration

Selective accuracy scores only accepted predictions; coverage includes its
explicit denominator and empty acceptance yields an undefined accuracy. Fixed
Weighted A* fallback instead scores every decision after replacing low-confidence
choices. Export these as separate tables. Never combine their headings/values.

Thresholds 0.5 through 0.9 are prespecified diagnostic policies; no best threshold
is selected by looking at the test results. For calibration, split training maps
into proper-training and calibration subsets, fit a positive scalar temperature
using calibration labels, and evaluate once on the untouched test maps. Compare
the raw and temperature-transformed probabilities of the same inner model;
do not attribute differences from a larger full-training model to calibration.

## Sensitivity and remaining gates

Feature-group and occupancy-redundancy ablations use identical task/map splits.
The primary seed-42 weight analysis uses 45 prespecified nonnegative weightings,
keeps test maps fixed, reports label agreement and policy regret, and compares
keeping the default model with refitting for each preference on training maps.

SHAP must be recomputed from the corrected model and unique task rows, including
split-to-split ranking stability and representative signed local explanations.
SHAP dependency setup remains outstanding. External literature checks and the
new manuscript/response letter also remain outstanding. Passing small unit tests
is not end-to-end validation of the final analyses; numerical tables are released
only after their data and execution gates pass.
