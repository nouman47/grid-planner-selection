"""Explain overhead losses using exact limits under the declared utility."""
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
from analysis_core import KEYS,cluster_interval
TOL=1e-12
def loss(cost,span,score):
 return .5*np.where(span>0,np.minimum(cost/np.maximum(span,1e-30),score),score*(cost>0))
def main():
 out=ROOT/'analyses/cost_limits';out.mkdir(exist_ok=True);summaries=[];caseframes=[];families=[];max_error=0.
 for policy in ['strict','relaxed']:
  utilities=pd.read_csv(ROOT/f'analyses/{policy}/planner_utilities.csv',float_precision='round_trip')
  ranges=utilities[utilities.success_rate>0].groupby(KEYS).runtime_ms.agg(lambda x:x.max()-x.min()).rename('runtime_span_ms').reset_index()
  for seed in [42,52,62,72,82]:
   reference=pd.read_csv(ROOT/f'analyses/{policy}/seed_{seed}/TrainingSingleBest_outcomes.csv',float_precision='round_trip')[KEYS+['planner','utility']].rename(columns={'planner':'reference_planner','utility':'reference_utility'})
   for method in ['ExtraTrees','LogisticRegression','GradientBoosting']:
    folder='selection_timing' if method=='ExtraTrees' else 'comparator_timing'
    for scope in ['cached','cold']:
     saved=pd.read_csv(ROOT/f'analyses/{folder}/{policy}_{seed}_{method}_{scope}_outcomes.csv',float_precision='round_trip')
     data=saved[KEYS+['planner','overhead_ms','utility']].rename(columns={'utility':'saved_charged_utility'}).merge(utilities[KEYS+['planner','utility','runtime_score','success_rate','family']],on=KEYS+['planner'],validate='one_to_one').merge(reference,on=KEYS,validate='one_to_one').merge(ranges,on=KEYS,how='left',validate='one_to_one').fillna({'runtime_span_ms':0})
     assert len(data)==355 and not data.duplicated(KEYS).any()
     c=data.overhead_ms.to_numpy();span=data.runtime_span_ms.to_numpy();r=data.runtime_score.to_numpy();d=(data.utility-data.reference_utility).to_numpy();charged=data.utility.to_numpy()-loss(c,span,r)
     error=float(np.max(np.abs(charged-data.saved_charged_utility)));max_error=max(max_error,error);assert error<5e-12
     positive=d>TOL;finite=positive&(span>0)&(d<=.5*r+TOL);limit=np.where(finite,2*span*d,np.nan);survives=charged-data.reference_utility.to_numpy()>TOL
     predicted=positive & ((d>.5*r+TOL)|((span>0)&(c<2*span*d-TOL))|((span==0)&(c==0)))
     assert np.array_equal(predicted,survives)
     assert not (survives&~positive).any()
     data=data.assign(policy=policy,seed=seed,method=method,scope=scope,planning_gain=d,charged_gain=charged-data.reference_utility,planning_win=positive,retained_win=survives,finite_cost_limit_ms=limit,utility_saturation_positive_floor=positive&(d>.5*r+TOL),tied_runtime_span=span==0)
     caseframes.append(data)
     retain=np.where(positive,survives.astype(float),np.nan);point,lo,hi=cluster_interval(retain,data['map'],1000,42)
     summaries.append({'policy':policy,'seed':seed,'method':method,'scope':scope,'tasks':len(data),'planning_wins':int(positive.sum()),'retained_wins':int(survives.sum()),'lost_wins':int((positive&~survives).sum()),'retention_among_planning_wins':point,'retention_ci_low':lo,'retention_ci_high':hi,'finite_limits':int(finite.sum()),'median_finite_cost_limit_ms':float(np.nanmedian(limit)) if finite.any() else np.nan,'median_actual_decision_ms':float(np.median(c)),'positive_saturated_floor_tasks':int((positive&(d>.5*r+TOL)).sum()),'mean_charged_difference':float((charged-data.reference_utility).mean())})
     for family,g in data.groupby('family'):
      families.append({'policy':policy,'seed':seed,'method':method,'scope':scope,'family':family,'tasks':len(g),'planning_wins':int(g.planning_win.sum()),'retained_wins':int(g.retained_win.sum()),'lost_wins':int((g.planning_win&~g.retained_win).sum())})
 # Boundary fixtures cover finite limits, clipped saturation and the tie discontinuity.
 assert np.isclose(.1-loss(np.array([2.]),np.array([10.]),np.array([.8]))[0],0)
 assert .1-loss(np.array([1.]),np.array([10.]),np.array([.8]))[0]>0
 assert .1-loss(np.array([3.]),np.array([10.]),np.array([.8]))[0]<0
 assert .5-loss(np.array([1e6]),np.array([10.]),np.array([.4]))[0]>0
 assert loss(np.array([0.]),np.array([0.]),np.array([1.]))[0]==0
 assert loss(np.array([1e-6]),np.array([0.]),np.array([1.]))[0]==.5
 summary=pd.DataFrame(summaries);cases=pd.concat(caseframes,ignore_index=True);assert len(cases)==21300
 summary.to_csv(out/'summary.csv',index=False);cases.to_csv(out/'task_diagnostics.csv',index=False);pd.DataFrame(families).to_csv(out/'family_counts.csv',index=False)
 report={'passed':True,'retrospective_diagnostic':True,'settings':len(summary),'aligned_task_decisions':len(cases),'original_charged_utilities_reconstructed':True,'maximum_absolute_utility_error':max_error,'analytic_cost_limit_predictions_match_all_saved_outcomes':True,'boundary_fixtures_passed':True,'test_tuning':False,'sources':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['analyse_cost_limits.py','COST_LIMIT_PROTOCOL.md','analysis_core.py']}}
 (out/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));print(summary[summary.seed==42].to_string(index=False))
if __name__=='__main__':main()
