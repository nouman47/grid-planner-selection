"""Re-execute saved simulated routes with one identical horizon per map."""
import sys,json,shutil,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import pandas as pd,numpy as np
from robot_simulation import ROOT,DEST,Grid,track,VMAX

def main():
 out=DEST/'robot_simulation';pilot=DEST/'robot_simulation_initial_horizon'
 if not pilot.exists():shutil.copytree(out,pilot)
 plans=[json.loads(line) for line in (pilot/'plans.jsonl').read_text().splitlines()];old=pd.read_csv(pilot/'episodes.csv');records=[]
 for name,g in old.groupby('map',sort=True):
  original=Grid.load(ROOT/'data/maps'/name,True);mapplans=[r for r in plans if r['map']==name];successful=[r['path_length'] for r in mapplans if r['success']]
  horizon=min(3600.,max(60.,3*max(successful)/VMAX+30)) if successful else 60.
  reference=next((p['path'] for p in mapplans if p['method']=='FixedJPS' and p['success']),None)
  reference_hash=hashlib.sha256(json.dumps(reference).encode()).hexdigest() if reference is not None else None
  for r in g.to_dict('records'):
   task={k:r[k] for k in ['map','start_x','start_y','goal_x','goal_y']};method=r['method'];condition=r['condition']
   if r['status']=='invalid_inflated_endpoint':records.append({**task,'method':method,'condition':condition,'status':r['status'],'goal_reached':False,'collision':False});continue
   plan=next(p for p in mapplans if p['method']==method)
   if not plan['success']:records.append({**task,'method':method,'condition':condition,'status':'planning_'+plan['status'],'goal_reached':False,'collision':False});continue
   assert reference is not None,'A common dynamic reference is required for every executed map'
   seed=int(hashlib.sha256(name.encode()).hexdigest()[:8],16)+20261101;result=track(original,plan['path'],condition,seed,horizon,reference)
   records.append({**task,'method':method,'condition':condition,'planner':plan['planner'],'dynamic_reference_path_sha256':reference_hash,'status':'goal' if result['goal_reached'] else ('collision' if result['collision'] else 'simulation_timeout'),**result})
  print('Common-horizon simulation',name,len(records),flush=True)
 with (out/'records.jsonl').open('w') as f:
  for r in records:f.write(json.dumps(r)+'\n')
 frame=pd.DataFrame([{k:v for k,v in r.items() if k!='trace'} for r in records]);assert len(frame)==639 and not frame.duplicated(['map','method','condition']).any();frame.to_csv(out/'episodes.csv',index=False);summary=[]
 for (method,condition),g in frame.groupby(['method','condition']):
  eligible=g[g.status!='invalid_inflated_endpoint'];summary.append({'method':method,'condition':condition,'maps_all':len(g),'eligible_maps':len(eligible),'goal_rate_all':g.goal_reached.mean(),'goal_rate_eligible':eligible.goal_reached.mean() if len(eligible) else np.nan,'collision_rate_all':g.collision.mean(),'planning_failures':int(g.status.str.startswith('planning_').sum()),'tracking_timeouts':int((g.status=='simulation_timeout').sum()),'invalid_inflated_endpoints':int((g.status=='invalid_inflated_endpoint').sum()),'mean_simulated_time_completed_s':g.loc[g.goal_reached,'simulated_elapsed_s'].mean()})
 pd.DataFrame(summary).to_csv(out/'summary.csv',index=False);manifest=json.loads((out/'manifest.json').read_text());manifest.update({'common_horizon':'Identical per-map horizon for all methods/conditions, min(3600,max(60,3*maximum successful route length/VMAX+30)); simulated seconds','horizon_correction':'Initial route-scaled horizon could differ by method; pilot retained separately, all controller trajectories regenerated under a common horizon; no new planner fitting or choice','dynamic_collision_correction':'Ground-truth moving-obstacle position evaluated at each checked motion substep rather than frozen at control-step start; initial controller retained as robot_simulation_before_dynamic_substeps.py','controller_source_sha256':hashlib.sha256((Path(__file__).parent/'robot_simulation.py').read_bytes()).hexdigest(),'common_horizon_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'episodes_unique_validated':639});(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
 manifest.update({'dynamic_obstacle':'One identical per-map simulated circle trajectory for all methods, anchored at the saved fixed-JPS reference-route midpoint, same sinusoidal motion and phase in simulated time','shared_world_correction':'Prior route-relative obstacle positions differed across methods; those outputs are superseded lineage. All final controllers were rerun with the fixed-JPS reference trajectory and common horizons, without retuning models or controller parameters.'});(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
 print('All 639 final simulation episodes regenerated under common horizons and shared dynamic worlds',flush=True)

if __name__=='__main__':main()
