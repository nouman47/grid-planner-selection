# Simulation design corrections and final output identity

These experiments are exploratory. No controller/model parameters were tuned to
obtain favorable goal or collision rates. The final outputs are exclusively
results/robot_simulation/, regenerated from the saved footprint-inflated plans.

Three corrections were made during review:

1. Different route lengths initially gave different controller deadlines. Every
   method/condition now uses the same per-map horizon, derived from the maximum
   saved successful route length. robot_simulation_initial_horizon/ is lineage.
2. Moving-obstacle position was initially frozen at the beginning of a collision
   check step. The final controller evaluates it at each sampled motion substep.
3. A route-relative obstacle gave different worlds to different policies. The
   final dynamic world is anchored to the saved fixed-JPS path for that map and
   has the same motion, phase and reference-path hash for every method. All controller trials with valid plans were rerun and all 639 episode records regenerated; robot_simulation_route_relative/ outputs are superseded lineage.

The last correction fixes comparative fairness; it does not add physical evidence.
Each executed episode logs the shared reference hash. validate_extension.py
reconstructs it from the saved fixed-JPS plan and checks common map horizons,
record identity and logged motion bounds. Prior controller/common-horizon source
snapshots retain their explicitly named before-correction identities. Initial
simulation records are not combined with final outcomes or counted as extra trials.

All worlds remain discrete, simplified computational scenarios in grid units.
True-pose collisions are checked at two sampled substeps, not certified for all
continuous times. The original learned selectors are reused after footprint
inflation without retraining. There is one seeded noise realization per map and
condition. Neither successful tracking nor any conditional switching statement
establishes physical robot readiness or collision safety.
