# Additional experiments and the switching bound

This is an exploratory extension to already inspected benchmark evidence. It
does not certify fundamental novelty, universal improvement or physical safety.
SATzilla2012 explicitly models feature costs and uses backups; conformal policy
control and conformal routing also precede this work. The specific contribution
is an evaluated application to this grid portfolio, with joint map-block
calibration, measured decision costs and a fresh complete-transaction comparison.

## Rule and accepted-switch implication

For query t and planner p, let U(t,p,o) be the original declared utility when
selection cost o is charged to the runtime component. It is nonincreasing in o.
Let b be the fixed planner selected on proper-training maps. Define true net gain
g(t,p,o) = U(t,p,o) − U(t,b,0), and a fitted predicted net gain ghat(t,p).
The decision-cost budget o* is an empirical proper-training timing quantile.

For calibration map j, define Z_j as the maximum of
ghat(t,p) − g(t,p,o*) over all six planners and the five fixed queries on that
map. With n calibration maps, q is the k-th smallest Z, where
k = ceil((n+1)(1−alpha)); q is infinite if k > n. Here n=42, alpha=.1, k=39.
Choose the planner with largest ghat only if its ghat−q is positive; otherwise
choose b. Seven depth-two gradient-boosted regressors and eight cheap features
define the fitted predictor; the protocol fixes all parameters before new-policy
test evaluation. The unguarded comparator executes its largest predicted utility.

Conditional on a fixed proper-training fit and exchangeable calibration/new map
blocks with the same query construction, standard split-conformal rank symmetry
gives P(Z_new <= q) >= 1−alpha. On that joint event, every candidate lower
margin is valid simultaneously. Therefore, for an accepted switch and realized
cost o <= o*,

    g(t,p,o) >= g(t,p,o*) >= ghat(t,p) − q > 0.

This is the accepted-switch implication, obtained by the score definition and
monotonicity. It is not a fundamentally new conformal theorem. The probability
statement is marginal over new map blocks, not conditional on selection. Without
a proven timing bound, a union-bound error statement also requires an additional
term for P(o > o*); that probability is not guaranteed by a CPU timing quantile.
Related city maps and convenience queries limit deployment exchangeability.

If the rule rejects, it still pays decision cost before running b. Thus its total
utility can be below direct fixed-planner use. In particular, zero acceptance
does not imply free fallback or overall non-degradation. Actual guarded results
have zero switches on all evaluated splits, and the observed utility adjustment
is negative. The added method does not establish consistent superiority.

## Timing portability

Proper-training profiling uses calls in the resident parent process. Complete
transactions run selection in fresh forked workers with resident inherited
models. Actual worker decision times can exceed the profiled budget. The
`pipeline/budget_portability.csv` file reports that difference explicitly; the
bound must not be interpreted as an operational guarantee when its budget event
fails. We retain the original frozen policy rather than refitting the budget
after inspecting this test experiment.

## Complete transaction and simulation reproduction

From the project directory, after installing the recorded dependencies:

```bash
python extensions_v2/cost_aware.py
python extensions_v2/robot_simulation.py
python extensions_v2/robot_common_horizon.py
python extensions_v2/pipeline.py
python extensions_v2/validate_extension.py
```

Use a fresh output working copy when collecting new timed observations. Preserve
the supplied results before rerunning; fitting scripts overwrite their named
outputs. Pipeline records are atomic/resumable and require matching protocol and
model hashes. Do not collect timed transactions while training, simulating or
rendering documents. Model timings are environment-specific.

The final simulation output is `results/robot_simulation/`. The initial horizon
pilot is retained separately as lineage and excluded from reported science.
All final trajectories are regenerated under one common horizon and one shared moving-obstacle world per map, and
moving-obstacle positions are checked at each recorded collision substep.
The simulation is discrete and has no metric map calibration or actual sensor
logs. It is a transfer stress test of existing models, not hardware validation.
The physical-trial template is empty. See HARDWARE_TRIALS.md for real collection.

Primary related sources:

- Xu et al. (2012), SATzilla2012. https://www.cs.ubc.ca/labs/algorithms/Projects/SATzilla/SATzilla2012final.pdf
- Prinster et al. (2026), Conformal Policy Control. https://proceedings.mlr.press/v306/prinster26a.html
- Uddin and Bauer (2026), Conformal LLM Routing with Distribution-Free Safety Guarantees. https://aclanthology.org/2026.acl-srw.70/

See SIMULATION_CORRECTIONS.md for the complete design correction lineage. The superseded route-relative outcomes are not final results. The shared trajectory is anchored to the fixed-JPS reference path and independently checked by its per-map hash.
