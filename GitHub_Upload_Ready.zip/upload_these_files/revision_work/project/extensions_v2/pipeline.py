"""Execute and time entire planning transactions, saving every returned path."""
import sys,json,time,hashlib,os,multiprocessing as mp,random,platform
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));sys.path.insert(0,str(Path(__file__).resolve().parent))
import joblib,numpy as np,pandas as pd
from planners import Grid,search,path_length
from features import MapFeatures,FEATURES
from analysis_core import KEYS,PLANNERS,cluster_interval
from audit_benchmark import segment_clear,independent_map
from cost_aware import vector,decide,ROOT,DEST

METHODS=['FixedJPS','OriginalExtraTrees','CheapUtility','GuardedCheapUtility']
def atomic(path,data):
 temp=path.with_suffix('.tmp')
 with temp.open('w') as f:json.dump(data,f,allow_nan=False);f.flush();os.fsync(f.fileno())
 temp.replace(path)
def worker(pipe,task,policy,method,scope,cached,context,models):
 try:
  begin=time.perf_counter_ns();strict=policy=='strict';load0=begin
  if scope=='fresh':
   if method=='OriginalExtraTrees':context=MapFeatures(ROOT/'data/maps'/task['map'],strict);grid=context.grid
   else:grid=Grid.load(ROOT/'data/maps'/task['map'],strict)
  else:grid=cached
  load1=time.perf_counter_ns();f0=load1
  if method=='OriginalExtraTrees':data,_=context.extract(task);x=np.array([[data[n] for n in FEATURES]],float)
  elif method!='FixedJPS':x=vector(task,grid.blocked.shape[1],grid.blocked.shape[0])
  f1=time.perf_counter_ns()
  if method=='OriginalExtraTrees':model=models['et'];p=model.predict_proba(x)[0];planner=PLANNERS[int(model.classes_[p.argmax()])]
  elif method=='FixedJPS':planner='jps'
  else:choice,_,_=decide(models['guard'],x,method=='GuardedCheapUtility');planner=PLANNERS[int(choice[0])]
  d1=time.perf_counter_ns();meta={'planner':planner,'load_context_ms':(load1-load0)/1e6,'task_features_ms':(f1-f0)/1e6,'inference_decision_ms':(d1-f1)/1e6}
  pipe.send({'phase':'search_start','started_ns':time.monotonic_ns(),'meta':meta})
  s0=time.perf_counter_ns();result=search(planner,grid,tuple(int(task[k]) for k in KEYS[1:3]),tuple(int(task[k]) for k in KEYS[3:5]));s1=time.perf_counter_ns()
  pipe.send({'phase':'search_complete','runtime_ms':result['runtime_ms']})
  errors=[];path=result['path']
  if result['success']:
   if tuple(path[0])!=tuple(int(task[k]) for k in KEYS[1:3]) or tuple(path[-1])!=tuple(int(task[k]) for k in KEYS[3:5]):errors.append('endpoints')
   if abs(path_length(path)-result['path_length'])>1e-7:errors.append('length')
   if any(not grid.visible(a,b) for a,b in zip(path,path[1:])):errors.append('collision')
  end=time.perf_counter_ns();pipe.send({'phase':'complete','result':result,'meta':{**meta,'search_wall_ms':(s1-s0)/1e6,'validation_ms':(end-s1)/1e6,'worker_wall_ms':(end-begin)/1e6,'validation_errors':errors}})
 except BaseException as exc:pipe.send({'phase':'fatal','error':repr(exc)})
 finally:pipe.close()
def transaction(*args):
 context=mp.get_context('fork');parent,child=context.Pipe(False);proc=context.Process(target=worker,args=(child,*args));begin=time.perf_counter_ns();proc.start();child.close();meta={}
 try:
  if not parent.poll(30):raise RuntimeError('Pre-search stage deadline')
  first=parent.recv()
  if first.get('phase')!='search_start':raise RuntimeError(first)
  meta=first['meta'];remaining=max(0.,10-(time.monotonic_ns()-first['started_ns'])/1e9)
  if parent.poll(remaining):
   msg=parent.recv()
   if msg.get('phase')!='search_complete':raise RuntimeError(msg)
   if msg['runtime_ms']>10000:result={'success':False,'status':'timeout','path':[],'path_length':None,'runtime_ms':10000.}
   else:
    if not parent.poll(30):raise RuntimeError('Post-search validation/transfer deadline')
    msg=parent.recv()
    if msg.get('phase')!='complete':raise RuntimeError(msg)
    result=msg['result'];meta=msg['meta']
  else:result={'success':False,'status':'timeout','path':[],'path_length':None,'runtime_ms':10000.}
  end=time.perf_counter_ns()
  return {**result,**meta,'parent_wall_ms':(end-begin)/1e6,'parent_start_ns':begin,'parent_end_ns':end}
 finally:
  if proc.is_alive():proc.terminate()
  proc.join(5)
  if proc.is_alive():proc.kill();proc.join()
  parent.close()
def summarize(out):
 paths=sorted((out/'records').glob('*.json'));assert len(paths)==3408,len(paths)
 raw=[json.loads(p.read_text()) for p in paths];rows=[];segments=0
 for policy in ['strict','relaxed']:
  subset=[r for r in raw if r['policy']==policy];free=None;name=None
  for r in subset:
   if r['map']!=name:name=r['map'];free=independent_map(ROOT/'data/maps'/name)
   if r['success']:
    assert not r.get('validation_errors')
    for a,b in zip(r['path'],r['path'][1:]):assert segment_clear(free,a,b,policy=='strict');segments+=1
  for scope in ['cached','fresh']:
   for method in METHODS:
    items=[r for r in subset if r['scope']==scope and r['method']==method];frame=pd.DataFrame(items)
    grouped=frame.groupby(KEYS,sort=True);assert len(grouped)==71 and (grouped.size()==3).all()
    for key,g in grouped:
     good=g[g.success];rows.append({**dict(zip(KEYS,key)),'policy':policy,'scope':scope,'method':method,'success_rate':g.success.mean(),'parent_wall_ms':g.parent_wall_ms.median(),'search_runtime_ms':g.runtime_ms.median(),'path_length':good.path_length.median() if len(good) else np.nan,'selection_ms':(g.task_features_ms+g.inference_decision_ms).median(),'load_context_ms':g.load_context_ms.median()})
 frame=pd.DataFrame(rows);frame.to_csv(out/'task_medians.csv',index=False);summary=[];paired=[]
 for (policy,scope,method),g in frame.groupby(['policy','scope','method']):
  summary.append({'policy':policy,'scope':scope,'method':method,'maps':len(g),'success_rate':g.success_rate.mean(),'mean_parent_wall_ms':g.parent_wall_ms.mean(),'median_parent_wall_ms':g.parent_wall_ms.median(),'mean_search_runtime_ms':g.search_runtime_ms.mean(),'conditional_path_length':np.average(g.loc[g.success_rate>0,'path_length'],weights=g.loc[g.success_rate>0,'success_rate']),'mean_selection_ms':g.selection_ms.mean(),'mean_load_context_ms':g.load_context_ms.mean()})
  base=frame[(frame.policy==policy)&(frame.scope==scope)&(frame.method=='FixedJPS')];joined=g.merge(base,on=KEYS,suffixes=('_policy','_base'),validate='one_to_one')
  for metric in ['parent_wall_ms','success_rate','path_length']:
   diff=joined[metric+'_policy']-joined[metric+'_base']
   if metric=='path_length':diff=diff.where((joined.success_rate_policy>0)&(joined.success_rate_base>0))
   point,lo,hi=cluster_interval(diff,joined['map'],1000,42);paired.append({'policy':policy,'scope':scope,'method':method,'metric':metric,'difference':point,'ci_low':lo,'ci_high':hi,'paired_tasks':int(diff.notna().sum())})
 pd.DataFrame(summary).to_csv(out/'summary.csv',index=False);pd.DataFrame(paired).to_csv(out/'paired_intervals.csv',index=False)
 atomic(out/'audit.json',{'passed':True,'records':len(raw),'unique_keys':len({tuple(r[k] for k in KEYS+['policy','scope','method','repetition']) for r in raw}),'expected':3408,'successful_paths_independently_checked':sum(r['success'] for r in raw),'segments_checked':segments,'scope':'Complete offline planning transaction, not a hardware robot trial'})
def main():
 out=DEST/'pipeline';(out/'records').mkdir(parents=True,exist_ok=True);files=sorted((out/'records').glob('*.json'));existing=[json.loads(p.read_text()) for p in files];done={tuple(r[k] for k in KEYS+['policy','scope','method','repetition']) for r in existing};assert len(done)==len(files)
 protocol={'expected':3408,'protocol_sha256':hashlib.sha256((Path(__file__).parent/'PIPELINE_PROTOCOL.md').read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'platform':platform.platform(),'python':sys.version,'seed':20261101,'repetitions':3,'search_budget_s':10,'models':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in DEST.glob('*42*.joblib')}}
 if (out/'protocol.json').exists():assert json.loads((out/'protocol.json').read_text())==protocol
 else:atomic(out/'protocol.json',protocol)
 index=len(files);setup=[]
 for policy in ['strict','relaxed']:
  models={'guard':joblib.load(DEST/(policy+'_42_guard.joblib')),'et':joblib.load(DEST/(policy+'_42_original_et.joblib'))};models['et'].predict_proba(np.zeros((1,19)));models['guard']['model'].predict(np.zeros((1,8)))
  tasks=pd.read_csv(ROOT/f'analyses/{policy}/seed_42/test_keys.csv').sort_values(KEYS).drop_duplicates('map')
  for task in tasks.to_dict('records'):
   if all(tuple(task[k] for k in KEYS)+(policy,scope,method,rep) in done for scope in ['cached','fresh'] for method in METHODS for rep in range(3)):continue
   t=time.perf_counter_ns();context=MapFeatures(ROOT/'data/maps'/task['map'],policy=='strict');setup.append({'policy':policy,'map':task['map'],'cached_context_setup_ms':(time.perf_counter_ns()-t)/1e6});grid=context.grid
   for rep in range(3):
    order=[(scope,method) for scope in ['cached','fresh'] for method in METHODS];random.Random(20261101+rep+int(hashlib.sha256((policy+task['map']).encode()).hexdigest()[:8],16)).shuffle(order)
    for scope,method in order:
     key=tuple(task[k] for k in KEYS)+(policy,scope,method,rep)
     if key in done:continue
     result=transaction(task,policy,method,scope,grid,context,models)
     if result.get('validation_errors'):raise RuntimeError(result['validation_errors'])
     record={**task,'policy':policy,'scope':scope,'method':method,'repetition':rep,**result};atomic(out/'records'/f'{index:06d}.json',record);done.add(key);index+=1
   atomic(out/'progress.json',{'records':index,'expected':3408,'last_map':task['map'],'last_policy':policy});print(policy,task['map'],index,'/3408',flush=True)
 pd.DataFrame(setup).to_csv(out/'new_cache_context_setup.csv',index=False);summarize(out);print('Pipeline complete and independently audited',flush=True)

if __name__=='__main__':main()
