# Actual hardware validation procedure

Status: no physical robot observations have been collected. The supplied
simulation must never be renamed as a hardware trial or described as real sensor
evidence. An empty CSV schema is a collection aid, not a dataset.

Before trials, record robot make/model, circular or polygon footprint in metres,
wheelbase, permitted speed/acceleration/turn rates, occupancy resolution in
metres/cell, localization and ground-truth sources, computer/software versions,
controller, emergency-stop procedure and human supervisor. Rebuild footprint
geometry in those calibrated units. The grid-trained selectors have not been
validated on that platform; do not assume current labels transfer unchanged.

Use a controlled marked test area with static obstacles and an available stop.
Define at least three layouts (open, cluttered and narrow passage), ten fixed
start/goal pairs per layout and three paired repetitions per method, with method
order randomized within task blocks. Compare the strongest direct fixed planner,
the original selector and the proposed guarded selector using identical sensing,
map, footprint handling and controller. Log rejected/infeasible starts and plans.
Do not use people as moving test obstacles. An optional moving obstacle requires
a controlled apparatus and a separate approved procedure.

Record monotonic start/end timestamps for map readiness, feature extraction,
selection, planner return, path verification, execution start and execution end.
Retain map, planned path, commanded/estimated trajectory, measured footprint,
ground-truth or independently observed collision/goal events, intervention log,
and software/model hashes. Odometry alone does not verify ground-truth collision
or localization accuracy. Record pose/frame transformations and clock alignment.

The accompanying CSV has one row per actual attempt. Link each row to its raw
logs and map hash. Report planning and execution failures, collision,
intervention, completion time, travelled distance, tracking error and resource
costs separately. Predeclare goal/collision definitions and deadlines. Cluster
uncertainty by layout/task and show every paired difference; do not repeatedly
tune on the same hardware trials until a favorable result appears.

After genuine trials, the raw logs and schema can be checked and analyzed, and
only then may the manuscript acquire a physical-validation results section.
