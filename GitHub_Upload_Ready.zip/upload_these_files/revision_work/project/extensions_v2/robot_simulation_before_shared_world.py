"""Explicit simulated differential-drive transfer study; never hardware evidence."""
import sys,json,math,hashlib,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));sys.path.insert(0,str(Path(__file__).resolve().parent))
import numpy as np,pandas as pd,joblib
from scipy.ndimage import distance_transform_edt,label,uniform_filter
from planners import Grid,path_length
from features import MapFeatures,FEATURES
from run_benchmark import bounded_search
from analysis_core import KEYS,PLANNERS,cluster_interval
from cost_aware import ROOT,DEST,vector,decide

RADIUS=.4;DT=.1;VMAX=2.;WMAX=1.2;ACCEL=.8
def collision(grid,x,y,radius,obstacle=None):
 if x-radius<-.5 or y-radius<-.5 or x+radius>grid.width-.5 or y+radius>grid.height-.5:return True
 x0=max(0,int(math.ceil(x-radius-.5)));x1=min(grid.width-1,int(math.floor(x+radius+.5)))
 y0=max(0,int(math.ceil(y-radius-.5)));y1=min(grid.height-1,int(math.floor(y+radius+.5)))
 for yy in range(y0,y1+1):
  for xx in range(x0,x1+1):
   if grid.blocked[yy,xx] and max(abs(x-xx)-.5,0)**2+max(abs(y-yy)-.5,0)**2<=radius**2:return True
 return obstacle is not None and (x-obstacle[0])**2+(y-obstacle[1])**2<=(radius+obstacle[2])**2
def advance(x,y,heading,v,w,dt):
 if abs(w)<1e-10:return x+v*dt*math.cos(heading),y+v*dt*math.sin(heading),heading+w*dt
 return x+v/w*(math.sin(heading+w*dt)-math.sin(heading)),y-v/w*(math.cos(heading+w*dt)-math.cos(heading)),heading+w*dt
def context_for_grid(grid):
 c=object.__new__(MapFeatures);c.grid=grid;free=~grid.blocked;h,w=free.shape;c.clearance=distance_transform_edt(np.pad(free,1,constant_values=False))[1:-1,1:-1];c.density=uniform_filter(grid.blocked.astype(float),11,mode='constant',cval=1)
 c.components,_=label(free,np.array([[0,1,0],[1,1,1],[0,1,0]]));c.component_sizes=np.bincount(c.components.ravel());n=int(free.sum());edges=(free[:,:-1]&free[:,1:]).sum()+(free[:-1,:]&free[1:,:]).sum()
 c.global_features={'width':w,'height':h,'map_area':w*h,'aspect_ratio':w/h,'free_cells':n,'free_space_ratio':n/(w*h),'obstacle_density':1-n/(w*h),'mean_free_degree4':float(2*edges/n) if n else 0};return c
def track(grid,path,condition,seed,horizon):
 rng=np.random.default_rng(seed);points=np.asarray(path,float);x,y=points[0];theta=0.;v=0.;index=1;elapsed=0.;travel=0.;errors=[];brakes=0;trace=[];crashed=False;reached=False
 lengths=np.linalg.norm(np.diff(points,axis=0),axis=1);cumulative=np.r_[0,np.cumsum(lengths)];mid=max(1,int(np.searchsorted(cumulative,cumulative[-1]/2)));anchor=points[min(mid,len(points)-1)];delta=points[min(mid,len(points)-1)]-points[max(0,mid-1)];perp=np.array([-delta[1],delta[0]])/max(np.linalg.norm(delta),1e-9);crossing=cumulative[-1]/(2*VMAX)
 for step in range(int(horizon/DT)):
  elapsed=step*DT
  if np.hypot(x-points[-1,0],y-points[-1,1])<.6:reached=True;break
  obstacle=None
  if condition=='moving_obstacle':
   o=anchor+perp*(2*math.sin(.4*(elapsed-crossing)));obstacle=(float(o[0]),float(o[1]),.4)
  noise=.1 if condition!='nominal' else 0.;px=x+rng.normal(0,noise);py=y+rng.normal(0,noise);ph=theta+rng.normal(0,.02 if noise else 0)
  # Monotone waypoint progression; estimated pose drives the controller.
  while index<len(points)-1 and np.hypot(points[index,0]-px,points[index,1]-py)<1.0:index+=1
  target=points[index];angle=math.atan2(target[1]-py,target[0]-px);err=(angle-ph+math.pi)%(2*math.pi)-math.pi
  w=float(np.clip(2*err,-WMAX,WMAX));desired=VMAX*max(math.cos(err),0)**2 if abs(err)<math.pi/3 else 0.
  # Braking preview is model-based, not a guarantee under state uncertainty.
  look=max(.4,v*v/(2*ACCEL)+.3);unsafe=any(collision(grid,px+d*math.cos(ph),py+d*math.sin(ph),RADIUS+.05,obstacle) for d in np.linspace(0,look,5))
  if unsafe:desired=0.;brakes+=1
  v=float(np.clip(desired,v-ACCEL*DT,v+ACCEL*DT));v=float(np.clip(v,0,VMAX));nx,ny,nt=advance(x,y,theta,v,w,DT)
  def actual_obstacle(fraction):
   if condition!='moving_obstacle':return None
   o=anchor+perp*(2*math.sin(.4*(elapsed+DT*fraction-crossing)));return (float(o[0]),float(o[1]),.4)
  if any(collision(grid,*advance(x,y,theta,v,w,DT*a)[:2],RADIUS,actual_obstacle(a)) for a in [.5,1.]):crashed=True;break
  travel+=math.hypot(nx-x,ny-y);x,y,theta=nx,ny,nt;errors.append(float(np.min(np.linalg.norm(points[max(0,index-3):min(len(points),index+3)]-[x,y],axis=1))))
  if step%20==0:trace.append([round(elapsed,3),round(x,5),round(y,5),round(theta,5),round(v,4),round(w,4)])
 return {'goal_reached':reached,'collision':crashed,'simulated_elapsed_s':elapsed,'travel_cells':travel,'tracking_waypoint_error_mean_cells':float(np.mean(errors)) if errors else 0.,'braking_steps':brakes,'steps':step+1,'trace':trace,'time_budget_s':horizon}
def main():
 out=DEST/'robot_simulation';out.mkdir(exist_ok=True)
 # Geometry/kinematics checks are fixtures, separate from research observations.
 fixture=Grid(np.array([[True,False],[False,False]]));assert collision(fixture,.8,0,.4) and not collision(fixture,1,1,.4)
 a=advance(0,0,0,1,1,math.pi/2);assert np.allclose(a,[1,1,math.pi/2]);assert np.allclose(advance(0,0,0,1,0,1),[1,0,0])
 tasks=pd.read_csv(ROOT/'analyses/strict/seed_42/test_keys.csv').sort_values(KEYS).drop_duplicates('map');guard=joblib.load(DEST/'strict_42_guard.joblib');et=joblib.load(DEST/'strict_42_original_et.joblib');records=[];eligibility=[];plans=[]
 for task in tasks.to_dict('records'):
  grid=Grid.load(ROOT/'data/maps'/task['map'],True);free=~grid.blocked;clearance=distance_transform_edt(np.pad(free,1,constant_values=False))[1:-1,1:-1];inflated=Grid(grid.blocked|(clearance<=RADIUS+math.sqrt(2)/2),True)
  start=tuple(int(task[k]) for k in KEYS[1:3]);goal=tuple(int(task[k]) for k in KEYS[3:5]);valid=inflated.free(*start) and inflated.free(*goal);eligibility.append({**task,'eligible_after_conservative_inflation':valid})
  for method in ['FixedJPS','OriginalExtraTrees','GuardedCheapUtility']:
   if not valid:
    for condition in ['nominal','noisy_localization','moving_obstacle']:records.append({**task,'method':method,'condition':condition,'status':'invalid_inflated_endpoint','goal_reached':False,'collision':False})
    continue
   if method=='FixedJPS':planner='jps'
   elif method=='GuardedCheapUtility':planner=PLANNERS[int(decide(guard,vector(task,grid.width,grid.height),True)[0][0])]
   else:
    context=context_for_grid(inflated);data,_=context.extract(task);p=et.predict_proba(np.array([[data[n] for n in FEATURES]]))[0];planner=PLANNERS[int(et.classes_[p.argmax()])]
   result=bounded_search(inflated,planner,start,goal,10,'fork');plans.append({**task,'method':method,'planner':planner,**result})
   for condition in ['nominal','noisy_localization','moving_obstacle']:
    if not result['success']:records.append({**task,'method':method,'condition':condition,'status':'planning_'+result['status'],'goal_reached':False,'collision':False});continue
    horizon=min(3600.,max(60.,3*float(result['path_length'])/VMAX+30));seed=int(hashlib.sha256(task['map'].encode()).hexdigest()[:8],16)+20261101
    tracked=track(grid,result['path'],condition,seed,horizon);records.append({**task,'method':method,'condition':condition,'planner':planner,'status':'goal' if tracked['goal_reached'] else ('collision' if tracked['collision'] else 'simulation_timeout'),**tracked})
  print('Robot simulation',task['map'],len(records),'/639',flush=True)
 with (out/'records.jsonl').open('w') as f:
  for row in records:f.write(json.dumps(row)+'\n')
 with (out/'plans.jsonl').open('w') as f:
  for row in plans:f.write(json.dumps(row)+'\n')
 frame=pd.DataFrame([{k:v for k,v in r.items() if k!='trace'} for r in records]);frame.to_csv(out/'episodes.csv',index=False);pd.DataFrame(eligibility).to_csv(out/'eligibility.csv',index=False)
 summary=[]
 for (method,condition),g in frame.groupby(['method','condition']):
  eligible=g[g.status!='invalid_inflated_endpoint'];summary.append({'method':method,'condition':condition,'maps_all':len(g),'eligible_maps':len(eligible),'goal_rate_all':g.goal_reached.mean(),'goal_rate_eligible':eligible.goal_reached.mean() if len(eligible) else np.nan,'collision_rate_all':g.collision.mean(),'planning_failures':int(g.status.str.startswith('planning_').sum()),'tracking_timeouts':int((g.status=='simulation_timeout').sum()),'invalid_inflated_endpoints':int((g.status=='invalid_inflated_endpoint').sum()),'mean_simulated_time_completed_s':g.loc[g.goal_reached,'simulated_elapsed_s'].mean()})
 pd.DataFrame(summary).to_csv(out/'summary.csv',index=False)
 (out/'manifest.json').write_text(json.dumps({'completed':True,'episodes':len(records),'expected':639,'maps':71,'units':'grid-cell widths and simulated seconds; no calibrated physical map resolution','radius_cells':RADIUS,'dt_s':DT,'max_v_cells_s':VMAX,'max_w_rad_s':WMAX,'max_accel_cells_s2':ACCEL,'inflation':'Conservative centre-distance threshold radius+sqrt(2)/2, including blocked exterior; can reject physically feasible narrow passages','state_noise':'Noisy and moving-obstacle conditions: independent normal position SD .1 cells and heading SD .02 rad per control step','dynamic_obstacle':'One fully observed simulated circle of radius .4 cells, sinusoidally crossing the route midpoint; reactive braking, no global dynamic replanning','transfer':'Original trained selectors reused on footprint-altered grids without retraining; a simulation transfer stress test, not validated new robot-domain labels','scope':'Simulation only, no hardware or sensor logs. Goal and true-pose collision are distinct. Braking prediction under state noise is not certified safe.','fixture_tests_passed':True,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2))

if __name__=='__main__':main()
