# Full-transaction measurement cohort, fixed before execution

The initial extension outline considered the complete 355-query primary split.
The executed transaction cohort is one canonical coordinate-sorted query per
held-out map, 71 tasks under each collision rule, matching the existing canonical
explanation sampling rule. This reduces repeated queries within a map while
retaining every primary held-out map; it is not selected by runtime, class,
success, prediction or the new policy's outcome. Report this scope explicitly.

Four methods (fixed JPS, original Extra Trees, cheap utility, calibrated guarded
cheap utility), two occupancy-cache states, two collision rules and three
repetitions produce exactly 3,408 fresh executed planning transactions. Each
paired task/repetition block shuffles all eight method/cache combinations using
seed 20261101. The guard and original models are frozen before these runs.
One child worker at a time, no concurrent training or robot simulation.
Retain all paths and phase timers, inspect all keys, then independently verify
every successful path against the occupied-square segment checker. Use paired
whole-map bootstrap intervals (1,000 resamples) for total wall-time differences.
Do not mix the new wall-clock observations into the original preference labels.

Fresh parsing includes opening and parsing the occupancy file but does not flush
OS caches or unload models. Cached Extra Trees has a precomputed feature context;
other cached methods have occupancy only. Context construction costs are
recorded separately. The complete parent wall timer includes process start,
selection, actual search, path validation and result transfer. Model-load and
physical sensing/control costs are outside this transaction. A search-start
signal begins the external 10 s planner budget. Parent wall times may exceed
10 s because the other stages are included. This is complete offline planning
transaction evidence, not a physical navigation measurement.
