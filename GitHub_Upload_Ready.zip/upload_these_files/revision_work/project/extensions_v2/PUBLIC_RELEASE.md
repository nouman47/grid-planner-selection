# Repository-ready release

Status: prepared locally; not publicly deposited. No GitHub URL or DOI is
invented. Publishing through the user's account requires an authenticated
connection and an actual successful creation/deposit.

Suggested repository name: `grid-planner-selection-revision`.
Suggested tag: `revision-v2`.
Suggested description: independently audited six-planner benchmark with
map-disjoint selection, measured planning transactions and explicit simulation
limitations.

Publish corrected source, dependency files, experiment protocols, input/split
manifests, table/figure/document builders and the hardware-trial procedure. Put
the complete S1 data archive in a release asset rather than ordinary Git history
because it exceeds GitHub's ordinary individual-file limit. Preserve the Moving
AI attribution/license notice. Any software reuse license must be chosen by the
rights holder; this package does not invent a license grant for the author.

Use the final verified S1 archive for the release asset. Provide repository
README reproduction commands and an honest summary of the negative results.
Record the public commit/tag, downloadable asset URL and asset hash. Check the
links from a signed-out session. Then replace the manuscript's current
"repository not released" statement with those real locations and regenerate the
response letter. Do not mark this step complete solely because files are ready.
