"""Cheap utility routing and map-calibrated switching; original sources untouched."""
import sys,json,time,hashlib,gc,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import joblib,numpy as np,pandas as pd
from sklearn.ensemble import GradientBoostingRegressor,ExtraTreesClassifier
from sklearn.multioutput import MultiOutputRegressor
from sklearn.model_selection import GroupShuffleSplit
from analysis_core import KEYS,PLANNERS,policy_outcomes,cluster_interval

ROOT=Path(__file__).resolve().parents[1];DEST=ROOT/'extensions_v2/results';DEST.mkdir(exist_ok=True)
CHEAP=['start_x','start_y','goal_x','goal_y','euclidean_distance','manhattan_distance','width','height']
def vector(task,width,height):
 sx,sy,gx,gy=[int(task[k]) for k in KEYS[1:]]
 return np.array([[sx,sy,gx,gy,np.hypot(gx-sx,gy-sy),abs(gx-sx)+abs(gy-sy),width,height]],float)
def net_predictions(pred,budget):
 span=np.maximum(np.exp(np.clip(pred[:,6],-20,20)),1e-9)
 return pred[:,:6]-.5*np.minimum(budget/span,1)[:,None]
def decide(bundle,x,guard=True):
 pred=bundle['model'].predict(x);net=net_predictions(pred,bundle['budget_ms']);base=bundle['baseline_index']
 gain=net-pred[:,base,None];choice=gain.argmax(axis=1)
 accepted=gain[np.arange(len(x)),choice]>bundle['q'] if guard else np.ones(len(x),bool)
 return np.where(accepted,choice,base),accepted,gain
def charge(utility,runtime_score,span,cost):
 penalty=np.where(span>0,.5*np.minimum(cost/np.maximum(span,1e-30),runtime_score),.5*runtime_score*(cost>0))
 return utility-penalty
def matrix(utilities,keys,col):
 return keys.merge(utilities.pivot(index=KEYS,columns='planner',values=col).reset_index(),on=KEYS,validate='one_to_one')[list(PLANNERS)].to_numpy(float)
def main():
 summaries=[];paired=[];coverage=[]
 for policy in ['strict','relaxed']:
  features=pd.read_csv(ROOT/f'data/features_{policy}.csv');utilities=pd.read_csv(ROOT/f'analyses/{policy}/planner_utilities.csv')
  for seed in [42,52,62,72,82]:
   folder=ROOT/f'analyses/{policy}/seed_{seed}';train=pd.read_csv(folder/'train_keys.csv').merge(features,on=KEYS,validate='one_to_one');test=pd.read_csv(folder/'test_keys.csv').merge(features,on=KEYS,validate='one_to_one')
   proper,cal=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=seed+1000).split(train,groups=train['map']))
   assert not set(train.iloc[proper]['map'])&set(train.iloc[cal]['map']) and not set(train['map'])&set(test['map'])
   U=matrix(utilities,train[KEYS],'utility');R=matrix(utilities,train[KEYS],'runtime_score');T=matrix(utilities,train[KEYS],'runtime_ms');S=matrix(utilities,train[KEYS],'success_rate')
   span=np.array([np.ptp(t[s>0]) if (s>0).any() else 0 for t,s in zip(T,S)])
   target=np.column_stack([U,np.log(np.maximum(span,1e-9))]);base=int(U[proper].mean(axis=0).argmax())
   model=MultiOutputRegressor(GradientBoostingRegressor(n_estimators=100,max_depth=2,learning_rate=.05,min_samples_leaf=10,random_state=seed),n_jobs=1)
   model.fit(train.iloc[proper][CHEAP].to_numpy(float),target[proper]);model.predict(train[CHEAP].to_numpy(float)[:1])
   costs=[]
   for task in train.iloc[proper].to_dict('records'):
    reps=[]
    for _ in range(3):
     start=time.perf_counter_ns();x=vector(task,task['width'],task['height']);p=model.predict(x);n=net_predictions(p,1.0);c=int(n.argmax());reps.append((time.perf_counter_ns()-start)/1e6)
    costs.append(float(np.median(reps)))
   budget=float(np.quantile(costs,.99));calpred=model.predict(train.iloc[cal][CHEAP].to_numpy(float));hat=net_predictions(calpred,budget)-calpred[:,base,None]
   actual=charge(U[cal],R[cal],span[cal,None],budget)-U[cal,base,None]
   scores=pd.DataFrame({'map':train.iloc[cal]['map'].to_numpy(),'optimism':(hat-actual).max(axis=1)}).groupby('map').optimism.max().to_numpy()
   rank=math.ceil((len(scores)+1)*.9);q=float(np.sort(scores)[rank-1]) if rank<=len(scores) else float('inf')
   bundle={'model':model,'baseline_index':base,'budget_ms':budget,'q':q,'alpha':.1,'feature_columns':CHEAP,'policy':policy,'seed':seed,'proper_maps':sorted(set(train.iloc[proper]['map'])),'calibration_maps':sorted(set(train.iloc[cal]['map'])),'test_maps':sorted(set(test['map']))}
   tag=f'{policy}_{seed}';joblib.dump(bundle,DEST/(tag+'_guard.joblib'),compress=3)
   pd.DataFrame({'map':train.iloc[proper]['map'].to_numpy(),'median_decision_ms':costs}).to_csv(DEST/(tag+'_proper_training_costs.csv'),index=False)
   pred=model.predict(test[CHEAP].to_numpy(float));ut=matrix(utilities,test[KEYS],'utility');rt=matrix(utilities,test[KEYS],'runtime_score');tt=matrix(utilities,test[KEYS],'runtime_ms');st=matrix(utilities,test[KEYS],'success_rate');sp=np.array([np.ptp(t[s>0]) if (s>0).any() else 0 for t,s in zip(tt,st)])
   hat=net_predictions(pred,budget)-pred[:,base,None];truth=charge(ut,rt,sp[:,None],budget)-ut[:,base,None]
   covered=(hat-truth).max(axis=1)<=q+1e-12
   for name in ['CheapUtility','GuardedCheapUtility']:
    choices,accepted,gain=decide(bundle,test[CHEAP].to_numpy(float),name.startswith('Guarded'))
    overhead=[]
    for task in test.to_dict('records'):
     reps=[]
     for _ in range(3):
      start=time.perf_counter_ns();xx=vector(task,task['width'],task['height']);decide(bundle,xx,name.startswith('Guarded'));reps.append((time.perf_counter_ns()-start)/1e6)
     overhead.append(float(np.median(reps)))
    output=policy_outcomes(utilities,test,[PLANNERS[i] for i in choices],overhead_ms=np.array(overhead));output.to_csv(DEST/(tag+'_'+name+'_outcomes.csv'),index=False)
    baseline=policy_outcomes(utilities,test,[PLANNERS[base]]*len(test));diff=output.utility-baseline.utility;point,lo,hi=cluster_interval(diff,test['map'],1000,seed)
    summaries.append({'policy':policy,'seed':seed,'method':name,'baseline':PLANNERS[base],'mean_utility':output.utility.mean(),'baseline_utility':baseline.utility.mean(),'utility_difference':point,'ci_low':lo,'ci_high':hi,'mean_search_selection_ms':output.runtime_ms.mean(),'success_rate':output.success_rate.mean(),'mean_selection_ms':np.mean(overhead),'budget_ms':budget,'cost_budget_exceedance':float((np.array(overhead)>budget).mean()),'switch_rate':float((choices!=base).mean()),'gate_acceptance':float(accepted.mean()),'q':q})
    record=test[KEYS+['family']].copy();record['planner']=np.array(PLANNERS)[choices];record['accepted']=accepted;record['lower_margin']=gain[np.arange(len(test)),choices]-q;record['selection_ms']=overhead;record['map_bound_case_covered']=covered;record.to_csv(DEST/(tag+'_'+name+'_decisions.csv'),index=False)
   mapcoverage=pd.DataFrame({'map':test['map'],'covered':covered}).groupby('map').covered.all()
   coverage.append({'policy':policy,'seed':seed,'calibration_maps':len(scores),'test_maps':len(mapcoverage),'map_coverage':mapcoverage.mean(),'nominal':.9,'q':q,'budget_ms':budget})
   if seed==42:
    # Exact primary original classifier producer; compare saved probabilities.
    labels=pd.read_csv(ROOT/f'analyses/{policy}/task_labels.csv');tr=train[KEYS].merge(labels,on=KEYS,validate='one_to_one');y=tr.best_planner.map({n:i for i,n in enumerate(PLANNERS)}).fillna(-1).to_numpy(int);valid=y>=0
    original=ExtraTreesClassifier(n_estimators=500,max_features='sqrt',random_state=seed,n_jobs=1);original.fit(train.loc[valid,features.columns.intersection(CHEAP)].to_numpy(),y[valid]) if False else None
    from features import FEATURES
    original.fit(train.loc[valid,FEATURES].to_numpy(float),y[valid]);raw=original.predict_proba(test[FEATURES].to_numpy(float));aligned=np.zeros((len(test),6));aligned[:,original.classes_.astype(int)]=raw
    saved=pd.read_csv(folder/'ExtraTrees_test_predictions.csv')[["p_"+x for x in PLANNERS]].to_numpy(float);assert np.allclose(aligned,saved,atol=1e-12,rtol=1e-12)
    joblib.dump(original,DEST/(tag+'_original_et.joblib'),compress=3);del original;gc.collect()
   print(tag,'new policy evaluated; q',q,'map coverage',mapcoverage.mean(),flush=True)
 pd.DataFrame(summaries).to_csv(DEST/'cost_policy_summary.csv',index=False);pd.DataFrame(coverage).to_csv(DEST/'map_coverage.csv',index=False)
 (DEST/'cost_policy_manifest.json').write_text(json.dumps({'completed':True,'protocol_sha256':hashlib.sha256((Path(__file__).parent/'PROTOCOL.md').read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'exploratory_extension':True,'test_tuning':False,'original_classifier_reconstruction_matches_saved_probabilities':True,'conditional_guarantee_limits':'Map-exchangeability, fixed query blocks, and decision budget; fallback still pays overhead; no collision safety or universal improvement claim'},indent=2))

if __name__=='__main__':main()
