# Additional revision experiments fixed before new-policy evaluation

This extension is exploratory: the original corrected benchmark and its test
results have already been inspected. The original Extra Trees remains primary.
No test outcome will be used to change the following configurations or select a
reported winner. Negative results and zero-acceptance gates will be retained.

## Proposed policy and bounded contribution

Use eight inexpensive pre-search descriptors: start/goal coordinates, Euclidean
and Manhattan separation, width and height. Fit seven gradient-boosted regressors
on proper-training maps: six planner utilities and log successful-candidate
runtime span. Each has 100 trees, depth 2, learning rate .05 and minimum leaf 10.
Use the original five map splits under both collision rules. Reserve 20% of
outer-training maps for calibration (seed outer_seed+1000). The fixed reference
is the single-best planner chosen on proper-training maps only.

Measure median per-query decision cost from three calls on proper-training tasks;
use its 99th percentile as an operational budget, not a deterministic bound.
Predict net utility gain relative to the fixed reference by subtracting the
estimated runtime-score penalty at that budget. Calibrate one-sided optimistic
error using the maximum over all six planners and all five queries within each
calibration map. At alpha .1, the finite-sample map quantile supplies a joint
lower margin. Switch only when that lower margin is positive; otherwise execute
the reference. An unguarded cheap-utility comparator isolates the gate effect.

Any conformal statement is conditional on exchangeability of map blocks, fixed
five-query construction, the fitted model and operational cost budget. It is a
marginal map guarantee, not a selected-subset conditional guarantee. Accepted
switches are protected only when the cost budget holds and the map coverage event
holds. Rejected decisions still incur selector cost: no unconditional
non-degradation or collision-safety theorem is claimed. City variants and fixed
convenience maps weaken applicability of exchangeability to deployment.

Report all five splits, acceptance, actual regret/utility, map coverage and
budget exceedance. Do not choose alpha by test performance. Related established
cost-sensitive selection and conformal routing must be cited; this is a
portfolio-specific policy/evaluation extension, not certified fundamental novelty.

## Complete planning transactions

For the primary seed-42 held-out tasks, strict and relaxed rules, three repetitions,
execute fixed JPS, original 500-tree Extra Trees, cheap utility and guarded cheap
utility sequentially in shuffled paired task blocks. Report cached occupancy
and fresh-parsed occupancy transactions separately. Cold means fresh parsing,
not flushed OS disk caches. Models are already resident. Each transaction really
runs feature extraction, inference/routing, planner search, path checking and
worker result transfer. Retain start/end timestamps, selected planner, path,
success, each stage and total parent wall time; externally enforce a 10 s search
budget after the search-start signal. Common process launch and occupancy loading
are included in parent totals for every method. A timed-out transaction remains
a failure and is not replaced. All expected keys must exist before summary.
This is an offline complete planning transaction, not sensing/control hardware.

## Robot applicability

Add explicitly labelled simulation with circular footprint, conservative obstacle
inflation, differential-drive velocity/turn-rate constraints and closed-loop path
tracking. Test nominal and noisy localization plus a moving-obstacle condition,
recording true-pose collision, goal success, tracking error and completion time.
Report unusable endpoints after inflation instead of silently dropping them.
Existing trained selectors are transfer tests under changed geometry, not models
validated by training on those robot conditions. Provide hardware experiment and
logging instructions; no physical result may be claimed without recorded trials.

## Integrity

Keep the previous complete S1 archive unchanged as the baseline. Preserve original
source/data hashes. New records are atomic and resumable. One timed worker only;
do not run training/simulation/rendering concurrently with transaction timing.
