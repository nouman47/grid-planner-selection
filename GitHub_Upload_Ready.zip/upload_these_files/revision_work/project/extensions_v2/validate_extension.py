"""Independent key, timing, model, calibration and simulation release checks."""
import sys,json,hashlib,itertools
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));sys.path.insert(0,str(Path(__file__).resolve().parent))
import joblib,numpy as np,pandas as pd
from analysis_core import KEYS,PLANNERS
from features import FEATURES
from cost_aware import ROOT,DEST,CHEAP,matrix,charge,net_predictions,decide

def main():
 folder=DEST/'pipeline';protocol=json.loads((folder/'protocol.json').read_text());records=[json.loads(p.read_text()) for p in sorted((folder/'records').glob('*.json'))];expected=set();ident=KEYS+['policy','scope','method','repetition']
 for policy in ['strict','relaxed']:
  keys=pd.read_csv(ROOT/f'analyses/{policy}/seed_42/test_keys.csv').sort_values(KEYS).drop_duplicates('map')
  for row in keys.to_dict('records'):
   for scope,method,rep in itertools.product(['cached','fresh'],['FixedJPS','OriginalExtraTrees','CheapUtility','GuardedCheapUtility'],range(3)):expected.add(tuple(row[k] for k in KEYS)+(policy,scope,method,rep))
 observed=[tuple(r[k] for k in ident) for r in records];assert len(observed)==len(set(observed))==3408 and set(observed)==expected
 assert hashlib.sha256((Path(__file__).parent/'pipeline.py').read_bytes()).hexdigest()==protocol['source_sha256']
 baseline=json.loads((ROOT/'results/full_v2/protocol.json').read_text())
 for name,digest in baseline['sources'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
 for name,digest in baseline['map_sha256'].items():assert hashlib.sha256((ROOT/'data/maps'/name).read_bytes()).hexdigest()==digest
 oracle=pd.read_csv(ROOT/'results/full_v2/independent_oracle.csv');oraclecols=list(oracle.columns)
 for r in records:
  assert r['parent_wall_ms']>0 and np.isclose(r['parent_wall_ms'],(r['parent_end_ns']-r['parent_start_ns'])/1e6)
  assert r['success']==(r['status']=='solved') and r['runtime_ms']>0 and r['runtime_ms']<=10000
  if r['success']:
   assert r['path'][0]==[r['start_x'],r['start_y']] and r['path'][-1]==[r['goal_x'],r['goal_y']]
  if 'worker_wall_ms' in r:
   assert r['parent_wall_ms']>=r['worker_wall_ms']
   assert sum(r[k] for k in ['load_context_ms','task_features_ms','inference_decision_ms','search_wall_ms','validation_ms'])<=r['worker_wall_ms']+.001
 diag=[];scores_saved=[]
 for policy in ['strict','relaxed']:
  features=pd.read_csv(ROOT/f'data/features_{policy}.csv');utilities=pd.read_csv(ROOT/f'analyses/{policy}/planner_utilities.csv')
  for seed in [42,52,62,72,82]:
   bundle=joblib.load(DEST/f'{policy}_{seed}_guard.joblib');proper=set(bundle['proper_maps']);calmaps=set(bundle['calibration_maps']);testmaps=set(bundle['test_maps']);assert len(proper)==168 and len(calmaps)==42 and len(testmaps)==71
   assert not proper&calmaps and not (proper|calmaps)&testmaps
   train=pd.read_csv(ROOT/f'analyses/{policy}/seed_{seed}/train_keys.csv').merge(features,on=KEYS,validate='one_to_one');cal=train[train['map'].isin(calmaps)];U=matrix(utilities,cal[KEYS],'utility');R=matrix(utilities,cal[KEYS],'runtime_score');T=matrix(utilities,cal[KEYS],'runtime_ms');S=matrix(utilities,cal[KEYS],'success_rate');span=np.array([np.ptp(t[s>0]) if (s>0).any() else 0 for t,s in zip(T,S)])
   pred=bundle['model'].predict(cal[CHEAP].to_numpy(float));b=bundle['baseline_index'];hat=net_predictions(pred,bundle['budget_ms'])-pred[:,b,None];actual=charge(U,R,span[:,None],bundle['budget_ms'])-U[:,b,None]
   scores=pd.DataFrame({'map':cal['map'].to_numpy(),'score':(hat-actual).max(axis=1)}).groupby('map').score.max();q=float(scores.sort_values().iloc[38]);assert np.isclose(q,bundle['q'],atol=1e-12)
   for name,score in scores.items():scores_saved.append({'policy':policy,'seed':seed,'map':name,'optimism_score':score,'q':q})
   test=pd.read_csv(ROOT/f'analyses/{policy}/seed_{seed}/test_keys.csv').merge(features,on=KEYS,validate='one_to_one')
   for method in ['CheapUtility','GuardedCheapUtility']:
    choice,accepted,gain=decide(bundle,test[CHEAP].to_numpy(float),method=='GuardedCheapUtility');saved=pd.read_csv(DEST/f'{policy}_{seed}_{method}_decisions.csv');assert np.array_equal(saved.planner,np.array(PLANNERS)[choice]) and np.array_equal(saved.accepted,accepted)
   if seed==42:
    actualrecords=[r for r in records if r['policy']==policy and r['method']=='GuardedCheapUtility']
    for scope in ['cached','fresh']:
     g=[r for r in actualrecords if r['scope']==scope];costs=np.array([r['task_features_ms']+r['inference_decision_ms'] for r in g]);diag.append({'policy':policy,'scope':scope,'transactions':len(g),'budget_ms':bundle['budget_ms'],'mean_worker_selection_ms':costs.mean(),'budget_exceedance_rate':float((costs>bundle['budget_ms']).mean())})
 pd.DataFrame(scores_saved).to_csv(DEST/'calibration_map_scores.csv',index=False);pd.DataFrame(diag).to_csv(DEST/'pipeline/budget_portability.csv',index=False)
 sim=DEST/'robot_simulation';episodes=pd.read_csv(sim/'episodes.csv');assert len(episodes)==639 and not episodes.duplicated(['map','method','condition']).any()
 assert not (episodes.goal_reached&episodes.collision).any();eligible=pd.read_csv(sim/'eligibility.csv');assert len(eligible)==71 and (~eligible.eligible_after_conservative_inflation).sum()==24
 raw=[json.loads(x) for x in (sim/'records.jsonl').read_text().splitlines()];assert len(raw)==639
 manifest=json.loads((sim/'manifest.json').read_text());assert manifest['controller_source_sha256']==hashlib.sha256((Path(__file__).parent/'robot_simulation.py').read_bytes()).hexdigest()
 assert manifest['common_horizon_source_sha256']==hashlib.sha256((Path(__file__).parent/'robot_common_horizon.py').read_bytes()).hexdigest()
 plans=[json.loads(x) for x in (sim/'plans.jsonl').read_text().splitlines()]
 for name,g in episodes.groupby('map'):
  reference=next((p['path'] for p in plans if p['map']==name and p['method']=='FixedJPS' and p['success']),None)
  executed=[r for r in raw if r['map']==name and 'trace' in r]
  if executed:
   assert reference is not None;digest=hashlib.sha256(json.dumps(reference).encode()).hexdigest();assert all(r['dynamic_reference_path_sha256']==digest for r in executed)
 for r in raw:
  for t,x,y,theta,v,w in r.get('trace',[]):assert 0<=v<=2 and abs(w)<=1.2+1e-10
  if r['status']=='invalid_inflated_endpoint':assert not r['goal_reached'] and not r['collision']
 timing=episodes.groupby('map').time_budget_s.nunique(dropna=True);assert (timing<=1).all()
 assert len(pd.read_csv(Path(__file__).parent/'physical_trials_template.csv'))==0
 report={'passed':True,'complete_unique_transactions':3408,'unchanged_original_benchmark_sources_and_maps':True,'per_record_timing_and_status_contracts_passed':True,'calibration_quantiles_independently_recomputed':10,'new_policy_decisions_replayed':7100,'simulation_unique_episodes':639,'shared_dynamic_reference_checked_from_saved_JPS_paths':True,'common_horizons_and_logged_motion_bounds_passed':True,'physical_observations':0,'public_repository_released':False,'raw_pipeline_budget_portability_included':True}
 (DEST/'extension_validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));print(pd.DataFrame(diag).to_string(index=False))

if __name__=='__main__':main()
