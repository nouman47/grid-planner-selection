"""Forty-five prespecified utility weightings on the primary held-out-map split.

Refits the same Extra Trees configuration using training maps only. Reports both
keeping the default trained policy and retraining for each preference. All scores
remain planning-only until the separate overhead analysis is completed.
"""
import argparse
import hashlib
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.metrics import accuracy_score,f1_score
from analysis_core import KEYS,PLANNERS,compute_utility,policy_outcomes,cluster_interval
from features import FEATURES


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--analysis',default='analyses/strict');args=parser.parse_args();root=Path(args.analysis)
    manifest=json.loads((root/'manifest.json').read_text())
    if manifest['status']!='model and planning-only policy analysis completed':raise RuntimeError('Model-analysis completion gate failed')
    policy=root.name;dest=root/'seed_42';raw=pd.read_csv(root/'planner_utilities.csv')
    default_labels=pd.read_csv(root/'task_labels.csv');features=pd.read_csv('data/features_'+policy+'.csv')
    train_keys=pd.read_csv(dest/'train_keys.csv');test_keys=pd.read_csv(dest/'test_keys.csv')
    train=train_keys.merge(features,on=KEYS,validate='one_to_one');test=test_keys.merge(features,on=KEYS,validate='one_to_one')
    x_train=train[FEATURES].to_numpy(float);x_test=test[FEATURES].to_numpy(float)
    if set(train['map'])&set(test['map']):raise RuntimeError('Map overlap')
    default_model=joblib.load(dest/'ExtraTrees.joblib');default_pred=default_model.predict(x_test).astype(int)
    code={name:i for i,name in enumerate(PLANNERS)};rows=[]
    for success_tick in range(5):
        for runtime_tick in range(11-success_tick):
            weights=(success_tick/10,runtime_tick/10,(10-success_tick-runtime_tick)/10)
            utilities,labels=compute_utility(raw,weights)
            train_labels=train_keys.merge(labels,on=KEYS,validate='one_to_one');test_labels=test_keys.merge(labels,on=KEYS,validate='one_to_one')
            train_y=train_labels.best_planner.map(code).fillna(-1).to_numpy(int);test_y=test_labels.best_planner.map(code).fillna(-1).to_numpy(int)
            valid_train=train_y>=0;valid_test=test_y>=0
            model=ExtraTreesClassifier(n_estimators=500,max_features='sqrt',random_state=42,n_jobs=1)
            model.fit(x_train[valid_train],train_y[valid_train]);pred=model.predict(x_test).astype(int)
            original=policy_outcomes(utilities,test,[PLANNERS[i] for i in default_pred],weights=weights)
            retrained=policy_outcomes(utilities,test,[PLANNERS[i] for i in pred],weights=weights)
            oracle=test_keys.merge(labels[KEYS+['best_utility']],on=KEYS,validate='one_to_one').best_utility.to_numpy()
            joined=labels.merge(default_labels[KEYS+['best_planner']],on=KEYS,suffixes=('_new','_default'),validate='one_to_one')
            valid=joined.label_valid.to_numpy(bool)
            agreement=float((joined.loc[valid,'best_planner_new']==joined.loc[valid,'best_planner_default']).mean())
            default_regret=oracle-original.utility.to_numpy();retrained_regret=oracle-retrained.utility.to_numpy()
            delta=original.utility.to_numpy()-retrained.utility.to_numpy();mean,lo,hi=cluster_interval(delta,test['map'],1000,42)
            rows.append({'w_success':weights[0],'w_runtime':weights[1],'w_path':weights[2],
                         'valid_label_agreement_with_default':agreement,'test_classification_tasks':int(valid_test.sum()),
                         'default_model_accuracy':accuracy_score(test_y[valid_test],default_pred[valid_test]) if valid_test.any() else np.nan,
                         'retrained_accuracy':accuracy_score(test_y[valid_test],pred[valid_test]) if valid_test.any() else np.nan,
                         'retrained_macro_f1':f1_score(test_y[valid_test],pred[valid_test],labels=np.arange(6),average='macro',zero_division=0) if valid_test.any() else np.nan,
                         'default_model_mean_regret':float(default_regret.mean()),'retrained_mean_regret':float(retrained_regret.mean()),
                         'default_minus_retrained_utility':mean,'utility_difference_ci_low':lo,'utility_difference_ci_high':hi,
                         'timing_scope':'planning-only','primary_seed':42})
            print('Weighting',weights,'completed',flush=True)
    output=pd.DataFrame(rows)
    if len(output)!=45:raise RuntimeError('Weight grid incomplete')
    output.to_csv(root/'weight_sensitivity.csv',index=False)
    (root/'weight_sensitivity.metadata.json').write_text(json.dumps({'configurations':45,'seed':42,'test_maps_unchanged':True,
        'training_uses_only_training_maps':True,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'limitations':'Primary split only; fixed tree configuration, no per-weight tuning; end-to-end overhead remains separate'},indent=2))


if __name__=='__main__':main()
