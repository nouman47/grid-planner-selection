"""Check persisted model outputs independently of the reporting loop."""
import ast,hashlib,json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score,f1_score
from analysis_core import KEYS,PLANNERS
from features import FEATURES

def main():
    checks=0;hashes={}
    for policy in ['strict','relaxed']:
        root=Path('analyses')/policy
        manifest=json.loads((root/'manifest.json').read_text())
        assert manifest['status']=='model and planning-only policy analysis completed'
        for file,key in [('evaluate_models.py','analysis_source_sha256'),('analysis_core.py','analysis_core_sha256')]:
            current=hashlib.sha256(Path(file).read_bytes()).hexdigest()
            if current!=manifest[key] and file=='analysis_core.py':
                change=json.loads(Path('validation/selective_threshold_grid_correction.json').read_text())
                old=Path('validation/analysis_core_before_threshold_grid.py')
                assert hashlib.sha256(old.read_bytes()).hexdigest()==manifest[key]==change['previous_core_sha256']
                assert current==change['current_core_sha256'] and change['boundary_regression_test_passed']
                # The sole accepted source change is the recorded selective-grid
                # diagnostic repair. All fitting/policy/metric functions match.
                trees=[ast.parse(p.read_text()) for p in [old,Path(file)]]
                for tree in trees:tree.body=[n for n in tree.body if not isinstance(n,ast.FunctionDef) or n.name!='selective_table']
                assert ast.dump(trees[0],include_attributes=False)==ast.dump(trees[1],include_attributes=False)
            else:assert current==manifest[key]
        features=pd.read_csv('data/features_'+policy+'.csv')
        metrics=pd.read_csv(root/'model_comparison.csv')
        labels=pd.read_csv(root/'task_labels.csv')
        utilities=pd.read_csv(root/'planner_utilities.csv')
        for seed in [42,52,62,72,82]:
            dest=root/f'seed_{seed}';split=json.loads((dest/'split.json').read_text())
            train=pd.read_csv(dest/'train_keys.csv');test=pd.read_csv(dest/'test_keys.csv')
            assert not set(train['map'])&set(test['map'])
            assert len(train)+len(test)==1405 and len(set(split['train_maps'])|set(split['test_maps']))==281
            for name in ['LogisticRegression','RandomForest','ExtraTrees','GradientBoosting','ExtraTreesBalanced','RandomForestBalanced']:
                path=dest/(name+'.joblib');hashes[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
                model=joblib.load(path);pred=pd.read_csv(dest/(name+'_test_predictions.csv'))
                assert not pred.duplicated(KEYS).any() and pred[KEYS].equals(test[KEYS])
                x=pred[KEYS].merge(features,on=KEYS,validate='one_to_one')[FEATURES].to_numpy(float)
                raw=model.predict_proba(x);p=np.zeros((len(x),6));p[:,np.asarray(model.classes_,int)]=raw
                saved=pred[['p_'+n for n in PLANNERS]].to_numpy(float)
                assert np.allclose(p,saved,atol=1e-12) and np.allclose(pred.confidence,p.max(axis=1))
                assert np.array_equal(pred.predicted_planner,np.asarray(PLANNERS)[p.argmax(axis=1)])
                joined=pred[KEYS].merge(labels,on=KEYS,validate='one_to_one');valid=joined.label_valid.to_numpy(bool)
                y=joined.best_planner.map({n:i for i,n in enumerate(PLANNERS)}).fillna(-1).to_numpy(int)
                m=metrics[(metrics.seed==seed)&(metrics.model==name)].iloc[0]
                assert np.isclose(m.accuracy,accuracy_score(y[valid],p.argmax(axis=1)[valid]))
                assert np.isclose(m.macro_f1,f1_score(y[valid],p.argmax(axis=1)[valid],labels=np.arange(6),average='macro',zero_division=0))
                checks+=len(pred)
            for path in dest.glob('*_outcomes.csv'):
                frame=pd.read_csv(path);assert frame[KEYS].equals(test[KEYS])
                assert np.isfinite(frame.utility).all() and frame.utility.between(-1e-12,1+1e-12).all()
                oracle=test.merge(labels[KEYS+['best_utility']],on=KEYS,validate='one_to_one').best_utility.to_numpy()
                assert (frame.utility.to_numpy()<=oracle+1e-10).all()
                if 'planner' in frame:
                    joined=frame[KEYS+['planner']].merge(utilities,on=KEYS+['planner'],validate='one_to_one')
                    for col in ['utility','success_rate','runtime_ms','path_length']:
                        assert np.allclose(frame[col],joined[col],equal_nan=True)
                checks+=len(frame)
        print(policy,'persisted outputs verified',flush=True)
    report={'passed':True,'task_output_checks':checks,'model_sha256':hashes,
            'scope':'Map separation, persisted model probabilities, classification metrics, task alignment, planner outcomes and oracle bounds. Overhead, sensitivity and SHAP remain separate.'}
    Path('validation/model_outputs_validation.json').write_text(json.dumps(report,indent=2))
    print('Verified',checks,'task outputs and',len(hashes),'saved classifier models',flush=True)

if __name__=='__main__':main()
