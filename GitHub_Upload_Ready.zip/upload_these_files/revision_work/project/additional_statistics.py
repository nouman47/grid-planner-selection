"""Paired model comparisons and family/class support on saved held-out outputs."""
from pathlib import Path
import json
import numpy as np,pandas as pd
from analysis_core import KEYS,PLANNERS

def scores(matrix):
    tp=np.diagonal(matrix,axis1=-2,axis2=-1);denom=matrix.sum(axis=-2)+matrix.sum(axis=-1)
    f1=np.divide(2*tp,denom,out=np.zeros_like(tp,dtype=float),where=denom>0).mean(axis=-1)
    return tp.sum(axis=-1)/matrix.sum(axis=(-2,-1)),f1

def main():
    pairs=[];support=[]
    for policy in ['strict','relaxed']:
        root=Path('analyses')/policy;labels=pd.read_csv(root/'task_labels.csv')
        for seed in [42,52,62,72,82]:
            folder=root/f'seed_{seed}';primary=pd.read_csv(folder/'ExtraTrees_test_predictions.csv')
            for partition in ['train','test']:
                keys=pd.read_csv(folder/(partition+'_keys.csv'));frame=keys.merge(labels,on=KEYS,validate='one_to_one')
                for family,g in frame.groupby('family'):
                    counts=g.best_planner.fillna('all_failure').value_counts()
                    for name in list(PLANNERS)+['all_failure']:support.append({'policy':policy,'seed':seed,'partition':partition,'family':family,'planner_label':name,'tasks':int(counts.get(name,0)),'maps_in_family':g['map'].nunique()})
            valid=primary.label_valid.to_numpy(bool);p=primary.loc[valid].reset_index(drop=True);names,inverse=np.unique(p['map'],return_inverse=True)
            code={n:i for i,n in enumerate(PLANNERS)};y=p.best_planner.map(code).to_numpy(int);a=p.predicted_planner.map(code).to_numpy(int)
            ma=np.zeros((len(names),6,6),int);np.add.at(ma,(inverse,y,a),1)
            rng=np.random.default_rng(seed);draws=rng.integers(0,len(names),size=(1000,len(names)))
            acca,f1a=scores(ma[draws].sum(axis=1));pointa=scores(ma.sum(axis=0))
            for model in ['LogisticRegression','RandomForest','GradientBoosting','ExtraTreesBalanced','RandomForestBalanced']:
                other=pd.read_csv(folder/(model+'_test_predictions.csv'));assert other[KEYS].equals(primary[KEYS])
                b=other.loc[valid,'predicted_planner'].map(code).to_numpy(int);mb=np.zeros_like(ma);np.add.at(mb,(inverse,y,b),1)
                accb,f1b=scores(mb[draws].sum(axis=1));pointb=scores(mb.sum(axis=0))
                for metric,values,point in [('accuracy',acca-accb,pointa[0]-pointb[0]),('macro_f1',f1a-f1b,pointa[1]-pointb[1])]:
                    pairs.append({'policy':policy,'seed':seed,'primary':'ExtraTrees','comparator':model,'metric':metric,'primary_minus_comparator':float(point),'ci_low':float(np.quantile(values,.025)),'ci_high':float(np.quantile(values,.975)),'maps':len(names),'tasks':len(y),'bootstrap_replicates':1000})
    out=Path('analyses/additional_statistics');out.mkdir(exist_ok=True)
    pd.DataFrame(pairs).to_csv(out/'paired_model_comparisons.csv',index=False);pd.DataFrame(support).to_csv(out/'family_class_support.csv',index=False)
    (out/'metadata.json').write_text(json.dumps({'completed':True,'paired_differences':len(pairs),'resampling_unit':'whole map, shared draws for both models','interval':'95% percentile; descriptive, no multiple-comparison significance claim','split_dependence':'Five overlapping map partitions are not independent replications'},indent=2))
    print('Paired model comparisons and family class support completed',flush=True)

if __name__=='__main__':main()
