"""Small explicit Monte Carlo repeat check, not an attribution-convergence proof."""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path('../shap_dependencies').resolve()))
import shap,joblib,numpy as np,pandas as pd
from scipy.stats import spearmanr
from analysis_core import KEYS,aligned_probabilities
from features import FEATURES
from explain_selection import ExactIndependent

def main():
    dest=Path('analyses/shap');rows=[]
    for policy in ['strict','relaxed']:
        folder=Path('analyses')/policy/'seed_42';features=pd.read_csv('data/features_'+policy+'.csv')
        background=pd.read_csv(dest/(policy+'_42_background_keys.csv')).merge(features,on=KEYS)[FEATURES].to_numpy(float)
        sample=pd.read_csv(dest/(policy+'_42_explanation_keys.csv'))[KEYS].merge(features,on=KEYS,validate='one_to_one').sort_values(KEYS).drop_duplicates('family')
        model=joblib.load(folder/'ExtraTrees.joblib');values=[]
        for seed in [1042,2042,3042]:
            e=shap.PermutationExplainer(lambda x:aligned_probabilities(model,x),ExactIndependent(background,max_samples=25),seed=seed)
            r=e(sample[FEATURES].to_numpy(float),max_evals=390,silent=True)
            assert np.max(abs(r.base_values+r.values.sum(axis=1)-aligned_probabilities(model,sample[FEATURES].to_numpy(float))))<1e-9
            values.append(np.abs(r.values).mean(axis=(0,2)))
        for i in range(3):
            for j in range(i+1,3):rows.append({'policy':policy,'repeat_a':i,'repeat_b':j,'queries':len(sample),'rank_spearman':float(spearmanr(values[i],values[j]).statistic)})
    pd.DataFrame(rows).to_csv(dest/'small_cohort_permutation_repeat_check.csv',index=False)
    (dest/'sampling_check_note.json').write_text(json.dumps({'completed':True,'scope':'Three canonical seed-42 cases, one per family, same trained model and same 25-row background, three independent permutation seeds. This checks small-cohort Monte Carlo sensitivity only; it does not prove global attribution convergence.'},indent=2))
    print('Small-cohort permutation repeat checks completed',flush=True)

if __name__=='__main__':main()
