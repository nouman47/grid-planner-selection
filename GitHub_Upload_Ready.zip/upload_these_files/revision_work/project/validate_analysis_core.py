"""Small synthetic unit fixtures only; these are not research observations."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from analysis_core import PLANNERS,aggregate_repetitions,compute_utility,score_predictions,selective_table,cluster_interval,classification_intervals,policy_outcomes,temperature_probabilities
from audit_benchmark import sparse_oracle,segment_clear


def main():
    checks=[];rows=[]
    costs=[8.,4.,1.,2.,.5,10.];lengths=[5.,5.,6.,5.,5.,4.]
    for task in range(2):
        for i,name in enumerate(PLANNERS):
            for repetition in range(3):
                success=(task==0 and not(name=='weighted_astar' and repetition>0))
                rows.append({'map':'fixture_'+str(task),'start_x':0,'start_y':0,'goal_x':2,'goal_y':2,'family':'test_fixture',
                             'difficulty':'test_fixture','policy':'strict','planner':name,'repetition':repetition,
                             'success':success,'status':'solved' if success else 'no_path',
                             'runtime_ms':costs[i] if success else 12.,'path_length':lengths[i] if success else np.nan})
    aggregate=aggregate_repetitions(pd.DataFrame(rows),3);utilities,labels=compute_utility(aggregate)
    assert labels.iloc[0].best_planner=='jps';checks.append('utility winner uses corrected runtime and path objectives')
    assert not labels.iloc[1].label_valid and labels.iloc[1].best_planner is None;checks.append('all-failure task has no arbitrary class label')
    assert (utilities[utilities.success_rate==0].utility==0).all();checks.append('failures receive zero utility')
    _,length_labels=compute_utility(aggregate,(0.,0.,1.));assert length_labels.iloc[0].best_planner=='theta_star';checks.append('weight sensitivity changes appropriate preferred label')
    scores=score_predictions(np.arange(6),np.eye(6));assert scores['accuracy']==scores['macro_f1']==1. and scores['ece']==scores['brier']==0.;checks.append('perfect aligned six-class metrics')
    selection=selective_table(np.array([0,1]),np.array([[.6,.4,0,0,0,0],[.6,.4,0,0,0,0]]),[.5,.9])
    assert selection.iloc[0].n_accepted==2 and selection.iloc[0].selective_accuracy==.5 and selection.iloc[1].n_accepted==0 and np.isnan(selection.iloc[1].selective_accuracy);checks.append('selective metrics condition only on accepted tasks; empty acceptance stays undefined')
    assert cluster_interval([3.,3.,3.],['a','a','b'],20)==(3.,3.,3.);checks.append('cluster bootstrap retains constant mean')
    ci=classification_intervals(np.arange(6),np.arange(6),['a']*6,20)
    assert ci['accuracy_ci_low']==ci['accuracy_ci_high']==ci['macro_f1_ci_low']==ci['macro_f1_ci_high']==1.;checks.append('six-class confusion-matrix cluster bootstrap')
    task_frame=labels.iloc[:1];out=policy_outcomes(utilities[utilities['map']=='fixture_0'],task_frame,['jps'],[1.])
    assert out.iloc[0].runtime_ms==1.5 and out.iloc[0].utility<out.iloc[0].planning_only_utility;checks.append('selection overhead is charged to runtime and utility')
    p=np.array([[.1,.2,.1,.3,.1,.2]]);assert np.allclose(temperature_probabilities(p,1),p);checks.append('identity temperature transform')
    blocked=np.array([[False,True],[True,False]]);free=~blocked;tasks=[{'map':'test','start_x':0,'start_y':0,'goal_x':1,'goal_y':1}]
    assert np.isinf(next(iter(sparse_oracle(free,tasks,True).values()))) and np.isclose(next(iter(sparse_oracle(free,tasks,False).values())),np.sqrt(2));checks.append('independent graph oracle distinguishes strict and relaxed corner movement')
    assert not segment_clear(free,(0,0),(1,1),True) and segment_clear(free,(0,0),(1,1),False);checks.append('independent slab geometry distinguishes strict and relaxed corner contact')
    result={'passed':True,'checks':checks,'fixture_notice':'Synthetic unit-test fixtures only; never manuscript data'}
    Path('validation/analysis_core_validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))


if __name__=='__main__':main()
