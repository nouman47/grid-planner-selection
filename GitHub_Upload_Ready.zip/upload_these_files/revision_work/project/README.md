# Planner selection journal revision

This working package contains the revised benchmark foundation and its validation
evidence. It does not contain a finished revised manuscript or response letter.

From this directory:

```bash
python validate_planners.py
python features.py --policy strict --out data/features_strict.csv
python features.py --policy relaxed --out data/features_relaxed.csv
python validate_features.py
python run_benchmark.py --out results/pilot_check --policies both --start-method spawn
```

The supplied independent pilot evidence is in `results/pilot_v2/`. A fresh pilot
directory is required when regenerating it. `audit_pilot.py --runs PATH` performs
independent graph-distance and segment-collision checks. The full-run gate checks
the supplied pilot evidence and exact planner source hash.

Planned full experiment (Linux fork minimizes process startup; spawn is portable):

```bash
python run_benchmark.py --scenarios data/scenarios.csv --out results/full_v2 --policies both --repetitions 3 --timeout 10 --start-method fork --resume
```

This checkpoint already initializes full_v2 with 3,458 verified imported records.
The new writer uses one atomically closed JSON file per result, with provenance
for the original logging implementation retained. full_v1 is historical and must
not be resumed using the revised writer. Use the identical command above after
a clean interruption. Existing
outputs with different protocols or fatal records cannot be silently reused.

Read `EXPERIMENT_PROTOCOL.md` for measurement definitions, collision rules,
provenance requirements and the remaining analysis/manuscript gates.
