"""Reproduce and independently check the two supplementary summary extensions."""
from pathlib import Path
import json,re
import numpy as np,pandas as pd
from sklearn.metrics import f1_score
from analysis_core import KEYS,cluster_interval

def validate_or_write(frame,path,keys):
    if path.exists():
        old=pd.read_csv(path).sort_values(keys).reset_index(drop=True)
        new=frame[old.columns].sort_values(keys).reset_index(drop=True)
        pd.testing.assert_frame_equal(new,old,check_exact=False,rtol=1e-11,atol=1e-12,check_dtype=False)
    else:frame.to_csv(path,index=False)

def main():
    dest=Path('analyses/additional_statistics');dest.mkdir(exist_ok=True);rows=[]
    for policy in ['strict','relaxed']:
        for seed in [42,52,62,72,82]:
            for model in ['LogisticRegression','RandomForest','ExtraTrees','GradientBoosting','ExtraTreesBalanced','RandomForestBalanced']:
                d=pd.read_csv(f'analyses/{policy}/seed_{seed}/{model}_test_predictions.csv');d=d[d.label_valid]
                active=sorted(d.best_planner.unique())
                rows.append({'policy':policy,'seed':seed,'model':model,'test_supported_classes':len(active),'supported_class_macro_f1':f1_score(d.best_planner,d.predicted_planner,labels=active,average='macro',zero_division=0)})
    validate_or_write(pd.DataFrame(rows),dest/'supported_class_macro_f1.csv',['policy','seed','model'])
    rows=[]
    for stage in ['selection_timing','comparator_timing']:
        for path in sorted((Path('analyses')/stage).glob('*_outcomes.csv')):
            policy,seed,method,scope=re.fullmatch(r'(strict|relaxed)_(\d+)_(.*)_(cached|cold)_outcomes.csv',path.name).groups();seed=int(seed)
            outcome=pd.read_csv(path);baseline=pd.read_csv(f'analyses/{policy}/seed_{seed}/TrainingSingleBest_outcomes.csv')
            assert outcome[KEYS].equals(baseline[KEYS])
            for family,g in outcome.groupby('family'):
                for metric in ['utility','runtime_ms','success_rate']:
                    point,low,high=cluster_interval(g[metric].to_numpy()-baseline.loc[g.index,metric].to_numpy(),g['map'],1000,seed)
                    rows.append({'policy':policy,'seed':seed,'method':method,'scope':scope,'family':family,'metric':metric,'difference':point,'ci_low':low,'ci_high':high,'tasks':len(g),'maps':g['map'].nunique()})
    validate_or_write(pd.DataFrame(rows),dest/'charged_family_comparisons.csv',['policy','seed','method','scope','family','metric'])
    (Path('validation')/'supplementary_statistics_validation.json').write_text(json.dumps({'passed':True,'supported_class_rows':60,'charged_family_rows':len(rows),'independent_regeneration_matches_saved_values':True,'bootstrap_repetitions':1000,'bootstrap_seed':'partition seed','resampling_unit':'whole map'},indent=2))
    print('Supplementary tables exactly reproduced and validated')

if __name__=='__main__':main()
