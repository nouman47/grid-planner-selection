"""Independent pilot audit: graph shortest paths and slab segment collisions."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import numpy as np
from planners import Grid
from validate_planners import reference_distance,rectangle_clear


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--runs',default='results/pilot_v2/runs.jsonl');args=parser.parse_args()
    runs=[json.loads(line) for line in Path(args.runs).read_text().splitlines()];grids={};oracles={};errors=[];segments=0
    for r in runs:
        key=(r['map'],r['policy']);start=(r['start_x'],r['start_y']);goal=(r['goal_x'],r['goal_y']);strict=r['policy']=='strict'
        if key not in grids:grids[key]=Grid.load(Path('data/maps')/r['map'],strict)
        grid=grids[key];task=key+start+goal
        if task not in oracles:oracles[task]=reference_distance(grid.blocked,start,goal,strict)
        oracle=oracles[task];problem=[]
        if r['status'] in {'timeout','setup_timeout','worker_crash','error'}:problem.append(r['status'])
        elif r['success']!=math.isfinite(oracle):problem.append('reachability')
        if r['success']:
            path=r['path'];length=sum(math.dist(a,b) for a,b in zip(path,path[1:]))
            if tuple(path[0])!=start or tuple(path[-1])!=goal:problem.append('endpoints')
            if abs(length-r['path_length'])>1e-7:problem.append('geometric length')
            if r['planner'] in {'dijkstra','astar','bidirectional_astar','jps'} and abs(length-oracle)>1e-7:problem.append('not grid optimal')
            if r['planner']=='weighted_astar' and length>1.5*oracle+1e-7:problem.append('weighted bound')
            for a,b in zip(path,path[1:]):
                segments+=1;x0,x1=sorted([a[0],b[0]]);y0,y1=sorted([a[1],b[1]])
                crop=grid.blocked[y0:y1+1,x0:x1+1]
                aa=(a[0]-x0,a[1]-y0);bb=(b[0]-x0,b[1]-y0)
                if not rectangle_clear(crop,aa,bb,strict):problem.append('slab collision');break
        if problem:errors.append({'map':r['map'],'policy':r['policy'],'planner':r['planner'],'start':start,'goal':goal,'errors':problem})
    result={'runs':len(runs),'tasks_with_policy':len(oracles),'segments_checked':segments,'errors':errors,
            'passed':not errors,'runs_sha256':hashlib.sha256(Path(args.runs).read_bytes()).hexdigest(),
            'minimum_solved_length':min(r['path_length'] for r in runs if r['success']),
            'maximum_solved_length':max(r['path_length'] for r in runs if r['success']),
            'method':'Independent heap graph oracle and segment/rectangle slab intersection; obstacle subsets cover segment bounding boxes'}
    dest=Path(args.runs).parent/'independent_audit.json';dest.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
    return int(bool(errors))


if __name__=='__main__':raise SystemExit(main())
