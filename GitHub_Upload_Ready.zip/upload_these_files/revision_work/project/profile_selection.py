"""Direct raw-map feature and per-query selection timing, with cached/cold costs."""
import argparse,hashlib,json,os,time,platform
from pathlib import Path
import joblib,numpy as np,pandas as pd
from analysis_core import KEYS,PLANNERS,aligned_probabilities,temperature_probabilities,policy_outcomes,cluster_interval
from features import MapFeatures,FEATURES

def atomic_json(path,value):
    temp=path.with_suffix('.tmp')
    with temp.open('w') as f:json.dump(value,f);f.flush();os.fsync(f.fileno())
    temp.replace(path)

def main():
    dest=Path('analyses/selection_timing');dest.mkdir(exist_ok=True);records=dest/'records';records.mkdir(exist_ok=True)
    parser=argparse.ArgumentParser();parser.add_argument('--resume',action='store_true');args=parser.parse_args()
    files=sorted(records.glob('*.json'))
    if files and not args.resume:raise RuntimeError('Existing timing records: use explicit --resume')
    raw=[json.loads(f.read_bytes()) for f in files];restored=len(raw)
    identity=KEYS+['policy','seed','model','repetition']
    done={tuple(r[k] for k in identity) for r in raw}
    assert len(done)==len(raw)
    assert [f.name for f in files]==[f'{i:06d}.json' for i in range(len(files))]
    setup=[];summary=[];comparison=[];index=len(raw);hashes={}
    for policy in ['strict','relaxed']:
        root=Path('analyses')/policy;features=pd.read_csv('data/features_'+policy+'.csv');utilities=pd.read_csv(root/'planner_utilities.csv')
        for seed in [42,52,62,72,82]:
            folder=root/f'seed_{seed}';test=pd.read_csv(folder/'test_keys.csv').merge(features,on=KEYS,validate='one_to_one')
            models={name:joblib.load(folder/file) for name,file in [('ExtraTrees','ExtraTrees.joblib'),('TemperatureBaseModel','TemperatureBaseModel.joblib')]}
            for name,file in [('ExtraTrees','ExtraTrees.joblib'),('TemperatureBaseModel','TemperatureBaseModel.joblib')]:hashes[str(folder/file)]=hashlib.sha256((folder/file).read_bytes()).hexdigest()
            temperature=json.loads((folder/'calibration_split.json').read_text())['temperature']
            for model in models.values():model.predict_proba(test[FEATURES].to_numpy(float)[:1])
            for map_name,group in test.groupby('map',sort=True):
                prior=[r for r in raw if r['policy']==policy and r['seed']==seed and r['map']==map_name]
                expected_map=len(group)*len(models)*3
                if len(prior)==expected_map:continue
                if prior:
                    cold=float(prior[0]['map_preparation_median_ms'])
                    assert all(r['map_preparation_median_ms']==cold for r in prior)
                    context=MapFeatures(Path('data/maps')/map_name,policy=='strict');contexts=[context]
                else:
                    context=None
                contexts=[];map_times=[]
                for rep in range(0 if prior else 3):
                    begin=time.perf_counter_ns();context=MapFeatures(Path('data/maps')/map_name,policy=='strict');elapsed=(time.perf_counter_ns()-begin)/1e6
                    map_times.append(elapsed);contexts.append(context)
                    setup.append({'policy':policy,'seed':seed,'map':map_name,'repetition':rep,'map_preparation_ms':elapsed})
                if not prior:cold=float(np.median(map_times));context=contexts[-1]
                for task in group.to_dict('records'):
                    for name,model in models.items():
                        for rep in range(3):
                            task_identity=tuple(task[k] for k in KEYS)+(policy,seed,name,rep)
                            if task_identity in done:continue
                            begin=time.perf_counter_ns();data,_=context.extract(task);a=time.perf_counter_ns()
                            x=np.array([[data[n] for n in FEATURES]],dtype=float);b=time.perf_counter_ns()
                            prob=aligned_probabilities(model,x);c=time.perf_counter_ns()
                            if name=='TemperatureBaseModel':prob=temperature_probabilities(prob,temperature)
                            prediction=int(prob.argmax(axis=1)[0]);confidence=float(prob.max());fallback=prediction if confidence>=.5 else PLANNERS.index('weighted_astar');d=time.perf_counter_ns()
                            assert np.allclose(x[0],np.array([task[n] for n in FEATURES]),rtol=1e-10,atol=1e-10)
                            value={**{k:task[k] for k in KEYS},'policy':policy,'seed':seed,'model':name,'repetition':rep,
                                'feature_ms':(a-begin)/1e6,'vector_ms':(b-a)/1e6,'inference_ms':(c-b)/1e6,'decision_ms':(d-c)/1e6,
                                'cached_selection_ms':(d-begin)/1e6,'map_preparation_median_ms':cold,
                                'cold_selection_ms':(d-begin)/1e6+cold,'predicted_planner':PLANNERS[prediction],
                                'fallback_planner':PLANNERS[fallback],'confidence':confidence}
                            atomic_json(records/f'{index:06d}.json',value);raw.append(value);done.add(task_identity);index+=1
                del contexts,context
                print(policy,seed,map_name,'timing records',index,flush=True)
            current=pd.DataFrame(raw);current=current[(current.policy==policy)&(current.seed==seed)]
            baseline=pd.read_csv(folder/'TrainingSingleBest_outcomes.csv')
            for model_name,g in current.groupby('model'):
                grouped=g.groupby(KEYS,sort=False)
                assert (grouped.size()==3).all()
                for scope in ['cached','cold']:
                    median=grouped[scope+'_selection_ms'].median().reset_index();decisions=grouped[['predicted_planner','fallback_planner']].first().reset_index()
                    timed=test[KEYS].merge(median,on=KEYS,validate='one_to_one').merge(decisions,on=KEYS,validate='one_to_one')
                    assert timed[KEYS].equals(test[KEYS])
                    for use_fallback in [False,True]:
                        method=model_name+('_FixedFallback_0.5' if use_fallback else '')
                        choices=timed.fallback_planner if use_fallback else timed.predicted_planner
                        outcome=policy_outcomes(utilities,test,choices,overhead_ms=timed[scope+'_selection_ms'].to_numpy())
                        output=dest/f'{policy}_{seed}_{method}_{scope}_outcomes.csv';outcome.to_csv(output,index=False)
                        sr=outcome.success_rate.to_numpy();length=outcome.path_length.to_numpy();valid=(sr>0)&np.isfinite(length)
                        summary.append({'policy':policy,'seed':seed,'method':method,'scope':scope,'tasks':len(outcome),
                            'mean_selection_ms':float(timed[scope+'_selection_ms'].mean()),'success_rate':float(sr.mean()),
                            'mean_total_runtime_ms':float(outcome.runtime_ms.mean()),'mean_utility':float(outcome.utility.mean()),
                            'conditional_mean_path_length':float(np.average(length[valid],weights=sr[valid]))})
                        for col in ['runtime_ms','utility','success_rate']:
                            mean,lo,hi=cluster_interval(outcome[col].to_numpy()-baseline[col].to_numpy(),outcome['map'],1000,seed)
                            comparison.append({'policy':policy,'seed':seed,'method':method,'scope':scope,'metric':col,'policy_minus_training_single_best':mean,'ci_low':lo,'ci_high':hi})
    frame=pd.DataFrame(raw);expected=2*5*355*2*3
    assert len(frame)==expected and not frame.duplicated(KEYS+['policy','seed','model','repetition']).any()
    frame.to_csv(dest/'raw_timing.csv',index=False);pd.DataFrame(setup).to_csv(dest/'new_map_preparation_repetitions.csv',index=False)
    frame.groupby(['policy','seed','map']).map_preparation_median_ms.first().reset_index().to_csv(dest/'map_preparation_medians.csv',index=False)
    pd.DataFrame(summary).to_csv(dest/'charged_policy_summary.csv',index=False);pd.DataFrame(comparison).to_csv(dest/'paired_charged_comparisons.csv',index=False)
    atomic_json(dest/'manifest.json',{'completed':True,'records':len(frame),'expected':expected,'repetitions':3,'models_sha256':hashes,
        'restored_timing_records':restored,'new_timing_records':len(frame)-restored,
        'recovery_note':'Only missing query/model/repetition keys measured after interruption. Existing per-map setup medians reused for partially completed maps. Original raw map-setup repetitions were not all persisted; retained medians on immutable query records are authoritative.',
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'platform':platform.platform(),
        'cached':'Existing feature arrays for the map; raw task extraction, vector construction, model inference, probability transform and threshold decision timed per unique query.',
        'cold':'Cached query selection plus median measured map parsing/global feature preparation. Model already loaded; operating-system file caches not flushed; this is not cold-disk latency.',
        'deployment_scope':'Adds measured selection overhead to benchmark median search runtime; no robot, sensing, control, model loading or end-to-end live planner execution included.'})
    print('Direct selection timing completed',len(frame),flush=True)

if __name__=='__main__':main()
