"""Offline audit of complete benchmark: coverage, independent graph oracle,
path geometry, runtime contracts and provenance. Never treat a counter as data.
Run after benchmark completion to avoid competing with timed planner searches.
"""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra


KEYS=['map','start_x','start_y','goal_x','goal_y']
PLANNERS=('dijkstra','astar','weighted_astar','bidirectional_astar','jps','theta_star')
IDENTITY=KEYS+['planner','policy','repetition']


def independent_map(path):
    lines=Path(path).read_text().splitlines();start=lines.index('map');header=dict(line.split(maxsplit=1) for line in lines[:start])
    width,height=int(header['width']),int(header['height']);rows=lines[start+1:]
    if len(rows)!=height or any(len(row)!=width for row in rows):raise ValueError('Map dimensions')
    return np.array([[c in '.GS' for c in row] for row in rows],bool)


def sparse_oracle(free,tasks,strict):
    """Independent explicit weighted graph; SciPy shortest paths, not planner code."""
    height,width=free.shape;ids=np.arange(height*width).reshape(height,width);us=[];vs=[];weights=[]
    configurations=[(ids[:,:-1],ids[:,1:],free[:,:-1]&free[:,1:],1.),
                    (ids[:-1,:],ids[1:,:],free[:-1,:]&free[1:,:],1.)]
    diagonal=free[:-1,:-1]&free[1:,1:]
    other=free[:-1,1:]&free[1:,:-1]
    configurations.extend([(ids[:-1,:-1],ids[1:,1:],diagonal&other if strict else diagonal,math.sqrt(2)),
                           (ids[:-1,1:],ids[1:,:-1],other&diagonal if strict else other,math.sqrt(2))])
    for a,b,mask,cost in configurations:
        u=a[mask];v=b[mask];us.extend([u,v]);vs.extend([v,u]);weights.extend([np.full(len(u),cost),np.full(len(u),cost)])
    graph=coo_matrix((np.concatenate(weights),(np.concatenate(us),np.concatenate(vs))),shape=(height*width,)*2).tocsr()
    starts=sorted(set(int(row['start_y'])*width+int(row['start_x']) for row in tasks))
    distances=dijkstra(graph,directed=True,indices=starts);positions={n:i for i,n in enumerate(starts)}
    result={}
    for row in tasks:
        key=tuple(row[k] for k in KEYS);sx,sy,gx,gy=[int(row[k]) for k in KEYS[1:]]
        if not free[sy,sx] or not free[gy,gx]:raise ValueError('Invalid supplied scenario endpoint')
        result[key]=float(distances[positions[sy*width+sx],gy*width+gx])
    return result


def segment_clear(free,a,b,strict):
    """Independent vectorized segment/square slab intersection, not integer DDA."""
    x0,x1=sorted([a[0],b[0]]);y0,y1=sorted([a[1],b[1]])
    yy,xx=np.nonzero(~free[y0:y1+1,x0:x1+1]);xx=xx+x0;yy=yy+y0
    if not len(xx):return True
    lower=np.zeros(len(xx));upper=np.ones(len(xx))
    for av,bv,centres in zip(a,b,(xx,yy)):
        delta=bv-av
        if delta==0:
            outside=(av<centres-.5)|(av>centres+.5);lower[outside]=1;upper[outside]=0
        else:
            t1=(centres-.5-av)/delta;t2=(centres+.5-av)/delta
            lower=np.maximum(lower,np.minimum(t1,t2));upper=np.minimum(upper,np.maximum(t1,t2))
    collision=lower<=upper+1e-12 if strict else lower<upper-1e-12
    return not bool(collision.any())


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',default='results/full_v2');parser.add_argument('--maps',default='data/maps')
    parser.add_argument('--scenarios',default='data/scenarios.csv');parser.add_argument('--structural-only',action='store_true');args=parser.parse_args()
    folder=Path(args.run);protocol=json.loads((folder/'protocol.json').read_text());paths=sorted((folder/'records').glob('*.json'))
    scenarios=pd.read_csv(args.scenarios);policies=['strict','relaxed'] if protocol['policies']=='both' else [protocol['policies']]
    expected={tuple(r[k] for k in KEYS)+(p,policy,repetition) for r in scenarios.to_dict('records') for p in PLANNERS
              for policy in policies for repetition in range(protocol['repetitions'])}
    allowed={protocol['protocol_hash']}
    if protocol.get('import_lineage'):allowed.add(protocol['import_lineage']['protocol_hash'])
    errors=[];rows=[];seen=set();record_hash=hashlib.sha256()
    for path in paths:
        raw=path.read_bytes();record_hash.update(path.name.encode()+hashlib.sha256(raw).digest())
        try:r=json.loads(raw);key=tuple(r[k] for k in IDENTITY)
        except Exception as exc:errors.append({'file':path.name,'error':repr(exc)});continue
        if key in seen:errors.append({'file':path.name,'error':'duplicate identity'})
        if key not in expected:errors.append({'file':path.name,'error':'unexpected identity'})
        if r['protocol_hash'] not in allowed:errors.append({'file':path.name,'error':'unknown protocol lineage'})
        seen.add(key);rows.append({k:v for k,v in r.items() if k not in ['path','validation_errors']})
    missing=expected-seen
    structural={'records':len(paths),'unique_keys':len(seen),'expected':len(expected),'missing':len(missing),'errors':errors[:100],
                'record_set_sha256':record_hash.hexdigest(),'complete':not missing and not errors}
    if args.structural_only:
        print(json.dumps(structural,indent=2));return int(bool(errors))
    if not structural['complete']:
        print(json.dumps(structural,indent=2));print('Full audit blocked: benchmark is incomplete or structurally invalid.');return 2
    for name,h in protocol['sources'].items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=h:raise RuntimeError('Benchmark source changed: '+name)
    if hashlib.sha256(Path(args.scenarios).read_bytes()).hexdigest()!=protocol['scenario_sha256']:raise RuntimeError('Scenario hash changed')
    oracle={}
    for name,group in scenarios.groupby('map'):
        path=Path(args.maps)/name
        if hashlib.sha256(path.read_bytes()).hexdigest()!=protocol['map_sha256'][name]:raise RuntimeError('Map hash changed: '+name)
        free=independent_map(path)
        for policy in policies:
            values=sparse_oracle(free,group.to_dict('records'),policy=='strict')
            oracle.update({key+(policy,):value for key,value in values.items()})
        print('Independent graph oracle:',name,flush=True)
    cached=None;free=None;segments=0;solved=0
    for path in paths:
        r=json.loads(path.read_bytes());key=tuple(r[k] for k in KEYS);problem=[];points=r['path'];strict=r['policy']=='strict'
        if cached!=r['map']:free=independent_map(Path(args.maps)/r['map']);cached=r['map']
        reference=oracle[key+(r['policy'],)];start=(r['start_x'],r['start_y']);goal=(r['goal_x'],r['goal_y'])
        status=r['status'];success=bool(r['success']);runtime=r.get('runtime_ms')
        if status not in ['solved','no_path','timeout']:problem.append('non-research status: '+status)
        if success!=(status=='solved'):problem.append('status/success disagreement')
        if runtime is None or not math.isfinite(runtime) or runtime<=0 or runtime>protocol['timeout_s']*1000+1e-6:problem.append('runtime outside measurement contract')
        if status=='no_path' and math.isfinite(reference):problem.append('false no-path result')
        if success:
            solved+=1
            if not points or tuple(points[0])!=start or tuple(points[-1])!=goal:problem.append('path endpoints')
            if len({tuple(v) for v in points})!=len(points):problem.append('path cycle')
            height,width=free.shape
            if any(not(0<=x<width and 0<=y<height) or not free[y,x] for x,y in points):problem.append('blocked/outside waypoint')
            length=sum(math.dist(a,b) for a,b in zip(points,points[1:]))
            if r['path_length'] is None or not math.isclose(length,r['path_length'],rel_tol=1e-9,abs_tol=1e-6):problem.append('recorded length mismatch')
            if length<math.dist(start,goal)-1e-6:problem.append('shorter than straight line')
            if not math.isfinite(reference):problem.append('solved disconnected graph')
            if r['planner'] in {'dijkstra','astar','bidirectional_astar','jps'} and not math.isclose(length,reference,rel_tol=1e-9,abs_tol=1e-6):problem.append('grid-optimality violation')
            if r['planner']=='weighted_astar' and length>1.5*reference+1e-6:problem.append('Weighted A* bound violation')
            if not problem:
                for a,b in zip(points,points[1:]):
                    segments+=1;dx=abs(a[0]-b[0]);dy=abs(a[1]-b[1])
                    if r['planner']!='theta_star':
                        if max(dx,dy)!=1:problem.append('nonadjacent discrete step');break
                        if strict and dx and dy and (not free[a[1],b[0]] or not free[b[1],a[0]]):problem.append('corner cutting');break
                    elif not segment_clear(free,a,b,strict):problem.append('independent segment collision');break
        elif points or r['path_length'] is not None:problem.append('failed run carries path/length')
        if problem:errors.append({'file':path.name,'errors':problem})
    report={**structural,'errors':errors[:200],'error_count':len(errors),'passed':not errors,'solved_runs':solved,
            'independent_oracle_tasks_with_policy':len(oracle),'segments_checked':segments,
            'protocol_hash':protocol['protocol_hash'],'audit_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'method':'Complete-key coverage, independent SciPy graph shortest paths, independent slab geometry for Theta*, direct discrete-step checks'}
    (folder/'audit.json').write_text(json.dumps(report,indent=2))
    if not errors:
        pd.DataFrame(rows).to_csv(folder/'audited_runs.csv',index=False)
        pd.DataFrame([{**dict(zip(KEYS,key[:-1])),'policy':key[-1],'oracle_distance':value} for key,value in oracle.items()]).to_csv(folder/'independent_oracle.csv',index=False)
        report['audited_runs_sha256']=hashlib.sha256((folder/'audited_runs.csv').read_bytes()).hexdigest()
        report['independent_oracle_sha256']=hashlib.sha256((folder/'independent_oracle.csv').read_bytes()).hexdigest()
        (folder/'audit.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2));return int(bool(errors))


if __name__=='__main__':raise SystemExit(main())
