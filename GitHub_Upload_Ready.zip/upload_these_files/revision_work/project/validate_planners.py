"""Independent small-graph oracle and geometric checks; never fit models.

Validation of optimality applies to grid-optimal planners only. Weighted A*
is checked against its 1.5 bound; Theta* is checked for validity, never claimed
globally optimal. Segment geometry is checked by a separate rectangle oracle.
"""
import heapq
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import numpy as np
from planners import Grid, PLANNERS, search


def reference_distance(blocked,start,goal,strict):
    height,width=blocked.shape
    def free(x,y):return 0<=x<width and 0<=y<height and not bool(blocked[y,x])
    if not free(*start) or not free(*goal):return math.inf
    distances={start:0.0};q=[(0.0,start)]
    while q:
        distance,node=heapq.heappop(q)
        if distance != distances[node]:continue
        if node==goal:return distance
        for x in range(node[0]-1,node[0]+2):
            for y in range(node[1]-1,node[1]+2):
                if (x,y)==node or not free(x,y):continue
                if strict and x!=node[0] and y!=node[1] and (not free(x,node[1]) or not free(node[0],y)):continue
                candidate=distance+math.hypot(x-node[0],y-node[1])
                if candidate<distances.get((x,y),math.inf):
                    distances[x,y]=candidate;heapq.heappush(q,(candidate,(x,y)))
    return math.inf


def rectangle_clear(blocked,a,b,strict):
    """Independent slab intersection with blocked cell squares, centre coords.

    Exact corner contact is excluded in relaxed mode and forbidden in strict.
    Integer-centre segments cannot coincide with half-integer cell boundaries.
    """
    for y,x in np.argwhere(blocked):
        low,high=0.0,1.0
        for av,bv,c in zip(a,b,(int(x),int(y))):
            dv=bv-av
            if dv==0:
                if not c-.5<=av<=c+.5:low,high=1.0,0.0;break
            else:
                t1,t2=(c-.5-av)/dv,(c+.5-av)/dv
                low=max(low,min(t1,t2));high=min(high,max(t1,t2))
        if (low<=high+1e-12 if strict else low<high-1e-12):return False
    return True


def check_result(result,blocked,start,goal,strict,oracle):
    errors=[];path=result['path'];success=result['success'];name=result['planner']
    if success != math.isfinite(oracle):errors.append('reachability mismatch')
    if not success:
        if path or result['path_length'] is not None:errors.append('failure fields')
        return errors
    if path[0]!=start or path[-1]!=goal:errors.append('endpoints')
    if len(set(path))!=len(path):errors.append('cycle')
    height,width=blocked.shape
    if any(not(0<=x<width and 0<=y<height) or blocked[y,x] for x,y in path):errors.append('blocked waypoint')
    for a,b in zip(path,path[1:]):
        if name!='theta_star' and max(abs(a[0]-b[0]),abs(a[1]-b[1]))!=1:errors.append('nonadjacent grid step')
        if not rectangle_clear(blocked,a,b,strict):errors.append('segment collision')
    length=sum(math.dist(a,b) for a,b in zip(path,path[1:]))
    if abs(length-result['path_length'])>1e-8:errors.append('length mismatch')
    if length<math.dist(start,goal)-1e-8:errors.append('below Euclidean')
    if name in {'dijkstra','astar','bidirectional_astar','jps'} and abs(length-oracle)>1e-8:errors.append('suboptimal grid path')
    if name=='weighted_astar' and length>1.5*oracle+1e-8:errors.append('weighted bound')
    return errors


def main():
    rng=random.Random(20261030);cases=[]
    # Exhaustive obstacle configurations on 3x3; multiple query orientations.
    for mask in range(512):
        blocked=np.array([(mask>>i)&1 for i in range(9)],dtype=bool).reshape(3,3)
        cases.append((f'exhaustive3_{mask}',blocked,(0,0),(2,2)))
        cases.append((f'exhaustive3_cross_{mask}',blocked,(2,0),(0,2)))
    for i in range(200):
        height=rng.randint(4,12);width=rng.randint(4,14)
        blocked=np.array([rng.random()<.30 for _ in range(height*width)]).reshape(height,width)
        start=(rng.randrange(width),rng.randrange(height));goal=(rng.randrange(width),rng.randrange(height))
        blocked[start[1],start[0]]=False;blocked[goal[1],goal[0]]=False
        cases.append((f'random_{i}',blocked,start,goal))
    cases.extend([
        ('same_cell',np.zeros((3,5),bool),(2,1),(2,1)),
        ('long_corridor',np.zeros((1,1500),bool),(0,0),(1499,0)),
        ('disconnected',np.array([[0,1,0],[0,1,0],[0,1,0]],bool),(0,0),(2,2)),
        ('corner',np.array([[0,1],[1,0]],bool),(0,0),(1,1)),
        ('rectangular',np.zeros((4,13),bool),(12,3),(0,0))])
    failures=[];counts={name:0 for name in PLANNERS};los_checks=0
    for strict in (True,False):
        for case,blocked,start,goal in cases:
            oracle=reference_distance(blocked,start,goal,strict);grid=Grid(blocked,strict)
            for name in PLANNERS:
                try:
                    result=search(name,grid,start,goal)
                    errors=check_result(result,blocked,start,goal,strict,oracle)
                except Exception as exc:errors=[repr(exc)]
                counts[name]+=1
                if errors:failures.append({'case':case,'strict':strict,'planner':name,'errors':errors})
        # Exhaustive segment endpoints over several nontrivial small masks.
        for mask in range(0,512,7):
            blocked=np.array([(mask>>i)&1 for i in range(9)],bool).reshape(3,3)
            grid=Grid(blocked,strict)
            for a,b in itertools.product(itertools.product(range(3),repeat=2),repeat=2):
                expected=rectangle_clear(blocked,a,b,strict)
                actual=grid.visible(a,b);los_checks+=1
                if actual!=expected:failures.append({'case':f'los_{mask}','strict':strict,'a':a,'b':b,'errors':['LOS mismatch']})
    result={'cases_per_policy':len(cases),'policies':2,'searches':sum(counts.values()),
            'per_planner':counts,'los_checks':los_checks,'failures':failures,
            'source_sha256':hashlib.sha256(Path('planners.py').read_bytes()).hexdigest(),
            'passed':not failures,'method':'Independent graph shortest-path and rectangle-intersection checks; finite validation suite, not a general proof'}
    Path('validation').mkdir(exist_ok=True);Path('validation/planner_validation.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='failures'},indent=2))
    print('Failures:',len(failures));print(json.dumps(failures[:12],indent=2))
    return int(bool(failures))


if __name__=='__main__':raise SystemExit(main())
