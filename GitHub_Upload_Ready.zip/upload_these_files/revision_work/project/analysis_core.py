"""Task-level utility, confidence and clustered uncertainty definitions.

Functions are side-effect free. Tests may use synthetic fixtures, but research
outputs must come exclusively from a complete independently audited benchmark.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score,f1_score

KEYS=['map','start_x','start_y','goal_x','goal_y']
PLANNERS=('dijkstra','astar','weighted_astar','bidirectional_astar','jps','theta_star')
WEIGHTS=(.2,.5,.3)


def aggregate_repetitions(runs,expected_repetitions):
    """Median budget-capped runtime; success frequency; conditional path length.

    A timeout contributes the full budget to runtime. Success frequency is the
    fraction of repetitions with validated paths. No-path runtime is its actual
    measured search time. Unsuccessful runs never supply a zero path length.
    """
    group_keys=KEYS+['policy','planner'];rows=[]
    for key,g in runs.groupby(group_keys,sort=True):
        if len(g)!=expected_repetitions or g.repetition.nunique()!=expected_repetitions:raise ValueError('Incomplete repeated outcome')
        good=g[g['success'].astype(bool)]
        length=float(good.path_length.median()) if len(good) else np.nan
        if len(good) and not np.allclose(good.path_length,length,rtol=1e-9,atol=1e-6):raise ValueError('Deterministic planner returned different path costs across repetitions')
        rows.append({**dict(zip(group_keys,key)),'family':g.iloc[0]['family'],'difficulty':g.iloc[0]['difficulty'],
                     'success_rate':len(good)/len(g),'runtime_ms':float(g.runtime_ms.median()),
                     'path_length':length,'repetitions':len(g),'timeout_count':int((g.status=='timeout').sum())})
    return pd.DataFrame(rows)


def inverse_normalize(values):
    values=np.asarray(values,float)
    if not len(values) or not np.isfinite(values).all():raise ValueError('Normalization requires finite values')
    lo,hi=values.min(),values.max()
    return np.ones(len(values)) if hi==lo else (hi-values)/(hi-lo)


def compute_utility(aggregated,weights=WEIGHTS):
    ws,wr,wl=weights
    if min(weights)<0 or not np.isclose(sum(weights),1):raise ValueError('Nonnegative weights summing to one required')
    result=aggregated.copy();result['runtime_score']=0.;result['length_score']=0.;result['utility']=0.
    for _,g in result.groupby(KEYS+['policy'],sort=False):
        if set(g.planner)!=set(PLANNERS) or len(g)!=len(PLANNERS):raise ValueError('Six distinct planner outcomes required per task')
        good=g[g.success_rate>0]
        if not len(good):continue
        rt=inverse_normalize(good.runtime_ms);length=inverse_normalize(good.path_length)
        result.loc[good.index,'runtime_score']=rt;result.loc[good.index,'length_score']=length
        result.loc[good.index,'utility']=ws*good.success_rate.to_numpy()+wr*rt+wl*length
    labels=[]
    order={name:i for i,name in enumerate(PLANNERS)}
    for key,g in result.groupby(KEYS+['policy'],sort=True):
        good=g[g.success_rate>0].copy()
        if len(good):
            good['_order']=good.planner.map(order)
            best=good.sort_values(['utility','runtime_ms','path_length','_order'],ascending=[False,True,True,True]).iloc[0]
            label=best.planner;utility=float(best.utility)
        else:label=None;utility=0.
        labels.append({**dict(zip(KEYS+['policy'],key)),'best_planner':label,'best_utility':utility,'label_valid':bool(len(good)),
                       'n_planners_with_success':len(good),'family':g.iloc[0]['family'],'difficulty':g.iloc[0]['difficulty']})
    return result,pd.DataFrame(labels)


def score_predictions(y,probabilities):
    y=np.asarray(y,int);p=np.asarray(probabilities,float)
    if len(y)==0:return {'n':0,'accuracy':np.nan,'macro_f1':np.nan,'brier':np.nan,'ece':np.nan}
    if p.shape!=(len(y),6) or not np.allclose(p.sum(axis=1),1):raise ValueError('Six aligned probabilities per task required')
    pred=p.argmax(axis=1);confidence=p.max(axis=1);one_hot=np.eye(6)[y];ece=0.
    edges=np.linspace(0,1,11)
    for i in range(10):
        mask=(confidence>=edges[i])&((confidence<=edges[i+1]) if i==9 else (confidence<edges[i+1]))
        if mask.any():ece+=mask.mean()*abs((pred[mask]==y[mask]).mean()-confidence[mask].mean())
    return {'n':len(y),'accuracy':accuracy_score(y,pred),'macro_f1':f1_score(y,pred,labels=np.arange(6),average='macro',zero_division=0),
            'brier':float(np.square(p-one_hot).sum(axis=1).mean()),'ece':float(ece),'mean_confidence':float(confidence.mean())}


def selective_table(y,probabilities,thresholds=None):
    y=np.asarray(y,int);p=np.asarray(probabilities,float);confidence=p.max(axis=1);pred=p.argmax(axis=1)
    # Integer division gives the same float as a declared decimal cutoff (e.g.
    # 0.6), unlike linspace's 0.6000000000000001, which can reject boundary cases.
    thresholds=np.arange(21,dtype=float)/20 if thresholds is None else thresholds;rows=[]
    for threshold in thresholds:
        mask=confidence>=threshold;n=int(mask.sum());accuracy=float((pred[mask]==y[mask]).mean()) if n else np.nan
        rows.append({'threshold':float(threshold),'n_total':len(y),'n_accepted':n,'coverage':n/len(y) if len(y) else np.nan,
                     'selective_accuracy':accuracy,'risk':1-accuracy if n else np.nan})
    return pd.DataFrame(rows)


def cluster_interval(values,groups,repetitions=1000,seed=20261030):
    """Percentile CI for a task-weighted mean, resampling whole maps."""
    values=np.asarray(values,float);groups=np.asarray(groups)
    keep=np.isfinite(values);values=values[keep];groups=groups[keep];names=np.unique(groups)
    if not len(names):return (np.nan,np.nan,np.nan)
    sums=np.array([values[groups==g].sum() for g in names]);counts=np.array([(groups==g).sum() for g in names]);rng=np.random.default_rng(seed)
    draws=rng.integers(0,len(names),size=(repetitions,len(names)));samples=sums[draws].sum(axis=1)/counts[draws].sum(axis=1)
    return float(values.mean()),float(np.quantile(samples,.025)),float(np.quantile(samples,.975))


def classification_intervals(y,pred,groups,repetitions=1000,seed=20261030):
    """Whole-map bootstrap CIs from per-map six-class confusion matrices."""
    y=np.asarray(y,int);pred=np.asarray(pred,int);names,inverse=np.unique(np.asarray(groups),return_inverse=True)
    if not len(y):return {'accuracy_ci_low':np.nan,'accuracy_ci_high':np.nan,'macro_f1_ci_low':np.nan,'macro_f1_ci_high':np.nan,'ci_maps':0}
    if len(y)!=len(pred) or len(y)!=len(inverse):raise ValueError('Misaligned classification bootstrap')
    matrices=np.zeros((len(names),6,6),int);np.add.at(matrices,(inverse,y,pred),1)
    rng=np.random.default_rng(seed);draws=rng.integers(0,len(names),size=(repetitions,len(names)));sample=matrices[draws].sum(axis=1)
    tp=np.diagonal(sample,axis1=1,axis2=2);denom=sample.sum(axis=1)+sample.sum(axis=2)
    f1=np.divide(2*tp,denom,out=np.zeros_like(tp,dtype=float),where=denom>0).mean(axis=1)
    accuracy=tp.sum(axis=1)/sample.sum(axis=(1,2))
    return {'accuracy_ci_low':float(np.quantile(accuracy,.025)),'accuracy_ci_high':float(np.quantile(accuracy,.975)),
            'macro_f1_ci_low':float(np.quantile(f1,.025)),'macro_f1_ci_high':float(np.quantile(f1,.975)),'ci_maps':len(names)}


def aligned_probabilities(model,x):
    raw=model.predict_proba(x);aligned=np.zeros((len(x),6))
    aligned[:,np.asarray(model.classes_,int)]=raw
    return aligned


def temperature_probabilities(p,temperature):
    logits=np.log(np.clip(np.asarray(p,float),1e-12,1))/temperature
    logits-=logits.max(axis=1,keepdims=True);exp=np.exp(logits);return exp/exp.sum(axis=1,keepdims=True)


def policy_outcomes(utilities,task_frame,selections,overhead_ms=None,weights=WEIGHTS):
    """Score chosen planners on common tasks; charge overhead in runtime utility.

    Utilities use the same per-task successful-candidate normalization. Additional
    selection overhead increases runtime and lowers its normalized component,
    clipped to [0,1]. Tied runtime ranges retain 1 for zero overhead and become
    zero for positive overhead. Report both planning-only and charged utility.
    """
    tasks=task_frame[KEYS].reset_index(drop=True).copy()
    if len(tasks)!=len(selections):raise ValueError('Policy selections do not align with tasks')
    if tasks.duplicated(KEYS).any():raise ValueError('Duplicate decision tasks')
    tasks['planner']=list(selections);tasks['_order']=np.arange(len(tasks))
    out=tasks.merge(utilities,on=KEYS+['planner'],how='left',validate='one_to_one').sort_values('_order')
    if out.utility.isna().any():raise ValueError('Missing policy outcome')
    overhead=np.zeros(len(out)) if overhead_ms is None else np.broadcast_to(np.asarray(overhead_ms,float),len(out))
    out['planning_runtime_ms']=out.runtime_ms;out['overhead_ms']=overhead;out['runtime_ms']=out.runtime_ms+overhead
    out['planning_only_utility']=out.utility
    ranges=utilities[utilities.success_rate>0].groupby(KEYS).runtime_ms.agg(['min','max'])
    out=out.join(ranges,on=KEYS)
    delta=(out['max']-out['min']).to_numpy();rt=out.runtime_score.to_numpy().copy()
    varied=delta>0;rt[varied]=np.clip(rt[varied]-overhead[varied]/delta[varied],0,1)
    rt[(delta==0)&(overhead>0)]=0;rt[out.success_rate.to_numpy()==0]=0
    ws,wr,wl=weights;out['utility']=np.where(out.success_rate>0,ws*out.success_rate+wr*rt+wl*out.length_score,0.)
    return out.drop(columns=['min','max','_order'])
