"""Preplanning features with explicit per-task alignment and definitions.

No planner outcomes, family labels or task difficulty are model inputs.
Arrays use [y,x]; coordinates are (column,row). Local radius 5 means an 11x11
window, including its free centre. Exterior cells are occupied. Clearance is
Euclidean distance to a blocked-cell centre, with a one-cell blocked exterior.
"""
from pathlib import Path
import hashlib
import json
import time
import numpy as np
import pandas as pd
from scipy.ndimage import distance_transform_edt,label,uniform_filter
from planners import Grid

KEYS=['map','start_x','start_y','goal_x','goal_y']
GROUPS={
    'navigation':['start_x','start_y','goal_x','goal_y','euclidean_distance','manhattan_distance'],
    'environment':['width','height','free_space_ratio','obstacle_density','start_clearance','goal_clearance','start_local_density','goal_local_density'],
    'topology':['map_area','aspect_ratio','free_cells','start_component_ratio','mean_free_degree4']}
FEATURES=sum(GROUPS.values(),[])


class MapFeatures:
    def __init__(self,path,strict=True,radius=5):
        t=time.perf_counter();self.grid=Grid.load(path,strict);free=~self.grid.blocked;h,w=free.shape
        padded=np.pad(free,1,constant_values=False)
        self.clearance=distance_transform_edt(padded)[1:-1,1:-1]
        self.density=uniform_filter(self.grid.blocked.astype(float),size=2*radius+1,mode='constant',cval=1.0)
        structure=np.array([[0,1,0],[1,1,1],[0,1,0]],int) if strict else np.ones((3,3),int)
        self.components,n_components=label(free,structure=structure)
        self.component_sizes=np.bincount(self.components.ravel());nfree=int(free.sum())
        edges=(free[:,:-1]&free[:,1:]).sum()+(free[:-1,:]&free[1:,:]).sum()
        self.global_features={'width':w,'height':h,'map_area':w*h,'aspect_ratio':w/h,
                              'free_cells':nfree,'free_space_ratio':nfree/(w*h),'obstacle_density':1-nfree/(w*h),
                              'mean_free_degree4':float(2*edges/nfree) if nfree else 0.0}
        self.setup_ms=(time.perf_counter()-t)*1000

    def extract(self,row):
        t=time.perf_counter();sx,sy,gx,gy=[int(row[c]) for c in KEYS[1:]]
        if not self.grid.free(sx,sy) or not self.grid.free(gx,gy):raise ValueError('Scenario endpoint is not traversable')
        delta=np.hypot(gx-sx,gy-sy);component=self.components[sy,sx]
        data={**self.global_features,'start_x':sx,'start_y':sy,'goal_x':gx,'goal_y':gy,
              'euclidean_distance':float(delta),'manhattan_distance':abs(gx-sx)+abs(gy-sy),
              'start_clearance':float(self.clearance[sy,sx]),'goal_clearance':float(self.clearance[gy,gx]),
              'start_local_density':float(self.density[sy,sx]),'goal_local_density':float(self.density[gy,gx]),
              'start_component_ratio':float(self.component_sizes[component]/self.global_features['free_cells'])}
        return data,(time.perf_counter()-t)*1000


def main():
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--scenarios',default='data/scenarios.csv')
    parser.add_argument('--maps',default='data/maps');parser.add_argument('--policy',choices=['strict','relaxed'],default='strict')
    parser.add_argument('--out',default='data/features_strict.csv');args=parser.parse_args()
    scenarios=pd.read_csv(args.scenarios);rows=[]
    for name,group in scenarios.groupby('map',sort=True):
        context=MapFeatures(Path(args.maps)/name,args.policy=='strict')
        for row in group.to_dict('records'):
            features,elapsed=context.extract(row)
            rows.append({**{k:row[k] for k in KEYS},'family':row['family'],'difficulty':row['difficulty'],**features,
                         'map_setup_ms':context.setup_ms,'cached_task_feature_ms':elapsed,'policy':args.policy})
    frame=pd.DataFrame(rows)
    if frame[KEYS].duplicated().any():raise ValueError('Duplicate task key')
    if frame[FEATURES].isna().any().any() or not np.isfinite(frame[FEATURES].to_numpy()).all():raise ValueError('Nonfinite feature')
    if len(frame)!=len(scenarios):raise ValueError('Task count mismatch')
    out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True);frame.to_csv(out,index=False)
    meta={'scenario_sha256':hashlib.sha256(Path(args.scenarios).read_bytes()).hexdigest(),
          'feature_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'rows':len(frame),'features':FEATURES,'groups':GROUPS,'policy':args.policy,'local_radius':5,
          'clearance':'Euclidean distance to blocked-cell centre including blocked one-cell exterior',
          'start_component':'4-connected for strict, 8-connected for relaxed; start component/free cells',
          'mean_free_degree4':'2 times undirected orthogonal free/free edge count divided by free cells',
          'timing':'Map loading/global arrays measured once per map; cached local extraction once per unique task; neither includes model inference'}
    out.with_suffix('.metadata.json').write_text(json.dumps(meta,indent=2));print('Saved',out,len(frame),'tasks',len(FEATURES),'features')


if __name__=='__main__':main()
