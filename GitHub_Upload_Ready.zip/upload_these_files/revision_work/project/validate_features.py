"""Feature checks against brute-force independent definitions on small maps."""
import json
import math
from pathlib import Path
import random
import tempfile
import numpy as np
from features import MapFeatures


def main():
    rng=random.Random(7182);checks=0;failures=[]
    with tempfile.TemporaryDirectory() as tmp:
        path=Path(tmp)/'fixture.map'
        for fixture in range(20):
            a=np.array([rng.random()<.25 for _ in range(48)],bool).reshape(6,8);a[0,0]=False;a[5,7]=False
            path.write_text('type octile\nheight 6\nwidth 8\nmap\n'+'\n'.join(''.join('@' if v else '.' for v in row) for row in a)+'\n')
            for strict in (True,False):
                context=MapFeatures(path,strict)
                for sx,sy in [(0,0),(7,5)]:
                    row={'start_x':sx,'start_y':sy,'goal_x':7-sx,'goal_y':5-sy};f,_=context.extract(row)
                    obstacle_centres=[(x,y) for y in range(-1,7) for x in range(-1,9) if not(0<=x<8 and 0<=y<6) or a[y,x]]
                    clearance=min(math.hypot(x-sx,y-sy) for x,y in obstacle_centres)
                    occupied=sum(not(0<=x<8 and 0<=y<6) or a[y,x] for y in range(sy-5,sy+6) for x in range(sx-5,sx+6))/121
                    seen={(sx,sy)};stack=[(sx,sy)]
                    while stack:
                        x,y=stack.pop()
                        for dx in (-1,0,1):
                            for dy in (-1,0,1):
                                if (not dx and not dy) or (strict and dx and dy):continue
                                n=(x+dx,y+dy)
                                if 0<=n[0]<8 and 0<=n[1]<6 and not a[n[1],n[0]] and n not in seen:
                                    seen.add(n);stack.append(n)
                    expected={'start_clearance':clearance,'start_local_density':occupied,'start_component_ratio':len(seen)/int((~a).sum())}
                    for key,v in expected.items():
                        checks+=1
                        if abs(f[key]-v)>1e-10:failures.append({'fixture':fixture,'strict':strict,'feature':key,'expected':v,'actual':f[key]})
    real=__import__('pandas').read_csv('data/features_strict.csv')
    if len(real)!=1405 or real[['map','start_x','start_y','goal_x','goal_y']].duplicated().any():failures.append({'error':'real task keys'})
    variation={c:int((real.groupby('map')[c].nunique()>1).sum()) for c in ['start_clearance','goal_clearance','start_local_density','goal_local_density']}
    result={'independent_feature_comparisons':checks,'real_task_rows':len(real),'maps':real['map'].nunique(),
            'maps_with_task_local_variation':variation,'failures':failures,'passed':not failures}
    Path('validation/feature_validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
    return int(bool(failures))


if __name__=='__main__':raise SystemExit(main())
