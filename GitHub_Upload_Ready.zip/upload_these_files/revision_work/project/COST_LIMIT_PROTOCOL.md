# Retrospective analysis of decision cost limits

This is an explanatory diagnostic of previously inspected evidence. It is not a
new confirmatory test, a tuned deployment gate or a claim of fundamental novelty.
No model, planner, test partition, objective weight or timing record is changed.

For each original map split and collision rule, compare the saved Extra Trees,
Logistic Regression and Gradient Boosting choices with the fixed planner selected
on training maps. Use both existing cached and cold-feature charged outcomes.
Align by the full map/start/goal key. Reconstruct the original utility charge
independently from the successful-candidate runtime span and compare every value
with the saved charged outcome.

For positive span dT, let D be planning-only utility minus fixed-planner utility,
R the selected planner's original runtime score and c the selection overhead.
Then the charged gain is D - 0.5 min(c/dT, R). If D>0 and D<=0.5R, a strictly
positive gain requires c<2dT D. If D>0.5R, the clipped runtime penalty alone cannot
remove the gain: this is saturation of the declared utility, not a claim that
arbitrarily large latency is acceptable. If D<=0, overhead cannot create a gain.
For zero span, apply the original discontinuous tie convention separately.

Report planning-only winning tasks, those still strictly winning after measured
cost, finite positive cost limits and actual decision costs. Primary seed-42
tables use all 355 tasks; conditional counts and median-limit denominators are
explicit. Other splits, family strata and map-bootstrap intervals are in S1.
Use a 1e-12 numerical tie tolerance consistently. Related/overlapping map splits
are not independent replications. Limits use observed counterfactual planner
outcomes and therefore cannot be used before search without another predictor.

This analysis explains the observed overhead sensitivity under the paper's
within-task normalized utility. It does not establish a new optimizer, physical
feasibility, a runtime deadline or performance under a different application loss.
