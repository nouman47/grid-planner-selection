"""Replay utility-regression and calibration models against saved outputs."""
from pathlib import Path
import hashlib,json,gc
import joblib,numpy as np,pandas as pd
from sklearn.metrics import accuracy_score,f1_score
from analysis_core import KEYS,PLANNERS,aligned_probabilities,temperature_probabilities,score_predictions
from features import FEATURES

def main():
    rows=[]
    for policy in ['strict','relaxed']:
        features=pd.read_csv(f'data/features_{policy}.csv');metrics=pd.read_csv(f'analyses/{policy}/model_comparison.csv');cal=pd.read_csv(f'analyses/{policy}/temperature_calibration.csv')
        labels=pd.read_csv(f'analyses/{policy}/task_labels.csv')
        for seed in [42,52,62,72,82]:
            folder=Path(f'analyses/{policy}/seed_{seed}');test=pd.read_csv(folder/'test_keys.csv')
            frame=test.merge(features,on=KEYS,validate='one_to_one');x=frame[FEATURES].to_numpy(float)
            yframe=test.merge(labels,on=KEYS,validate='one_to_one');valid=yframe.label_valid.to_numpy(bool)
            y=yframe.best_planner.map({n:i for i,n in enumerate(PLANNERS)}).fillna(-1).to_numpy(int)
            path=folder/'UtilityRegression.joblib';model=joblib.load(path);pred=model.predict(x);saved=pd.read_csv(folder/'UtilityRegression_test_predictions.csv')
            assert saved[KEYS].equals(test[KEYS]) and np.allclose(pred,saved[['predicted_utility_'+n for n in PLANNERS]],atol=1e-12,rtol=1e-12)
            choices=pred.argmax(axis=1);outcome=pd.read_csv(folder/'UtilityRegression_outcomes.csv');assert np.array_equal(np.array(PLANNERS)[choices],outcome.planner)
            m=metrics[(metrics.seed==seed)&(metrics.model=='UtilityRegression')].iloc[0]
            assert np.isclose(m.accuracy,accuracy_score(y[valid],choices[valid])) and np.isclose(m.macro_f1,f1_score(y[valid],choices[valid],labels=np.arange(6),average='macro',zero_division=0))
            rows.append({'policy':policy,'seed':seed,'model':'UtilityRegression','sha256':hashlib.sha256(path.read_bytes()).hexdigest()});del model;gc.collect()
            path=folder/'TemperatureBaseModel.joblib';model=joblib.load(path);raw=aligned_probabilities(model,x);split=json.loads((folder/'calibration_split.json').read_text())
            assert not set(split['proper_train_maps'])&set(split['calibration_maps']) and not set(test['map'])&(set(split['proper_train_maps'])|set(split['calibration_maps']))
            for method,p in [('ProperTrainRaw',raw),('ProperTrainTemperature',temperature_probabilities(raw,split['temperature']))]:
                observed=score_predictions(y[valid],p[valid]);m=cal[(cal.seed==seed)&(cal.method==method)].iloc[0]
                for metric in ['accuracy','macro_f1','brier','ece','mean_confidence']:assert np.isclose(observed[metric],m[metric],atol=1e-12)
                choice=p.argmax(axis=1);choice[p.max(axis=1)<.5]=PLANNERS.index('weighted_astar')
                outcome=pd.read_csv(folder/(method+'FixedFallback_0.5_outcomes.csv'));assert np.array_equal(np.array(PLANNERS)[choice],outcome.planner)
            rows.append({'policy':policy,'seed':seed,'model':'TemperatureBaseModel','sha256':hashlib.sha256(path.read_bytes()).hexdigest()});del model;gc.collect()
    Path('validation/additional_models_validation.json').write_text(json.dumps({'passed':True,'models_replayed':20,'model_records':rows,'utility_predictions_compared':21300,'calibration_task_rule_outputs_compared':7100,'calibration_map_separation_passed':True},indent=2))
    print('Additional 20 utility/calibration models replayed successfully')

if __name__=='__main__':main()
