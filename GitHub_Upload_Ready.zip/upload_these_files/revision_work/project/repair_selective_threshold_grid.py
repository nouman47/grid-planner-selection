"""Canonical decimal diagnostic cutoffs; regenerate only selective curves."""
from pathlib import Path
import hashlib,json
import numpy as np,pandas as pd
from analysis_core import selective_table,PLANNERS

def main():
    synthetic=np.array([[.6,.4,0,0,0,0],[.6,.4,0,0,0,0]])
    test=selective_table([0,1],synthetic);r=test[test.threshold==.6].iloc[0]
    assert r.n_accepted==2 and r.selective_accuracy==.5
    changes=[]
    for policy in ['strict','relaxed']:
        for seed in [42,52,62,72,82]:
            folder=Path(f'analyses/{policy}/seed_{seed}');p=folder/'selective_risk_coverage.csv';old=pd.read_csv(p)
            d=pd.read_csv(folder/'ExtraTrees_test_predictions.csv',float_precision='round_trip');d=d[d.label_valid]
            probs=d[['p_'+x for x in PLANNERS]].to_numpy();assert np.array_equal(probs.max(axis=1),d.confidence.to_numpy())
            y=d.best_planner.map({name:i for i,name in enumerate(PLANNERS)}).to_numpy(int);new=selective_table(y,probs)
            for i in range(len(new)):
                if int(old.iloc[i].n_accepted)!=int(new.iloc[i].n_accepted):
                    changes.append({'policy':policy,'seed':seed,'threshold':float(new.iloc[i].threshold),'old_accepted':int(old.iloc[i].n_accepted),'new_accepted':int(new.iloc[i].n_accepted)})
            new.to_csv(p,index=False)
    record={'passed':True,'reason':'np.linspace produced cutoffs such as 0.6000000000000001 rather than the declared decimal 0.6, excluding exact-boundary predictions. Default cutoffs now use integer-grid division. Probabilities are parsed with round-trip precision.','affected_output':'selective risk/coverage diagnostic curves only; no fitting, predictions, fixed-fallback outcomes, benchmark outcomes or model identities changed','boundary_regression_test_passed':True,'changed_counts':changes,'previous_core_sha256':hashlib.sha256(Path('validation/analysis_core_before_threshold_grid.py').read_bytes()).hexdigest(),'current_core_sha256':hashlib.sha256(Path('analysis_core.py').read_bytes()).hexdigest()}
    Path('validation/selective_threshold_grid_correction.json').write_text(json.dumps(record,indent=2))
    print('Selective grid corrected;',len(changes),'boundary counts updated')

if __name__=='__main__':main()
