"""Fair model and planning-policy analysis; blocked until full audit passes.

Outputs here are explicitly planning-only. Direct selection-overhead profiling,
explanation stability and final manuscript consistency are separate completion
gates; these files alone do not establish deployment benefit.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import ExtraTreesClassifier,ExtraTreesRegressor,RandomForestClassifier,GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,f1_score,classification_report,confusion_matrix
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from scipy.optimize import minimize_scalar
from analysis_core import KEYS,PLANNERS,WEIGHTS,aggregate_repetitions,compute_utility,score_predictions,selective_table,cluster_interval,classification_intervals,aligned_probabilities,policy_outcomes,temperature_probabilities
from features import FEATURES,GROUPS

SEEDS=(42,52,62,72,82)


def models(seed):
    return {'LogisticRegression':make_pipeline(StandardScaler(),LogisticRegression(max_iter=5000,random_state=seed)),
            'RandomForest':RandomForestClassifier(n_estimators=500,max_features='sqrt',random_state=seed,n_jobs=1),
            'ExtraTrees':ExtraTreesClassifier(n_estimators=500,max_features='sqrt',random_state=seed,n_jobs=1),
            'GradientBoosting':GradientBoostingClassifier(random_state=seed),
            'ExtraTreesBalanced':ExtraTreesClassifier(n_estimators=500,max_features='sqrt',class_weight='balanced',random_state=seed,n_jobs=1),
            'RandomForestBalanced':RandomForestClassifier(n_estimators=500,max_features='sqrt',class_weight='balanced',random_state=seed,n_jobs=1)}


def matrix_outcomes(utilities,frame,column):
    pivot=utilities.pivot(index=KEYS,columns='planner',values=column).reindex(columns=PLANNERS)
    return pivot.reindex(pd.MultiIndex.from_frame(frame[KEYS])).to_numpy(float)


def summarize_policy(outcomes,oracle_utility):
    weights=outcomes.success_rate.to_numpy();lengths=outcomes.path_length.to_numpy()
    finite=np.isfinite(lengths)&(weights>0)
    return {'tasks':len(outcomes),'success_rate':float(weights.mean()),'mean_capped_median_runtime_ms':float(outcomes.runtime_ms.mean()),
            'conditional_mean_path_length':float(np.average(lengths[finite],weights=weights[finite])) if finite.any() else np.nan,
            'mean_utility':float(outcomes.utility.mean()),'mean_oracle_regret':float(np.mean(oracle_utility-outcomes.utility.to_numpy()))}


def compare_with_baseline(outcomes,baseline,seed):
    rows=[]
    for column in ['runtime_ms','success_rate','utility','path_length']:
        difference=outcomes[column].to_numpy()-baseline[column].to_numpy()
        if column=='path_length':
            difference[(outcomes.success_rate.to_numpy()==0)|(baseline.success_rate.to_numpy()==0)]=np.nan
        mean,lo,hi=cluster_interval(difference,outcomes['map'].to_numpy(),1000,seed)
        rows.append({'metric':column,'mean_policy_minus_baseline':mean,'ci_low':lo,'ci_high':hi,'paired_tasks':int(np.isfinite(difference).sum()),
                     'interpretation':'positive is better' if column in ['utility','success_rate'] else 'negative is better',
                     'bootstrap_unit':'map','bootstrap_replicates':1000})
    return rows


def analyze(policy,frame,utilities,out):
    out.mkdir(parents=True,exist_ok=True);metrics=[];policy_rows=[];comparisons=[];fallback_rows=[];family_rows=[];family_policy_rows=[];calibration_rows=[];ablation_rows=[]
    encoded={name:i for i,name in enumerate(PLANNERS)};all_y=frame.best_planner.map(encoded).fillna(-1).to_numpy(int)
    for seed in SEEDS:
        dest=out/f'seed_{seed}';dest.mkdir(exist_ok=True)
        train_idx,test_idx=next(GroupShuffleSplit(n_splits=1,test_size=.25,random_state=seed).split(frame,groups=frame['map']))
        train=frame.iloc[train_idx].reset_index(drop=True);test=frame.iloc[test_idx].reset_index(drop=True)
        train_y=all_y[train_idx];test_y=all_y[test_idx];train_valid=train_y>=0;test_valid=test_y>=0
        if not train_valid.any():raise RuntimeError('No valid training labels; classification cannot be fitted')
        if set(train['map'])&set(test['map']):raise RuntimeError('Map overlap')
        split={'seed':seed,'train_maps':sorted(set(train['map'])),'test_maps':sorted(set(test['map'])),
               'train_tasks':len(train),'test_tasks':len(test),'train_valid_labels':int(train_valid.sum()),'test_valid_labels':int(test_valid.sum()),
               'train_label_counts':{name:int((train_y==i).sum()) for i,name in enumerate(PLANNERS)},
               'test_label_counts':{name:int((test_y==i).sum()) for i,name in enumerate(PLANNERS)},
               'class_order':PLANNERS,'features':FEATURES,'filter_rule':'Split all maps first, then exclude label-invalid tasks only from classification fitting/scoring'}
        (dest/'split.json').write_text(json.dumps(split,indent=2));train[KEYS].to_csv(dest/'train_keys.csv',index=False);test[KEYS].to_csv(dest/'test_keys.csv',index=False)
        x_train=train[FEATURES].to_numpy(float);x_test=test[FEATURES].to_numpy(float)
        train_matrix=matrix_outcomes(utilities,train,'utility');test_matrix=matrix_outcomes(utilities,test,'utility')
        oracle_u=test_matrix.max(axis=1);all_policies={};primary_probability=None;primary=None
        estimators=models(seed)
        for name,estimator in estimators.items():
            fitted_as=name
            if len(np.unique(train_y[train_valid]))<2:estimator=DummyClassifier(strategy='most_frequent');fitted_as='single-class constant fallback'
            estimator.fit(x_train[train_valid],train_y[train_valid]);prob=aligned_probabilities(estimator,x_test);pred=prob.argmax(axis=1)
            metric={'policy':policy,'seed':seed,'model':name,'fitted_as':fitted_as,**score_predictions(test_y[test_valid],prob[test_valid]),
                    **classification_intervals(test_y[test_valid],pred[test_valid],test.loc[test_valid,'map'].to_numpy(),1000,seed),
                    'train_tasks':int(train_valid.sum()),'test_tasks_all':len(test),'test_tasks_without_valid_label':int((~test_valid).sum())}
            metrics.append(metric)
            predictions=test[KEYS+['family','difficulty','best_planner','label_valid']].copy();predictions['predicted_planner']=[PLANNERS[i] for i in pred];predictions['confidence']=prob.max(axis=1)
            for i,planner in enumerate(PLANNERS):predictions['p_'+planner]=prob[:,i]
            predictions.to_csv(dest/f'{name}_test_predictions.csv',index=False)
            report=classification_report(test_y[test_valid],pred[test_valid],labels=np.arange(6),target_names=PLANNERS,output_dict=True,zero_division=0)
            pd.DataFrame(report).T.to_csv(dest/f'{name}_classification.csv')
            pd.DataFrame(confusion_matrix(test_y[test_valid],pred[test_valid],labels=np.arange(6)),index=PLANNERS,columns=PLANNERS).to_csv(dest/f'{name}_confusion.csv')
            joblib.dump(estimator,dest/f'{name}.joblib')
            all_policies[name]=policy_outcomes(utilities,test,[PLANNERS[i] for i in pred])
            for family in sorted(test.family.unique()):
                mask=(test.family.to_numpy()==family)&test_valid
                family_rows.append({'policy':policy,'seed':seed,'model':name,'family':family,**score_predictions(test_y[mask],prob[mask]),
                                    'tasks_all':int((test.family==family).sum()),'maps':test.loc[test.family==family,'map'].nunique()})
            if name=='ExtraTrees':primary_probability=prob;primary=estimator
            print(policy,seed,name,'fit and scored',flush=True)
        # Established utility-regression comparator, not a new planning algorithm.
        reg=ExtraTreesRegressor(n_estimators=500,max_features='sqrt',random_state=seed,n_jobs=1)
        reg.fit(x_train,train_matrix);predicted_utilities=reg.predict(x_test);reg_pred=predicted_utilities.argmax(axis=1)
        metrics.append({'policy':policy,'seed':seed,'model':'UtilityRegression','fitted_as':'ExtraTreesRegressor multi-output utility',
                        'n':int(test_valid.sum()),'accuracy':accuracy_score(test_y[test_valid],reg_pred[test_valid]) if test_valid.any() else np.nan,
                        'macro_f1':f1_score(test_y[test_valid],reg_pred[test_valid],labels=np.arange(6),average='macro',zero_division=0) if test_valid.any() else np.nan,
                        **classification_intervals(test_y[test_valid],reg_pred[test_valid],test.loc[test_valid,'map'].to_numpy(),1000,seed),
                        'train_tasks':len(train),'test_tasks_all':len(test),'brier':np.nan,'ece':np.nan})
        all_policies['UtilityRegression']=policy_outcomes(utilities,test,[PLANNERS[i] for i in reg_pred]);joblib.dump(reg,dest/'UtilityRegression.joblib')
        reg_export=test[KEYS].copy()
        for i,name in enumerate(PLANNERS):reg_export['predicted_utility_'+name]=predicted_utilities[:,i]
        reg_export.to_csv(dest/'UtilityRegression_test_predictions.csv',index=False)
        sbs_index=int(train_matrix.mean(axis=0).argmax());majority_index=int(np.bincount(train_y[train_valid],minlength=6).argmax())
        split['training_selected_single_best_planner']=PLANNERS[sbs_index];split['training_majority_label']=PLANNERS[majority_index]
        (dest/'split.json').write_text(json.dumps(split,indent=2))
        all_policies['TrainingSingleBest']=policy_outcomes(utilities,test,[PLANNERS[sbs_index]]*len(test))
        all_policies['TrainingMajority']=policy_outcomes(utilities,test,[PLANNERS[majority_index]]*len(test))
        for planner in PLANNERS:all_policies['Fixed_'+planner]=policy_outcomes(utilities,test,[planner]*len(test))
        # An oracle may choose the fastest failure on an all-failure task, while
        # such a task still has no classification label and oracle utility zero.
        best_by_task=utilities.assign(_class=utilities.planner.map(encoded)).sort_values(['utility','runtime_ms','path_length','_class'],ascending=[False,True,True,True]).drop_duplicates(KEYS)
        choices=test[KEYS].merge(best_by_task[KEYS+['planner']],on=KEYS,validate='one_to_one').planner.tolist()
        all_policies['VirtualBest']=policy_outcomes(utilities,test,choices)
        # Exact expected uniform-random policy; no lucky random draw.
        random_out=test[KEYS+['family','difficulty']].copy()
        for col in ['runtime_ms','success_rate','utility']:random_out[col]=matrix_outcomes(utilities,test,col).mean(axis=1)
        success=matrix_outcomes(utilities,test,'success_rate');length=matrix_outcomes(utilities,test,'path_length')
        numerator=np.nansum(success*length,axis=1);denom=success.sum(axis=1)
        random_out['path_length']=np.divide(numerator,denom,out=np.full(len(test),np.nan),where=denom>0)
        all_policies['UniformRandomExpected']=random_out
        # Fixed-fallback and selective analyses are deliberately separate.
        confidence=primary_probability.max(axis=1);base=primary_probability.argmax(axis=1)
        for threshold in [.5,.6,.7,.8,.9]:
            decisions=base.copy();uncertain=confidence<threshold;decisions[uncertain]=encoded['weighted_astar']
            name='FixedWeightedFallback_'+str(threshold);all_policies[name]=policy_outcomes(utilities,test,[PLANNERS[i] for i in decisions])
            fallback_rows.append({'policy':policy,'seed':seed,'threshold':threshold,'test_tasks_all':len(test),'n_overridden':int(uncertain.sum()),
                                  'coverage_all_tasks':float((~uncertain).mean()),
                                  'whole_policy_accuracy':accuracy_score(test_y[test_valid],decisions[test_valid]) if test_valid.any() else np.nan,
                                  'whole_policy_macro_f1':f1_score(test_y[test_valid],decisions[test_valid],labels=np.arange(6),average='macro',zero_division=0) if test_valid.any() else np.nan})
        selective_table(test_y[test_valid],primary_probability[test_valid]).to_csv(dest/'selective_risk_coverage.csv',index=False)
        # Calibration experiment: fit temperature on separate training maps.
        proper_idx,cal_idx=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=seed+1000).split(train,groups=train['map']))
        proper_valid=proper_idx[train_y[proper_idx]>=0];cal_valid=cal_idx[train_y[cal_idx]>=0]
        if len(proper_valid) and len(cal_valid):
            inner=ExtraTreesClassifier(n_estimators=500,max_features='sqrt',random_state=seed,n_jobs=1)
            inner.fit(x_train[proper_valid],train_y[proper_valid]);cal_p=aligned_probabilities(inner,x_train[cal_valid])
            def loss(log_t):
                p=temperature_probabilities(cal_p,np.exp(log_t));return -float(np.log(np.clip(p[np.arange(len(cal_valid)),train_y[cal_valid]],1e-12,1)).mean())
            fitted=minimize_scalar(loss,bounds=(np.log(.05),np.log(20)),method='bounded');temperature=float(np.exp(fitted.x))
            raw=aligned_probabilities(inner,x_test);calibrated=temperature_probabilities(raw,temperature)
            for method,p in [('ProperTrainRaw',raw),('ProperTrainTemperature',calibrated)]:
                calibration_rows.append({'policy':policy,'seed':seed,'method':method,'temperature':temperature if method.endswith('Temperature') else 1.,
                                         **score_predictions(test_y[test_valid],p[test_valid])})
                pred=p.argmax(axis=1);pred[p.max(axis=1)<.5]=encoded['weighted_astar']
                all_policies[method+'FixedFallback_0.5']=policy_outcomes(utilities,test,[PLANNERS[i] for i in pred])
            (dest/'calibration_split.json').write_text(json.dumps({'proper_train_maps':sorted(set(train.iloc[proper_idx]['map'])),
                'calibration_maps':sorted(set(train.iloc[cal_idx]['map'])),'temperature':temperature,'test_maps_never_used_for_calibration':True,
                'comparison_note':'ProperTrainRaw and ProperTrainTemperature share the same fitted inner model; primary full-training model differs'},indent=2))
            joblib.dump(inner,dest/'TemperatureBaseModel.joblib')
        # Ablations fit on exactly the same training tasks, never the test set.
        ablations={'navigation':GROUPS['navigation'],'navigation_environment':GROUPS['navigation']+GROUPS['environment'],
                   'full':FEATURES,'without_free_space':[x for x in FEATURES if x!='free_space_ratio'],
                   'without_obstacle_density':[x for x in FEATURES if x!='obstacle_density'],
                   'without_both_occupancy':[x for x in FEATURES if x not in ['free_space_ratio','obstacle_density']]}
        for name,columns in ablations.items():
            estimator=ExtraTreesClassifier(n_estimators=500,max_features='sqrt',random_state=seed,n_jobs=1)
            estimator.fit(train.loc[train_valid,columns].to_numpy(float),train_y[train_valid]);p=aligned_probabilities(estimator,test[columns].to_numpy(float))
            ablation_rows.append({'policy':policy,'seed':seed,'configuration':name,'features':len(columns),**score_predictions(test_y[test_valid],p[test_valid])})
        baseline=all_policies['TrainingSingleBest']
        for name,outcomes in all_policies.items():
            result={'policy':policy,'seed':seed,'method':name,'timing_scope':'planning-only; selection overhead not yet profiled',**summarize_policy(outcomes,oracle_u)}
            mean,lo,hi=cluster_interval(outcomes.utility,outcomes['map'],1000,seed);result.update(utility_ci_low=lo,utility_ci_high=hi);policy_rows.append(result)
            for family in sorted(outcomes.family.unique()):
                mask=outcomes.family.to_numpy()==family;subset=outcomes.loc[mask]
                family_result={'policy':policy,'seed':seed,'method':name,'family':family,'maps':subset['map'].nunique(),
                               **summarize_policy(subset,oracle_u[mask]),'timing_scope':'planning-only'}
                _,lo,hi=cluster_interval(subset.utility,subset['map'],1000,seed)
                family_result.update(utility_ci_low=lo,utility_ci_high=hi);family_policy_rows.append(family_result)
            outcomes.to_csv(dest/(name+'_outcomes.csv'),index=False)
            comparisons.extend({'policy':policy,'seed':seed,'method':name,'baseline':'TrainingSingleBest',**r} for r in compare_with_baseline(outcomes,baseline,seed))
        (dest/'model_inputs.json').write_text(json.dumps({'features':FEATURES,'class_order':PLANNERS,'primary_model':'ExtraTrees',
            'no_test_based_model_selection':True,'selection_overhead_pending':True},indent=2))
    for name,rows in [('model_comparison',metrics),('planning_only_policy_comparison',policy_rows),('paired_cluster_comparisons',comparisons),
                      ('fixed_fallback_whole_policy',fallback_rows),('family_classification',family_rows),('family_policy_comparison',family_policy_rows),('temperature_calibration',calibration_rows),('ablations',ablation_rows)]:
        pd.DataFrame(rows).to_csv(out/(name+'.csv'),index=False)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',default='results/full_v2');parser.add_argument('--policy',choices=['strict','relaxed'],default='strict')
    parser.add_argument('--out',default='analyses');args=parser.parse_args();folder=Path(args.run);audit_path=folder/'audit.json'
    if not audit_path.exists():print('Model fitting blocked: complete independent benchmark audit does not exist.');return 2
    audit=json.loads(audit_path.read_text())
    if not audit.get('passed') or not audit.get('complete') or audit.get('records')!=audit.get('expected'):raise RuntimeError('Full audit gate failed')
    runs_path=folder/'audited_runs.csv'
    if hashlib.sha256(runs_path.read_bytes()).hexdigest()!=audit.get('audited_runs_sha256'):raise RuntimeError('Audited table hash changed')
    protocol=json.loads((folder/'protocol.json').read_text());runs=pd.read_csv(runs_path)
    aggregate=aggregate_repetitions(runs,protocol['repetitions']);aggregate=aggregate[aggregate.policy==args.policy].reset_index(drop=True)
    utilities,labels=compute_utility(aggregate);features_path=Path('data/features_'+args.policy+'.csv');features=pd.read_csv(features_path)
    frame=features.merge(labels.drop(columns=['family','difficulty','policy']),on=KEYS,how='inner',validate='one_to_one').sort_values(KEYS).reset_index(drop=True)
    if len(frame)!=len(labels):raise RuntimeError('Features do not align one-to-one with label tasks')
    if frame[FEATURES].isna().any().any() or not np.isfinite(frame[FEATURES].to_numpy()).all():raise RuntimeError('Nonfinite model features')
    out=Path(args.out)/args.policy;out.mkdir(parents=True,exist_ok=True);utilities.to_csv(out/'planner_utilities.csv',index=False);labels.to_csv(out/'task_labels.csv',index=False)
    positive=aggregate[aggregate.success_rate>0]
    ranges=positive.groupby(KEYS).agg(runtime_values=('runtime_ms','nunique'),path_values=('path_length','nunique'))
    diagnostics={'tasks':len(labels),'all_failure_tasks':int((~labels.label_valid).sum()),
                 'tasks_with_successful_candidate':len(ranges),'equal_runtime_tasks':int((ranges.runtime_values==1).sum()),
                 'equal_path_cost_tasks':int((ranges.path_values==1).sum()),'weights':WEIGHTS,
                 'definition':'Degeneracy counts refer to candidates with at least one validated successful repetition'}
    (out/'utility_diagnostics.json').write_text(json.dumps(diagnostics,indent=2))
    manifest={'audit_protocol_hash':audit['protocol_hash'],'record_set_sha256':audit['record_set_sha256'],'feature_table_sha256':hashlib.sha256(features_path.read_bytes()).hexdigest(),
              'analysis_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'analysis_core_sha256':hashlib.sha256(Path('analysis_core.py').read_bytes()).hexdigest(),
              'weights':WEIGHTS,'seeds':SEEDS,'class_order':PLANNERS,'feature_columns':FEATURES,
              'status':'in progress','not_submission_ready':'Overhead, SHAP stability, weight sensitivity and final manuscript gates remain separate'}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2));analyze(args.policy,frame,utilities,out)
    manifest['status']='model and planning-only policy analysis completed';(out/'manifest.json').write_text(json.dumps(manifest,indent=2));return 0


if __name__=='__main__':raise SystemExit(main())
