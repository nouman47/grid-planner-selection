"""Held-out one-query-per-map SHAP with training backgrounds and additivity gates."""
import argparse,hashlib,json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path('../shap_dependencies').resolve()))
import joblib,numpy as np,pandas as pd,shap
from scipy.stats import spearmanr
from analysis_core import KEYS,PLANNERS,aligned_probabilities
from features import FEATURES,GROUPS

class ExactIndependent(shap.maskers.Independent):
    def invariants(self,x):
        # Approximate isclose equality can suppress a small but real feature
        # change across a tree threshold. Skip evaluations only for exact equality.
        return np.equal(self.data,np.asarray(x))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');args=parser.parse_args()
    dest=Path('analyses/shap_permutation_pilot' if args.pilot else 'analyses/shap');dest.mkdir(exist_ok=True)
    rankings=[];metadata=[];locals=[];stability=[]
    for policy in ['strict','relaxed']:
        features=pd.read_csv('data/features_'+policy+'.csv');root=Path('analyses')/policy
        for seed in [42,52,62,72,82]:
            folder=root/f'seed_{seed}';model_path=folder/'ExtraTrees.joblib';model=joblib.load(model_path)
            train=pd.read_csv(folder/'train_keys.csv').merge(features,on=KEYS,validate='one_to_one')
            test=pd.read_csv(folder/'test_keys.csv').merge(features,on=KEYS,validate='one_to_one')
            assert not set(train['map'])&set(test['map'])
            # First task in canonical coordinate order per held-out map; no label/confidence selection.
            sample=test.sort_values(KEYS).drop_duplicates('map').reset_index(drop=True)
            if args.pilot:sample=sample.iloc[:1].copy()
            background=train.iloc[np.random.default_rng(seed).choice(len(train),25,replace=False)].copy()
            x=sample[FEATURES].to_numpy(float);bg=background[FEATURES].to_numpy(float)
            start=time.perf_counter();explainer=shap.PermutationExplainer(lambda data:aligned_probabilities(model,data),ExactIndependent(bg,max_samples=25),seed=seed)
            result=explainer(x,max_evals=390,silent=True)
            aligned=np.asarray(result.values);base_aligned=np.asarray(result.base_values)[0]
            p=aligned_probabilities(model,x)
            error=float(np.max(np.abs(result.base_values+aligned.sum(axis=1)-p)))
            if error>1e-9:raise RuntimeError(f'Probability additivity failure {policy} {seed}: {error}')
            assert aligned.shape==(len(x),len(FEATURES),6)
            tag=f'{policy}_{seed}';sample[KEYS+['family']].to_csv(dest/(tag+'_explanation_keys.csv'),index=False)
            background[KEYS].to_csv(dest/(tag+'_background_keys.csv'),index=False)
            temp=dest/(tag+'.npz.tmp')
            with temp.open('wb') as f:np.savez_compressed(f,values=aligned,base_values=base_aligned,probabilities=p,features=x)
            temp.replace(dest/(tag+'.npz'))
            importance=np.abs(aligned).mean(axis=(0,2))
            for i,name in enumerate(FEATURES):
                rankings.append({'policy':policy,'seed':seed,'feature':name,'mean_absolute_shap':float(importance[i]),'rank':float(pd.Series(-importance).rank(method='average')[i])})
            for j,row in sample.iterrows():
                for k,feature in enumerate(FEATURES):
                    for c,planner in enumerate(PLANNERS):locals.append({**{key:row[key] for key in KEYS},'policy':policy,'seed':seed,'feature':feature,'feature_value':float(x[j,k]),'planner':planner,'shap':float(aligned[j,k,c]),'base_probability':float(base_aligned[c]),'predicted_probability':float(p[j,c])})
            metadata.append({'policy':policy,'seed':seed,'queries':len(sample),'background_queries':25,'max_evals':390,'model_sha256':hashlib.sha256(model_path.read_bytes()).hexdigest(),'max_additivity_error':error,'elapsed_s':time.perf_counter()-start})
            print(tag,'SHAP passed',len(sample),'queries; max error',error,flush=True)
    ranking=pd.DataFrame(rankings)
    for policy,g in ranking.groupby('policy'):
        wide=g.pivot(index='feature',columns='seed',values='mean_absolute_shap')
        for i,a in enumerate(wide.columns):
            for b in wide.columns[i+1:]:
                topa=set(wide[a].nlargest(5).index);topb=set(wide[b].nlargest(5).index)
                stability.append({'policy':policy,'seed_a':int(a),'seed_b':int(b),'spearman_rho':float(spearmanr(wide[a],wide[b]).statistic),'top5_jaccard':len(topa&topb)/len(topa|topb)})
    ranking.to_csv(dest/'feature_rankings.csv',index=False);pd.DataFrame(locals).to_csv(dest/'signed_local_explanations.csv',index=False);pd.DataFrame(stability).to_csv(dest/'ranking_stability.csv',index=False)
    for policy in ['strict','relaxed']:
        frame=pd.read_csv('data/features_'+policy+'.csv');frame[FEATURES].corr(method='spearman').to_csv(dest/(policy+'_feature_spearman.csv'))
    (dest/'manifest.json').write_text(json.dumps({'completed':True,'pilot':args.pilot,'shap_version':shap.__version__,'models':metadata,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'method':'Permutation SHAP of the saved classifier probabilities; float64 inputs; exact-equality invariance in the independent masker; 25 randomly sampled training-task backgrounds per split; max_evals 390 per query; one canonical unique task per held-out map.',
        'masker_change':'Default np.isclose-based masker invariance produced a relaxed split-42 additivity discrepancy of 8.000000000230045e-06. Only exactly equal background/query values are now considered invariant; small real changes across tree thresholds are evaluated.',
        'method_change':'Interventional TreeExplainer pilot failed the external 1e-6 additivity gate on strict split 72 (error 2.002055650054957e-05); those attributions excluded. Permutation SHAP directly calls predict_proba and must pass 1e-9 additivity.',
        'interpretation':'Attributions are Monte Carlo approximations and explain fitted predictions, not causes or planner guarantees. Exact additivity is not proof of converged individual Shapley values. Correlated features are not independently manipulable; independent masking may produce unrealistic combinations. Ranking variation combines different training sets, held-out cohorts, backgrounds and permutation sampling; it is descriptive, not a controlled same-cohort retraining experiment.'},indent=2))

if __name__=='__main__':main()
