"""Research revision: cell-centre grids; geometric costs; six explicit algorithms.

Original sources are preserved in research_read/. This module is independently
versioned and must pass validation before producing manuscript replacement data.
JPS rules: Harabor & Grastien 2011 (relaxed), 2012 (strict). Theta* is
Basic Theta* adapted to cell centres with an explicit segment traversal rule.
"""
from __future__ import annotations
import heapq
import math
import time
from pathlib import Path
import numpy as np

SQRT2 = math.sqrt(2.0)
MOVES = ((1,0), (0,1), (-1,0), (0,-1), (1,1), (-1,1), (-1,-1), (1,-1))


class Grid:
    def __init__(self, blocked, strict=True):
        self.blocked = np.asarray(blocked, dtype=bool)
        if self.blocked.ndim != 2:
            raise ValueError('Grid must be two dimensional')
        self.height, self.width = self.blocked.shape
        self.strict = bool(strict)

    @classmethod
    def load(cls, path, strict=True):
        lines = Path(path).read_text().splitlines()
        start = lines.index('map')
        header = dict(line.split(maxsplit=1) for line in lines[:start])
        width, height = int(header['width']), int(header['height'])
        rows = lines[start+1:]
        if len(rows) != height or any(len(row) != width for row in rows):
            raise ValueError('Map dimensions do not match header')
        # Explicit conservative traversability for benchmark point agents.
        unknown = set(''.join(rows)) - set('.GS@OTW')
        if unknown:
            raise ValueError(f'Unknown map symbols: {unknown}')
        return cls([[c not in '.GS' for c in row] for row in rows], strict)

    def free(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height and not self.blocked[y,x]

    def step(self, x, y, dx, dy):
        if not self.free(x+dx, y+dy):
            return False
        return not (self.strict and dx and dy) or (self.free(x+dx,y) and self.free(x,y+dy))

    def neighbors(self, node):
        x,y = node
        for dx,dy in MOVES:
            if self.step(x,y,dx,dy):
                yield (x+dx,y+dy), SQRT2 if dx and dy else 1.0

    def visible(self, a, b):
        """Integer DDA through cell interiors; strict mode checks corner contacts.

        Points are cell centres. Relaxed mode permits passage through an exact
        shared corner; strict mode also requires both orthogonal side cells free.
        Every positive-length cell traversal must be free under both policies.
        """
        x,y = a
        if not self.free(x,y) or not self.free(*b):
            return False
        dx,dy = abs(b[0]-x), abs(b[1]-y)
        sx = (b[0]>x)-(b[0]<x)
        sy = (b[1]>y)-(b[1]<y)
        ix=iy=0
        while ix<dx or iy<dy:
            cx=(2*ix+1)*dy
            cy=(2*iy+1)*dx
            if cx==cy:
                if self.strict and (not self.free(x+sx,y) or not self.free(x,y+sy)):
                    return False
                x+=sx; y+=sy; ix+=1; iy+=1
            elif cx<cy:
                x+=sx; ix+=1
            else:
                y+=sy; iy+=1
            if not self.free(x,y):
                return False
        return True


def path_length(path):
    return sum(math.dist(a,b) for a,b in zip(path,path[1:]))


def reconstruct(parent, node):
    out=[]
    seen=set()
    while node is not None:
        if node in seen:
            raise RuntimeError('Parent cycle')
        seen.add(node); out.append(node); node=parent[node]
    return out[::-1]


def _astar(grid, start, goal, weight=1.0, theta=False):
    h=lambda n: math.dist(n,goal)
    distances={start:0.0}; parent={start:None}; queue=[(weight*h(start),0.0,start)]
    closed=set(); expanded=0
    while queue:
        _,g,u=heapq.heappop(queue)
        if u in closed or g != distances.get(u):
            continue
        closed.add(u); expanded+=1
        if u==goal:
            return reconstruct(parent,goal), expanded
        for v,cost in grid.neighbors(u):
            if v in closed:
                continue
            p=u; candidate=g+cost
            if theta and parent[u] is not None and grid.visible(parent[u],v):
                p=parent[u]; candidate=distances[p]+math.dist(p,v)
            if candidate < distances.get(v,math.inf)-1e-12:
                distances[v]=candidate; parent[v]=p
                heapq.heappush(queue,(candidate+weight*h(v),candidate,v))
    return [],expanded


def _bidirectional(grid,start,goal):
    """Balanced consistent Euclidean potentials, incumbent lower-bound stop.

    p(v)=(d(v,t)-d(s,v))/2. Forward key=gF+p, backward=gB-p.
    Stop when min keyF + min keyB >= incumbent path cost. A first
    frontier intersection is only an upper bound, never a stop condition.
    """
    potential=lambda n:(math.dist(n,goal)-math.dist(start,n))/2
    dist=[{start:0.0},{goal:0.0}]; parents=[{start:None},{goal:None}]
    queues=[[(potential(start),0.0,start)],[(-potential(goal),0.0,goal)]]
    closed=[set(),set()]; best=math.inf; meet=None; expanded=0; tie=0
    while queues[0] and queues[1]:
        for side in (0,1):
            q=queues[side]
            while q and (q[0][2] in closed[side] or q[0][1] != dist[side].get(q[0][2])):
                heapq.heappop(q)
        if not queues[0] or not queues[1]:
            break
        if queues[0][0][0]+queues[1][0][0] >= best-1e-12:
            break
        if abs(queues[0][0][0]-queues[1][0][0])<1e-12:
            side=tie%2;tie+=1
        else:
            side=int(queues[1][0][0]<queues[0][0][0])
        other=1-side;_,g,u=heapq.heappop(queues[side]);closed[side].add(u);expanded+=1
        if u in dist[other] and g+dist[other][u]<best:
            best=g+dist[other][u];meet=u
        for v,cost in grid.neighbors(u):
            candidate=g+cost
            if v not in closed[side] and candidate<dist[side].get(v,math.inf)-1e-12:
                dist[side][v]=candidate;parents[side][v]=u
                key=candidate+(potential(v) if side==0 else -potential(v))
                heapq.heappush(queues[side],(key,candidate,v))
            if v in dist[side] and v in dist[other] and dist[side][v]+dist[other][v]<best:
                best=dist[side][v]+dist[other][v];meet=v
    if meet is None:
        return [],expanded
    return reconstruct(parents[0],meet)+reconstruct(parents[1],meet)[-2::-1],expanded


def _jps(grid,start,goal):
    """Online JPS with actual directional pruning and jump scans.

    No A* fallback. Strict and relaxed diagonal policies have distinct forced
    neighbor rules. Axial scans are iterative, including diagonal subqueries.
    Jump-segment costs are geometric; returned path expands jump segments.
    """
    free=grid.free
    def forced(x,y,dx,dy):
        if grid.strict:
            if dx and dy:
                return False
            if dx:
                return any(free(x,y+s) and not free(x-dx,y+s) for s in (-1,1))
            return any(free(x+s,y) and not free(x+s,y-dy) for s in (-1,1))
        if dx and dy:
            return (free(x-dx,y+dy) and not free(x-dx,y)) or (free(x+dx,y-dy) and not free(x,y-dy))
        if dx:
            return any(free(x+dx,y+s) and not free(x,y+s) for s in (-1,1))
        return any(free(x+s,y+dy) and not free(x+s,y) for s in (-1,1))
    def jump(x,y,dx,dy):
        while grid.step(x,y,dx,dy):
            x+=dx;y+=dy
            if (x,y)==goal or forced(x,y,dx,dy):
                return (x,y)
            if dx and dy and (jump(x,y,dx,0) is not None or jump(x,y,0,dy) is not None):
                return (x,y)
        return None
    def directions(u,p):
        if p is None:
            return [(dx,dy) for dx,dy in MOVES if grid.step(*u,dx,dy)]
        x,y=u;dx=(x>p[0])-(x<p[0]);dy=(y>p[1])-(y<p[1]);out=[]
        if dx and dy:
            out=[(dx,0),(0,dy),(dx,dy)]
            if not grid.strict:
                if not free(x-dx,y):out.append((-dx,dy))
                if not free(x,y-dy):out.append((dx,-dy))
        elif dx:
            out=[(dx,0)]
            for s in (-1,1):
                if grid.strict:
                    if free(x,y+s) and not free(x-dx,y+s):out.extend([(0,s),(dx,s)])
                elif not free(x,y+s):out.append((dx,s))
        else:
            out=[(0,dy)]
            for s in (-1,1):
                if grid.strict:
                    if free(x+s,y) and not free(x+s,y-dy):out.extend([(s,0),(s,dy)])
                elif not free(x+s,y):out.append((s,dy))
        return [(a,b) for a,b in out if grid.step(x,y,a,b)]
    distances={start:0.0};parents={start:None};closed=set();expanded=0
    queue=[(math.dist(start,goal),0.0,start)]
    while queue:
        _,g,u=heapq.heappop(queue)
        if u in closed or g != distances.get(u):continue
        closed.add(u);expanded+=1
        if u==goal:
            jumps=reconstruct(parents,goal);path=[start]
            for a,b in zip(jumps,jumps[1:]):
                steps=max(abs(b[0]-a[0]),abs(b[1]-a[1]));dx=(b[0]-a[0])//steps;dy=(b[1]-a[1])//steps
                path.extend((a[0]+i*dx,a[1]+i*dy) for i in range(1,steps+1))
            return path,expanded
        for dx,dy in directions(u,parents[u]):
            v=jump(*u,dx,dy)
            if v is None or v in closed:continue
            candidate=g+math.dist(u,v)
            if candidate<distances.get(v,math.inf)-1e-12:
                distances[v]=candidate;parents[v]=u
                heapq.heappush(queue,(candidate+math.dist(v,goal),candidate,v))
    return [],expanded


PLANNERS=('dijkstra','astar','weighted_astar','bidirectional_astar','jps','theta_star')


def search(name,grid,start,goal):
    start=tuple(map(int,start));goal=tuple(map(int,goal));started=time.perf_counter()
    if not grid.free(*start) or not grid.free(*goal):
        path=[];expanded=0;status='invalid_endpoint'
    else:
        status='solved'
        if name=='dijkstra':path,expanded=_astar(grid,start,goal,weight=0.0)
        elif name=='astar':path,expanded=_astar(grid,start,goal)
        elif name=='weighted_astar':path,expanded=_astar(grid,start,goal,weight=1.5)
        elif name=='theta_star':path,expanded=_astar(grid,start,goal,theta=True)
        elif name=='bidirectional_astar':path,expanded=_bidirectional(grid,start,goal)
        elif name=='jps':path,expanded=_jps(grid,start,goal)
        else:raise ValueError(name)
        if not path:status='no_path'
    runtime=(time.perf_counter()-started)*1000
    return {'planner':name,'success':bool(path),'status':status,'path':path,
            'path_length':path_length(path) if path else None,'nodes_expanded':expanded,
            'runtime_ms':runtime}
