"""Additional direct overhead for already fitted low-cost comparator models.

Added after observing primary Extra Trees overhead; no model selection or tuning.
Preserves primary-model identity. Uses the earlier measured map-setup medians.
"""
import hashlib,json,os,time
from pathlib import Path
import joblib,numpy as np,pandas as pd
from analysis_core import KEYS,PLANNERS,aligned_probabilities,policy_outcomes,cluster_interval
from features import MapFeatures,FEATURES

def main():
    dest=Path('analyses/comparator_timing');dest.mkdir(exist_ok=True);records=dest/'records';records.mkdir(exist_ok=True)
    files=sorted(records.glob('*.json'));raw=[json.loads(p.read_bytes()) for p in files]
    identity=KEYS+['policy','seed','model','repetition'];done={tuple(r[k] for k in identity) for r in raw};assert len(raw)==len(done)
    assert [p.name for p in files]==[f'{i:06d}.json' for i in range(len(files))]
    cold=pd.read_csv('analyses/selection_timing/map_preparation_medians.csv');summaries=[];paired=[];hashes={}
    for policy in ['strict','relaxed']:
        features=pd.read_csv('data/features_'+policy+'.csv');utilities=pd.read_csv('analyses/'+policy+'/planner_utilities.csv')
        for seed in [42,52,62,72,82]:
            folder=Path('analyses')/policy/f'seed_{seed}';test=pd.read_csv(folder/'test_keys.csv').merge(features,on=KEYS,validate='one_to_one')
            models={name:joblib.load(folder/(name+'.joblib')) for name in ['LogisticRegression','GradientBoosting']}
            for name in models:hashes[str(folder/(name+'.joblib'))]=hashlib.sha256((folder/(name+'.joblib')).read_bytes()).hexdigest()
            for model in models.values():model.predict_proba(test[FEATURES].to_numpy(float)[:1])
            for map_name,group in test.groupby('map',sort=True):
                if sum(r['policy']==policy and r['seed']==seed and r['map']==map_name for r in raw)==len(group)*6:continue
                context=MapFeatures(Path('data/maps')/map_name,policy=='strict')
                cost=float(cold[(cold.policy==policy)&(cold.seed==seed)&(cold['map']==map_name)].map_preparation_median_ms.iloc[0])
                for task in group.to_dict('records'):
                    for name,model in models.items():
                        for rep in range(3):
                            key=tuple(task[k] for k in KEYS)+(policy,seed,name,rep)
                            if key in done:continue
                            begin=time.perf_counter_ns();data,_=context.extract(task);a=time.perf_counter_ns()
                            x=np.array([[data[n] for n in FEATURES]],dtype=float);b=time.perf_counter_ns()
                            probability=aligned_probabilities(model,x);c=time.perf_counter_ns()
                            selected=int(probability.argmax());confidence=float(probability.max());fallback=selected if confidence>=.5 else PLANNERS.index('weighted_astar');d=time.perf_counter_ns()
                            assert np.allclose(x[0],[task[n] for n in FEATURES],atol=1e-10,rtol=1e-10)
                            r={**{k:task[k] for k in KEYS},'policy':policy,'seed':seed,'model':name,'repetition':rep,
                                'cached_selection_ms':(d-begin)/1e6,'cold_selection_ms':(d-begin)/1e6+cost,
                                'feature_ms':(a-begin)/1e6,'vector_ms':(b-a)/1e6,'inference_ms':(c-b)/1e6,'decision_ms':(d-c)/1e6,
                                'predicted_planner':PLANNERS[selected],'fallback_planner':PLANNERS[fallback],'confidence':confidence}
                            p=records/f'{len(raw):06d}.json';temp=p.with_suffix('.tmp')
                            with temp.open('w') as f:json.dump(r,f);f.flush();os.fsync(f.fileno())
                            temp.replace(p);raw.append(r);done.add(key)
                print(policy,seed,map_name,len(raw),'comparator timing records',flush=True)
            frame=pd.DataFrame(raw);frame=frame[(frame.policy==policy)&(frame.seed==seed)]
            baseline=pd.read_csv(folder/'TrainingSingleBest_outcomes.csv')
            for name,g in frame.groupby('model'):
                grouped=g.groupby(KEYS,sort=False);assert (grouped.size()==3).all()
                for scope in ['cached','cold']:
                    measurements=grouped[scope+'_selection_ms'].median().reset_index();choices=grouped[['predicted_planner','fallback_planner']].first().reset_index()
                    aligned=test[KEYS].merge(measurements,on=KEYS,validate='one_to_one').merge(choices,on=KEYS,validate='one_to_one')
                    assert aligned[KEYS].equals(test[KEYS])
                    for fallback in [False,True]:
                        method=name+('_FixedFallback_0.5' if fallback else '')
                        outcome=policy_outcomes(utilities,test,aligned.fallback_planner if fallback else aligned.predicted_planner,overhead_ms=aligned[scope+'_selection_ms'].to_numpy())
                        outcome.to_csv(dest/f'{policy}_{seed}_{method}_{scope}_outcomes.csv',index=False)
                        summaries.append({'policy':policy,'seed':seed,'method':method,'scope':scope,'mean_selection_ms':float(aligned[scope+'_selection_ms'].mean()),'success_rate':float(outcome.success_rate.mean()),'mean_total_runtime_ms':float(outcome.runtime_ms.mean()),'mean_utility':float(outcome.utility.mean())})
                        for col in ['runtime_ms','utility','success_rate']:
                            mean,lo,hi=cluster_interval(outcome[col].to_numpy()-baseline[col].to_numpy(),outcome['map'],1000,seed)
                            paired.append({'policy':policy,'seed':seed,'method':method,'scope':scope,'metric':col,'policy_minus_training_single_best':mean,'ci_low':lo,'ci_high':hi})
    frame=pd.DataFrame(raw);assert len(frame)==21300
    frame.to_csv(dest/'raw_timing.csv',index=False);pd.DataFrame(summaries).to_csv(dest/'charged_policy_summary.csv',index=False);pd.DataFrame(paired).to_csv(dest/'paired_charged_comparisons.csv',index=False)
    (dest/'manifest.json').write_text(json.dumps({'completed':True,'records':len(frame),'model_sha256':hashes,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope':'Exploratory overhead extension to existing LR and GB models after seeing ET timing; no refitting or primary-model change; cold costs reuse prior measured map-preparation medians; same limitations as primary selection timing.'},indent=2))

if __name__=='__main__':main()
