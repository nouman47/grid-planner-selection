"""Process-isolated, resumable benchmark with saved paths and provenance.

One search at a time by default, avoiding competing planner timing loads.
Timeout begins after the child's ready signal; process/map setup excluded from
search runtime and separately timed. A timed-out child is terminated and joined.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import math
import multiprocessing as mp
import os
import platform
from pathlib import Path
import random
import sys
import time
import traceback
import pandas as pd
import numpy as np
from planners import Grid,PLANNERS,search,path_length


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def identity(r):
    return (r['map'],int(r['start_x']),int(r['start_y']),int(r['goal_x']),int(r['goal_y']),r['planner'],r['policy'],int(r['repetition']))


def atomic_json(path,data):
    path=Path(path);temporary=path.with_suffix('.tmp')
    with temporary.open('w') as handle:
        handle.write(json.dumps(data,allow_nan=False)+'\n');handle.flush();os.fsync(handle.fileno())
    temporary.replace(path)


def load_legacy_import(folder,source,protocol):
    """Explicitly import verified records after a logging-only revision.

    Preserve original per-record protocol hashes and verify the exact measurement
    functions by AST, not by asserting that changed code is 'equivalent'.
    """
    folder=Path(folder);old=json.loads((folder/'protocol.json').read_text())
    if digest(source)!=old['sources']['run_benchmark.py']:raise RuntimeError('Archived legacy runner hash mismatch')
    def functions(path):
        tree=ast.parse(Path(path).read_text())
        return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.FunctionDef)}
    old_funcs=functions(source);new_funcs=functions(__file__)
    for name in ['worker','bounded_search']:
        if old_funcs[name]!=new_funcs[name]:raise RuntimeError('Measurement function changed: '+name)
    if old['sources']['planners.py']!=protocol['sources']['planners.py']:raise RuntimeError('Imported planner implementation differs')
    for key,value in protocol.items():
        if key not in ['sources','writer_version'] and old.get(key)!=value:raise RuntimeError('Imported measurement/environment differs: '+key)
    rows=[]
    with (folder/'runs.jsonl').open() as handle:
        for line in handle:rows.append(json.loads(line))
    keys=[identity(r) for r in rows]
    if len(keys)!=len(set(keys)):raise RuntimeError('Imported records are duplicated')
    if any(r['protocol_hash']!=old['protocol_hash'] for r in rows):raise RuntimeError('Unexpected imported protocol hash')
    if any(r['status'] not in ['solved','no_path','timeout','invalid_endpoint'] for r in rows):raise RuntimeError('Fatal imported status')
    lineage={'protocol_hash':old['protocol_hash'],'source_hashes':old['sources'],
             'log_sha256':digest(folder/'runs.jsonl'),'record_count':len(rows),
             'measurement_functions_ast_identical':True,'reason':'Logging-only change from open append stream to immutable atomic record files'}
    return rows,lineage


def worker(connection,grid,name,start,goal):
    try:
        connection.send({'ready':True,'started_ns':time.monotonic_ns()})
        result=search(name,grid,start,goal)
        connection.send({'search_complete':True,'result':result})
        # Validation is outside measured planner search time. Raster validation
        # here rechecks the returned geometry; independent slab tests are in
        # validate_planners.py and a sample audit can additionally use those.
        checked=time.perf_counter();path=result['path'];errors=[]
        if result['success']:
            if path[0]!=start or path[-1]!=goal:errors.append('endpoints')
            if len(path)!=len(set(path)):errors.append('cycle')
            if any(not grid.free(*p) for p in path):errors.append('occupied waypoint')
            for a,b in zip(path,path[1:]):
                if name!='theta_star' and max(abs(a[0]-b[0]),abs(a[1]-b[1]))!=1:errors.append('nonadjacent grid move')
                if not grid.visible(a,b):errors.append('segment collision')
            if abs(path_length(path)-result['path_length'])>1e-8:errors.append('length mismatch')
        if errors:
            result['reported_success']=result['success'];result['success']=False
            result['status']='invalid_path';result['path_length']=None
        result['validation_errors']=sorted(set(errors));result['validation_ms']=(time.perf_counter()-checked)*1000
        connection.send({k:v for k,v in result.items() if k not in ['path','planner','runtime_ms','nodes_expanded']})
    except BaseException:
        connection.send({'status':'error','success':False,'path':[],'path_length':None,'error':traceback.format_exc()})
    finally:connection.close()


def bounded_search(grid,name,start,goal,timeout,start_method='spawn'):
    context=mp.get_context(start_method);parent,child=context.Pipe(duplex=False)
    process=context.Process(target=worker,args=(child,grid,name,start,goal))
    setup=time.perf_counter();process.start();child.close()
    try:
        if not parent.poll(30):
            return {'status':'setup_timeout','success':False,'path':[],'path_length':None,'error':'Child not ready in 30 s'}
        first=parent.recv();setup_ms=(time.perf_counter()-setup)*1000
        if not first.get('ready'):return {**first,'setup_ms':setup_ms}
        remaining=max(0.0,timeout-(time.monotonic_ns()-first['started_ns'])/1e9)
        if parent.poll(remaining):
            message=parent.recv()
            if not message.get('search_complete'):return {**message,'setup_ms':setup_ms}
            result=message['result']
            if result['runtime_ms']>timeout*1000:
                result={'status':'timeout','success':False,'path':[],'path_length':None,'runtime_ms':timeout*1000,'runtime_censored':True}
            else:
                if not parent.poll(30):raise RuntimeError('Post-search validation did not complete in 30 s')
                result.update(parent.recv())
            result['budget_elapsed_ms']=(time.monotonic_ns()-first['started_ns'])/1e6
        else:
            result={'status':'timeout','success':False,'path':[],'path_length':None,
                    'runtime_ms':timeout*1000,'budget_elapsed_ms':(time.monotonic_ns()-first['started_ns'])/1e6,
                    'runtime_censored':True}
        return {**result,'setup_ms':setup_ms}
    except EOFError:
        return {'status':'worker_crash','success':False,'path':[],'path_length':None,'error':'Child pipe closed'}
    finally:
        if process.is_alive():process.terminate()
        process.join(timeout=5)
        if process.is_alive():process.kill();process.join()
        parent.close()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--scenarios',default='data/pilot_scenarios.csv')
    parser.add_argument('--maps',default='data/maps');parser.add_argument('--out',default='results/pilot')
    parser.add_argument('--timeout',type=float,default=10.0)
    parser.add_argument('--repetitions',type=int,default=1)
    parser.add_argument('--policies',choices=['strict','relaxed','both'],default='both')
    parser.add_argument('--seed',type=int,default=20261030)
    parser.add_argument('--start-method',choices=mp.get_all_start_methods(),default='spawn')
    parser.add_argument('--import-from',help='Explicit legacy checkpoint folder; measurement-function and environment guards apply')
    parser.add_argument('--import-source',default='../history/full_v1_sources/run_benchmark.py')
    parser.add_argument('--initialize-only',action='store_true')
    parser.add_argument('--resume',action='store_true');args=parser.parse_args()
    if args.timeout<=0 or args.repetitions<1:raise ValueError('Positive timeout and repetitions required')
    scenarios=pd.read_csv(args.scenarios);out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    task_keys=['map','start_x','start_y','goal_x','goal_y']
    if scenarios[task_keys].duplicated().any():raise RuntimeError('Scenario task keys are duplicated')
    validation=json.loads(Path('validation/planner_validation.json').read_text())
    if not validation['passed']:raise RuntimeError('Planner validation gate failed')
    if validation.get('source_sha256')!=digest('planners.py'):raise RuntimeError('Validation source hash is stale; rerun validation')
    sources={name:digest(name) for name in ['planners.py','run_benchmark.py','validate_planners.py']}
    if len(scenarios)>6:
        audit=json.loads(Path('results/pilot_v2/independent_audit.json').read_text())
        pilot_protocol=json.loads(Path('results/pilot_v2/protocol.json').read_text())
        if not audit['passed'] or audit['runs']!=72:raise RuntimeError('Independent real-map pilot gate failed')
        if pilot_protocol['sources']['planners.py']!=sources['planners.py']:raise RuntimeError('Pilot planner hash is stale')
        if audit['runs_sha256']!=digest('results/pilot_v2/runs.jsonl'):raise RuntimeError('Pilot data hash mismatch')
    maps={name:digest(Path(args.maps)/name) for name in sorted(set(scenarios['map']))}
    protocol={'scenario_sha256':digest(args.scenarios),'map_sha256':maps,'sources':sources,
              'timeout_s':args.timeout,'repetitions':args.repetitions,'policies':args.policies,'seed':args.seed,
              'python':sys.version,'platform':platform.platform(),'processor':platform.processor(),
              'cpu_count':os.cpu_count(),'numpy':np.__version__,'pandas':pd.__version__,
              'start_method':args.start_method,
              'timing':'Sequential process-isolated search; setup excluded; result transfer deadline; separate post-search validation',
              'geometry':'Cell centres; orthogonal 1, diagonal sqrt(2); strict primary, relaxed sensitivity',
              'writer_version':2}
    protocol_path=out/'protocol.json';record_dir=out/'records';record_dir.mkdir(exist_ok=True)
    imported=[]
    if protocol_path.exists():
        prior=json.loads(protocol_path.read_text());protocol['import_lineage']=prior.get('import_lineage')
    elif args.import_from:
        imported,lineage=load_legacy_import(args.import_from,args.import_source,protocol);protocol['import_lineage']=lineage
    else:protocol['import_lineage']=None
    protocol_hash=hashlib.sha256(json.dumps(protocol,sort_keys=True).encode()).hexdigest()
    if protocol_path.exists():
        old=json.loads(protocol_path.read_text())
        if old['protocol_hash']!=protocol_hash:raise RuntimeError('Existing results use a different protocol/source; choose a new output directory')
        if not args.resume:raise RuntimeError('Output exists; explicit --resume required')
    atomic_json(protocol_path,{**protocol,'protocol_hash':protocol_hash})
    records=[]
    allowed_hashes={protocol_hash}
    if protocol['import_lineage']:allowed_hashes.add(protocol['import_lineage']['protocol_hash'])
    for path in sorted(record_dir.glob('*.json')):
        r=json.loads(path.read_text())
        if r['protocol_hash'] not in allowed_hashes:raise RuntimeError('Unexpected record protocol')
        records.append({k:v for k,v in r.items() if k not in ['path','validation_errors']})
    done={identity(r) for r in records};policies=[True,False] if args.policies=='both' else [args.policies=='strict']
    if len(done)!=len(records):raise RuntimeError('Duplicate records in resume log')
    if any(r['status'] in {'invalid_path','error','worker_crash','setup_timeout'} for r in records):
        raise RuntimeError('Fatal record in existing log; investigate it and use a new protocol/output after repair')
    tasks=[];rng=random.Random(args.seed)
    for repetition in range(args.repetitions):
        for strict in policies:
            for row in scenarios.to_dict('records'):
                order=list(PLANNERS);rng.shuffle(order)
                for name in order:tasks.append({**row,'planner':name,'policy':'strict' if strict else 'relaxed','repetition':repetition})
    expected=len(tasks)
    ordinals={identity(r):i for i,r in enumerate(tasks)}
    if len(ordinals)!=expected:raise RuntimeError('Expected task identities are not unique')
    if imported:
        if not {identity(r) for r in imported}<=set(ordinals):raise RuntimeError('Imported keys are unexpected')
        for r in imported:
            atomic_json(record_dir/f'{ordinals[identity(r)]:06d}.json',r)
            records.append({k:v for k,v in r.items() if k not in ['path','validation_errors']});done.add(identity(r))
        atomic_json(out/'import_audit.json',{'verified_records':len(imported),'lineage':protocol['import_lineage'],
                                           'old_reported_progress_is_not_used':True})
    if not done<={identity(r) for r in tasks}:raise RuntimeError('Resume log contains unexpected task keys')
    if args.initialize_only:
        atomic_json(out/'progress.json',{'state':'initialized','accepted':len(done),'expected':expected,'protocol_hash':protocol_hash})
        print('Initialized',len(done),'verified records; no new search executed');return
    cached_map=None;cached_grid=None
    for task in tasks:
        if identity(task) in done:continue
        start=(int(task['start_x']),int(task['start_y']));goal=(int(task['goal_x']),int(task['goal_y']))
        cache_key=(task['map'],task['policy'])
        if cache_key!=cached_map:
            cached_grid=Grid.load(Path(args.maps)/task['map'],task['policy']=='strict');cached_map=cache_key
        result=bounded_search(cached_grid,task['planner'],start,goal,args.timeout,args.start_method)
        r={**task,**result,'protocol_hash':protocol_hash}
        atomic_json(record_dir/f'{ordinals[identity(task)]:06d}.json',r)
        records.append({k:v for k,v in r.items() if k not in ['path','validation_errors']});done.add(identity(task))
        progress={'state':'running','accepted':len(done),'expected':expected,'last':{k:r[k] for k in ['map','planner','policy','repetition','status']},'protocol_hash':protocol_hash}
        atomic_json(out/'progress.json',progress)
        print(f"{len(done)}/{expected} {task['policy']} {task['map']} {task['planner']} {r['status']} {r.get('runtime_ms',0):.2f}ms",flush=True)
        if r['status'] in {'invalid_path','error','worker_crash','setup_timeout'}:
            raise RuntimeError(f"Benchmark stopped after {r['status']}; inspect saved record before resuming")
    flat=[{k:v for k,v in r.items() if k not in ['path','validation_errors']} for r in records]
    csv_tmp=out/'runs.csv.tmp';pd.DataFrame(flat).to_csv(csv_tmp,index=False);csv_tmp.replace(out/'runs.csv')
    json_tmp=out/'runs.jsonl.tmp'
    with json_tmp.open('w') as handle:
        for path in sorted(record_dir.glob('*.json')):handle.write(path.read_text())
        handle.flush();os.fsync(handle.fileno())
    json_tmp.replace(out/'runs.jsonl')
    if len(done)!=expected:raise RuntimeError('Incomplete benchmark coverage')
    atomic_json(out/'progress.json',{'state':'completed','accepted':len(done),'expected':expected,'protocol_hash':protocol_hash})
    print('Finished',len(records),'records; paths and protocol saved',flush=True)


if __name__=='__main__':main()
