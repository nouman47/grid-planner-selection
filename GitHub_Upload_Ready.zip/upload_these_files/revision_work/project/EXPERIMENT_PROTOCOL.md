# Corrected experiment protocol

This is the revision implementation, not the historical submitted implementation.
The original manuscript and outputs remain unchanged. Replacement manuscript
results must not be populated until the full benchmark and analyses pass their gates.

## Benchmark

- Preserve the supplied 1,405 unique scenario queries on 281 maps. The queries are
  custom sampled tasks from the project; they are not claimed to be the official
  MovingAI optimal-distance scenarios.
- Keep all six algorithm names, now backed by separate implemented procedures.
  JPS has directional pruning and jump scans; no fallback to ordinary A* is used.
  Bidirectional A* uses balanced consistent Euclidean potentials and an incumbent
  lower-bound stopping rule. Basic Theta* uses cell-centre waypoints and geometric
  line-of-sight relaxation, documented as a cell-centre adaptation.
- Maps use (column,row) task coordinates and row-major [row,column] arrays.
  All 281 retrieved maps contain only `.`, `@` and `T`. Only `.` is traversable
  in these files. The loader also explicitly supports the documented G/S terrain
  case and treats water/exterior/trees as unavailable to this terrain agent.
- Orthogonal cost is 1; diagonal cost is exact sqrt(2), replacing rounded 1.414.
  Any-angle cost is Euclidean segment length. This is a declared protocol change.
- Strict no-corner-cutting is the primary analysis. The original permissive rule
  is a separate sensitivity condition on the same tasks. Strict line-of-sight
  forbids blocked-square corner contact; relaxed line-of-sight allows exact point
  contact but never traversal through a blocked cell interior. Both are point-agent
  abstractions, not finite-size robot collision models.
- Three repetitions per task, planner and collision rule: 50,580 planned records.
  Planner execution order is shuffled within each task using seed 20261030.
- One timed search executes at a time. Each search has its own OS process and a
  10-second wall-clock budget. Timeouts are censored observations, not proof of
  an impossible task. Invalid paths and infrastructure errors stop the run.
- Map loading/process startup and independent post-search path checks are outside
  reported planner runtime. The parent deadline conservatively includes the result
  transfer. Timeout rows record the capped budget. Direct feature/inference and
  policy overhead must be evaluated separately in the later analysis.
- Store every returned path and task key, not just aggregate scores. Persist each
  accepted record with fsync and an atomic rename into an immutable per-run file.
  The initial open append stream proved unreliable for live checkpoint visibility;
  only the verified 3,458-record snapshot was migrated to the new writer, with
  original per-record hashes preserved and timed functions checked AST-identical.
  Resume only under identical source/config/map hashes.
  Never mix source versions or infer completion from an old progress file alone.

## Features

- One row per navigation task. Nineteen documented preplanning descriptors are
  partitioned into navigation, environment and topology groups in features.py.
- Local density uses an 11x11 window (radius 5), with outside-map cells occupied.
  Clearance is distance to the nearest blocked cell centre, including a blocked
  exterior ring. These definitions replace the missing/ambiguous historical ones.
- Start component ratio is task-specific. Strict movement components equal
  4-connected components; relaxed components use 8-connectivity. The former
  ambiguous transition_complexity name is replaced with mean_free_degree4.
- Family/difficulty, planner identity, runtime, success and path outcomes never
  enter the model. Complementary occupancy descriptors are retained to allow the
  requested redundancy analysis, not treated as independent mechanisms.

## Downstream analysis to implement and validate after benchmark completion

- Freeze map-disjoint seed-42 split and seeds 52,62,72,82 on all 281 maps before
  filtering tasks without a successful candidate. Save map/task manifests. Do not
  let failure filtering silently change the held-out-map definition.
- Summarize repeated measured outcomes transparently; report timeout/unsolved
  tasks and success frequency. Define valid-label handling and normalized utility
  before model fitting. Test weights and tie handling on corrected outcomes.
- Compare all four original model families on identical map splits; assess class
  weighting within training maps. Keep any threshold/calibration selection away
  from the final test maps. Save class mappings and task-keyed probabilities.
- Compare fixed, majority, random, learned, fallback and oracle policies on common
  task sets with overhead accounted for. Separate fixed Weighted A* fallback,
  adaptive rules and accepted-case selective metrics. Include map-clustered
  uncertainty, family-specific results, weight sensitivity and explanation stability.
- Time feature generation from maps and single-task inference directly; report
  cache assumptions. Runtime results belong to the actual recorded execution
  environment, not the laptop/software versions in the submitted manuscript.
- No practical improvement or model superiority is assumed in advance. Weak or
  negative corrected results must be reported and claims narrowed accordingly.

## Primary references used for algorithm and format checks

- Harabor and Grastien (2011), Online Graph Pruning for Pathfinding on Grid Maps.
  https://doi.org/10.1609/aaai.v25i1.7994
- Harabor and Grastien (2012), The JPS Pathfinding System (strict movement rules).
  https://harabor.net/data/papers/harabor-grastien-socs12.pdf
- Nash, Daniel, Koenig and Felner (2007), Theta* Any-Angle Path Planning on Grids.
  https://idm-lab.org/bib/abstracts/Koen07f.html
- MovingAI benchmark file format and no-corner-cutting reference convention.
  https://movingai.com/benchmarks/formats.html

Finite tests and pilot audits provide validation evidence; they are not proofs
of general correctness, optimality for Theta*, or real-robot safety.
