"""Build the point-by-point response with locations from the final PDF."""
import json,re,hashlib
from pathlib import Path
import fitz
from docx import Document
from docx.shared import Pt,Inches,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).parent;OUT=ROOT/'submission_revision'
COMMENTS=json.loads((OUT/'reviewer_comments.json').read_text())
LOC=json.loads((OUT/'document_locations.json').read_text())
PDF=OUT/'manuscript_render/Revised_Manuscript.pdf'
def norm(x):return re.sub(r'\s+','',x).replace('–','-').replace('−','-')
pages=[norm(p.get_text()) for p in fitz.open(PDF)]
def locate(text):
 matches=[i+1 for i,p in enumerate(pages) if norm(text) in p]
 if not matches:raise ValueError('No verified page for '+text)
 return matches[0]
PAGE={'sections':{k:locate(v) for k,v in LOC['sections'].items()},'tables':{k:locate('Table '+str(n)+' ') for k,n in LOC['tables'].items()}}
# Caption prefixes must include a delimiter: Table 1 cannot match Table 10.
manuscript=Document(OUT/'Revised_Manuscript.docx')
for key,num in LOC['tables'].items():
 caption=next(p.text for p in manuscript.paragraphs if re.match(rf'^Table {num} ',p.text))
 PAGE['tables'][key]=locate(caption)
(OUT/'page_locations.json').write_text(json.dumps(PAGE,indent=2))

R={}
def add(key,paragraphs,sections=(),tables=(),evidence=''):
 R[key]={'paragraphs':paragraphs,'sections':list(sections),'tables':list(tables),'evidence':evidence}

add('R1.1',[
 'The contribution has been narrowed and stated explicitly. Rice-style instance-to-algorithm mapping, meta-learning, Extra Trees, confidence thresholds and SHAP are established methods; this work does not introduce a fundamentally new selection-learning or search mechanism. The revised contribution is an independently audited empirical assessment of their integration for this six-planner grid portfolio, including failure-aware utility, controlled collision rules and budgets, fair map-disjoint comparisons and measured decision costs.',
 'The new comparisons include six classifier configurations, class-weighted forests, multi-output utility regression, feature ablations, every fixed planner, a training-selected single best, training majority, exact expected uniform selection and a virtual-best oracle. They delimit the integration’s benefits rather than treating the combination itself as algorithmic novelty. The abstract, contribution statement, discussion and conclusion have been rewritten accordingly.'
],['novelty','models','benefit'],['models','planning','overhead'],'analyses/{strict,relaxed}/model_comparison.csv; ablations.csv; planning_only_policy_comparison.csv')

add('R1.2',[
 'The original numerical results have been replaced after the implementation corrections described in response R1.3. Class support is now explicit for both collision rules and the primary training/test partitions. Under strict checking, the primary valid training labels include 568 JPS, 292 Theta*, 113 Weighted A*, 30 A* and 9 Bidirectional A* cases; Dijkstra has none. The primary test set has 340 label-valid cases, including only 5 A* and 2 Bidirectional A*. Under relaxed checking Dijkstra has one example in the complete dataset and none in the primary test set. Zero scores for absent test classes are distinguished from failures on rare populated classes.',
 'Both Random Forest and Extra Trees were refitted with training-derived balanced class weights on all five identical map partitions. A six-output Extra Trees utility regressor provides a utility-aware alternative. Per-class reports, confusion matrices, fixed-six-class macro-F1, supported-class macro-F1 and paired model intervals are supplied. The primary strict Extra Trees accuracy is 0.7324 and fixed-six-class macro-F1 is 0.2493; five-split means are 0.7341 and 0.2528. Weighting does not uniformly improve minority recall, so the manuscript retains that negative result rather than claiming that imbalance has been solved.'
],['models','model_results'],['support','models','class_report'],'analyses/{strict,relaxed}/seed_*/split.json; *_classification.csv; *_confusion.csv; analyses/additional_statistics/supported_class_macro_f1.csv')

add('R1.3',[
 'Verification found a substantive error in the historical runner: it treated a returned result dictionary as a path, creating invalid success flags and the constant dictionary size 5.00 as path length. JPS, Theta* and bidirectional search also required implementation corrections. These findings are disclosed in the manuscript. All planner outcomes, labels, fitted models, predictions and explanations used in the revision were regenerated; the historical practical-performance table is withdrawn.',
 'The complete corrected experiment contains 50,580 unique expected records with no missing keys, duplicates or recorded validation errors. An independent audit checks 2,810 task/collision-rule reference distances and 21,058,724 returned-path segments. The task identity is the complete map/start/goal key. Success is the fraction of three repetitions with a validated route; length is geometric distance in cell-width units; timeout-capped runtime, normalization, ties, failures and all-failure tasks are defined explicitly.',
 'On strict seed 42, Extra Trees has utility 0.7279 and regret 0.0360, while the virtual best has utility 0.7639 and regret zero. Their conditional path means are 584.68 and 586.52, respectively; these means use their own successful outcomes and do not imply that the selector has a better route on identical success sets. The paired-success path comparison is reported separately. Every task-level policy outcome and model prediction is available in S1. Model-output validation reopens all 60 saved classifier models and checks 106,500 task-output comparisons.'
],['validation','utility','integrity_results','planning_results'],['integrity','planning','paired'],'results/full_v2/audit.json; audited_runs.csv; independent_oracle.csv; analyses/*/seed_*/*_outcomes.csv; validation/model_outputs_validation.json')

add('R1.4',[
 'All six fixed planners are now evaluated on the same test tasks, and the single-best reference is selected by mean utility on training maps only. It is JPS on these partitions. Comparisons report success, capped-median search runtime, conditional path length, utility and oracle regret, with paired map-cluster intervals.',
 'For strict seed 42, Extra Trees minus training-selected JPS is +126.8666 ms in runtime (95% interval 27.7745 to 246.9107), −2.4182 cell widths in paired-success path length (−3.3216 to −1.5998; 338 paired tasks), +0.0126 in planning-only utility (−0.0033 to 0.0288), and −0.0056 in success frequency (−0.0141 to 0.0000). After cached selection cost is charged, the utility difference is −0.0671 (−0.0930 to −0.0412). These results support a path–time trade-off and do not establish practical superiority. The claims have been corrected to match that evidence.'
],['confidence','planning_results','overhead_results'],['planning','paired','overhead'],'analyses/{strict,relaxed}/paired_cluster_comparisons.csv; analyses/selection_timing/paired_charged_comparisons.csv')

add('R1.5',[
 'The weights 0.2/0.5/0.3 are now described as a declared runtime-oriented preference, with smaller rewards for path quality and empirical reliability. They are not estimated safety requirements or universally optimal constants. Within-task normalization, its tie convention and failure handling are given explicitly.',
 'For each collision rule, 45 nonnegative weight combinations vary success weight from 0 to 0.4 and runtime weight over the remaining mass in steps of 0.1; path weight is the remainder. Seed-42 test maps remain fixed, and the model is refitted only on training maps for every setting. Label agreement with the default falls to 0.3476 under strict and 0.3082 under relaxed checking. Default-model regret ranges up to 0.4612 and 0.4906; the corresponding ranges for refitted models reach 0.0452 and 0.0502. The evidence demonstrates preference sensitivity, not invariant robustness. The revision therefore advises declaring the application preference and retraining when it changes.'
],['utility','weight_results'],['weights'],'analyses/{strict,relaxed}/weight_sensitivity.csv and weight_sensitivity.metadata.json; Fig. 3')

add('R1.6',[
 'The investigation identified a metric-definition problem: the submitted selective-accuracy table mixed fallback-applied whole-policy accuracy with retained-case terminology. The revised table and curves use the same accepted, label-valid cases, report accepted counts and coverage, and leave empty-set accuracy undefined. For strict seed 42, selective accuracy is 0.8060 at τ = 0.5 (268/340 accepted) and 0.9844 at τ = 0.9 (64/340), with local non-monotonicity at intermediate thresholds. This is distinct from accuracy after executing fallback on rejected cases.',
 'The revised fallback uses fixed Weighted A* with weight 1.5; the earlier adaptive rule is not relabelled as fixed fallback. At τ = 0.5 on the primary strict split, whole-policy accuracy is 0.6676 and macro-F1 is 0.2718, compared with 0.7324/0.2493 without fallback. Planning runtime decreases from 208.91 to 145.20 ms and success frequency increases from 0.9521 to 0.9549, while utility decreases from 0.7279 to 0.7248. Thus an F1 improvement is not presented as a utility improvement.',
 'Temperature scaling is fitted only on a separate calibration subset of training maps and compared with raw probabilities from the identical proper-training model. It does not uniformly improve calibration: strict five-split mean ECE changes from 0.0581 to 0.0627, while Brier score changes from 0.3923 to 0.3920. Raw and scaled fallback planning outcomes are supplied. Threshold 0.5 is fixed in advance; 0.5–0.9 is diagnostic, and no operating threshold is optimized on the test set. Confidence is not interpreted as a safety guarantee.'
],['confidence','fallback_results','overhead_results'],['confidence','calibration','paired'],'analyses/*/seed_*/selective_risk_coverage.csv; fixed_fallback_whole_policy.csv; temperature_calibration.csv; ProperTrain*Fallback* outcomes; Fig. 2')

add('R1.7',[
 'Separate DAO, Maze and Street analyses now cover every map partition and both collision rules, including class support, classification metrics and planning success/runtime/path/utility. On the primary split the family counts are 34 DAO maps/170 tasks, 16 Maze maps/80 tasks and 21 Street maps/105 tasks. The manuscript reports primary family utility before and after cached overhead, with family-specific whole-map paired intervals.',
 'The selector does not improve consistently across families. Primary strict Maze choices coincide with fixed JPS before overhead; DAO includes many cheap searches for which selection is costly; Street can offer path-quality trade-offs. The discussion distinguishes filename-disjoint transfer within the observed families from unseen-family or geographical transfer. Related city/map variants may occur across partitions, and leave-one-family-out testing has not been performed.'
],['family_results','limitations'],['families'],'analyses/*/family_classification.csv; family_policy_comparison.csv; analyses/additional_statistics/family_class_support.csv; charged_family_comparisons.csv')

add('R1.8',[
 'Uncertainty is now computed by resampling whole maps rather than treating their five queries as independent observations. Each percentile interval uses 1,000 map resamples. Paired policy differences use the same task keys and map draws; paired classifier accuracy and macro-F1 differences use shared map draws of per-map six-class confusion matrices. Primary model accuracy/F1 intervals and paired fixed-planner comparisons are reported, with all split-specific model comparisons in S1.',
 'Five overlapping partitions are summarized by descriptive means and sample standard deviations, not treated as five independent geographical replications. Family/subgroup intervals and multiple model comparisons are interpreted descriptively without uncorrected significance claims. The uncertainty discussion also notes that map-level clustering cannot eliminate every correlation among related map variants.'
],['confidence','model_results','planning_results','limitations'],['models','paired'],'analysis_core.py; additional_statistics.py; analyses/additional_statistics/paired_model_comparisons.csv; analyses/*/paired_cluster_comparisons.csv')

add('R1.9',[
 'All explanations were regenerated from the corrected primary models. The revised feature pipeline has 19 precisely defined descriptors; its results should not be read as a replication of the historical transition-complexity ranking. Permutation SHAP explains one canonical held-out query per map, yielding 710 split-specific cases across five partitions and two collision rules. Each background contains 25 training queries. An exact-equality invariant mask is used, and every explanation passes an external 10⁻⁹ probability-additivity gate. The failed initial TreeExplainer/default-invariance attempts are excluded and documented.',
 'Across-split ranking Spearman ranges are 0.905–0.986 for strict and 0.937–0.986 for relaxed checking; top-five Jaccard overlap ranges from 0.429 to 1.000. Signed DAO, Maze and Street examples retain task keys, feature values, baseline and predicted probabilities. The DAO example explains the raw prediction and is explicitly identified as activating fallback at τ = 0.5.',
 'Feature-correlation matrices, group ablations and removals of free-space ratio/obstacle density assess redundancy. Complementary occupancy and related size descriptors remain correlated, so individual rankings are not causal effects. A small same-model/background permutation-seed repeat check is also supplied. Finite backgrounds and permutation sampling limit attribution precision; exact additivity is not claimed as proof of convergence.'
],['timing','explanation_results'],['shap'],'analyses/shap/manifest.json; ranking_stability.csv; signed_local_explanations.csv; *_feature_spearman.csv; small_cohort_permutation_repeat_check.csv; Figs. 4–6')

add('R1.10',[
 'Repeated planner-record timing has been replaced by direct measurements on unique held-out query keys within each split. Raw-map feature extraction, vector construction, probability inference and decision logic are timed three times per query/model; map parsing/global preparation is timed separately. The primary and exploratory comparator stages contain 42,600 query/model/repetition measurements. Cached and cold-feature costs are distinguished, models are already loaded and operating-system caches are not flushed.',
 'The measured selection medians are added to the corresponding benchmark-search medians, and runtime utility is charged under the original normalization. This reconstructed total is not described as a live sensor-to-actuator measurement. The fixed reference times search only, whereas the conservative cold-feature charge includes parsing. On strict data, five-split mean cached selection costs are 17.047 ms for Extra Trees, 0.265 ms for Logistic Regression and 0.641 ms for Gradient Boosting. The primary Extra Trees charged utility falls below fixed JPS, which materially changes the practical conclusion.',
 'S1 supplies corrected code, maps with attribution, retained queries, complete per-run paths/results, split lists, predictions, derived tables, timing records, explanations, dependency versions and reproducibility commands. Fitted binary models are omitted from the compact archive; exact fitting code, configurations, seeds, predictions and recorded model hashes are provided. No public repository has been released, so the availability statement supplies the reviewable archive and does not invent a public URL. A public repository deposit remains an additional dissemination step rather than a completed action.'
],['timing','overhead_results','limitations'],['overhead'],'analyses/{selection_timing,comparator_timing}/raw_timing.csv; records/; manifest.json; Supplementary Material S1 README')

add('R1.11',[
 'The primary experiment now uses strict no-corner-cutting geometry and an externally enforced 10 s search budget. Relaxed diagonal movement is retained as a separate sensitivity analysis. Both use the identical 1,405 tasks, six planners and three repetitions, with a shuffled planner order. Orthogonal cost is 1, diagonal cost √2 and any-angle length is the Euclidean length of validated cell-centre segments. Strict and relaxed line-of-sight contact conventions are specified separately.',
 'The corrected planners passed 14,748 small-grid/randomized searches and 11,988 independent visibility checks before full execution. Full independent auditing verifies paths and discrete reference distances; failures, timeouts and no-path outcomes remain distinct. The broad conclusion is similar under both rules: nonzero regret, preference-sensitive labels and decision costs that can remove planning-only utility gains. Numerical planner/model rankings are not assumed invariant to collision geometry. These finite implementation checks do not amount to a proof of every algorithmic property or finite-robot feasibility.'
],['geometry','validation','integrity_results','limitations'],['integrity','models','overhead'],'validation/; results/pilot_v2/; results/full_v2/audit.json; analyses/{strict,relaxed}/')

add('R1.12',[
 'The limitations and conclusion now restrict every claim to static, fully observed two-dimensional grids with point agents. The discussion explains that robot dimensions, swept volume, orientation, curvature and dynamics require footprint inflation/configuration-space collision checking and a motion-feasibility layer. Dynamic obstacles and localization/map uncertainty require sensing, estimation, safety margins, replanning and control, followed by rebenchmarking of the portfolio and labels.',
 'The external 10 s budget is an experimental computational cap, not a real-time robot deadline. No physical robot trial, sensor-derived deployment validation, closed-loop execution result or safety guarantee is claimed. The paper presents a computational benchmark assessment and identifies deployment validation as unperformed work rather than implying that the new analyses supply it.'
],['geometry','limitations','conclusion'],[],'Revised abstract; Sections 6 and 7')

add('R2.1',[
 'The revised manuscript explicitly states that there is no new fundamental path-planning or selection-learning mechanism. Extra Trees, probability thresholds, calibration, SHAP and instance-based portfolio selection are established. Claims of methodological novelty have been replaced by a bounded empirical contribution: an independently validated six-planner benchmark, task-aligned failure-aware utility, controlled collision/budget experiments, fair held-out-map comparisons, direct decision-cost measurement and reproducible explanation checks.',
 'The additional classifiers, balanced-learning variants, utility regression, fixed baselines and feature ablations test the integration’s effects. Their negative and mixed findings are retained. Sections 2.4 and 5.1 place the work relative to Rice, algorithm-selection surveys and ASlib, and the abstract/conclusion use the same scope. This addresses the concern by correcting the contribution claim rather than asserting an unachieved fundamental advance.'
],['novelty','models','benefit','conclusion'],['models','planning'],'See also response R1.1 and Supplementary Material S1 comparative outputs')

add('R2.2',[
 'The expanded experiments identify a cost–quality trade-off, not consistent overall superiority. Relative to training-selected JPS on strict seed 42, the primary Extra Trees policy shortens routes by 2.4182 cell widths on 338 paired-success tasks (95% map interval −3.3216 to −1.5998), but adds 126.8666 ms of search time (27.7745 to 246.9107). Its planning-only utility gain is 0.0126 with an interval including zero, and its success frequency is slightly lower. Cached Extra Trees overhead changes the utility difference to −0.0671 (−0.0930 to −0.0412). These results cannot justify the former efficiency claim.',
 'An explicitly exploratory comparison times the already fitted cheaper Logistic Regression and Gradient Boosting models. Cached Gradient Boosting on Street maps has positive utility-difference point estimates on all five partitions under both rules: strict 0.0192–0.0398 and relaxed 0.0186–0.0441. Several family intervals include zero; this is a candidate operating condition, not a confirmatory subgroup-superiority result. Primary overall cached utility intervals for the cheaper models also include zero. Practical benefit therefore depends on path preference, feature caching, selector cost and task distribution. The revised discussion and conclusion make those conditions and limits explicit.'
],['planning_results','family_results','overhead_results','benefit'],['paired','families','overhead'],'analyses/additional_statistics/charged_family_comparisons.csv; analyses/comparator_timing/paired_charged_comparisons.csv')

add('R2.3',[
 'Task-level verification confirmed that the historical practical table was invalid. The runner interpreted the five-field result dictionary as a path and generated invalid path lengths/success fields; the planner implementations also needed correction. The table and its oracle-equivalence interpretation are withdrawn. Every revised result is regenerated from corrected paths and complete map/start/goal keys.',
 'On the primary strict split, Extra Trees accuracy is 0.7324 on 340 label-valid test tasks. Planning evaluation retains all 355 tasks, including all-failure tasks. Extra Trees utility/regret are 0.7279/0.0360, compared with 0.7639/0 for the virtual-best oracle. The primary relaxed regret is 0.0405. Utility regret and class error measure different quantities, but neither justifies zero regret here. S1 contains all task-level predictions and policy outcomes, the 50,580-record audit and independent reference distances. Response R1.3 gives the full correction and validation details.'
],['validation','utility','integrity_results','planning_results'],['integrity','planning','paired'],'results/full_v2/audit.json; audited_runs.csv; analyses/*/seed_*/*_test_predictions.csv and *_outcomes.csv')

add('R2.4',[
 'All six classifier configurations now use exactly the same five map-disjoint partitions, input features, label-validity rules and collision-policy task keys: Logistic Regression, Random Forest, Extra Trees, Gradient Boosting and balanced Random Forest/Extra Trees. Multi-output utility regression is evaluated on those same partitions. Every partition contains 210 training maps/1,050 tasks and 71 test maps/355 tasks before classification-only all-failure exclusions.',
 'The comparison reports per-split and mean accuracy/F1, support, confusion matrices, Brier/ECE and paired whole-map classifier-difference intervals. Fixed-planner and policy outcomes use the same held-out tasks. No model is tuned or promoted using test performance; Extra Trees remains the prespecified primary method. Since no model dominates all metrics, the revised manuscript does not claim Extra Trees superiority merely from a random-split comparison.'
],['models','model_results'],['config','models','class_report'],'analyses/*/seed_*/train_keys.csv, test_keys.csv, split.json and model_inputs.json; analyses/additional_statistics/paired_model_comparisons.csv')

add('R2.5',[
 'The inconsistency came from mixing distinct estimands in the historical table. Selective accuracy now means accuracy among accepted label-valid tasks only; whole-policy accuracy means accuracy after fixed fallback has been applied to rejected tasks. The revised Table 10 and Fig. 2 are generated from the same retained-case calculation and report accepted counts and coverage.',
 'For strict seed 42, increasing τ from 0.5 to 0.9 changes selective accuracy from 0.8060 (268/340 accepted) to 0.9844 (64/340 accepted). For relaxed checking it changes from 0.7753 (227/341) to 0.9844 (64/341). Small local reversals remain and are not hidden. In contrast, forcing many low-confidence decisions to Weighted A* can reduce whole-policy accuracy and utility. Separate calibration and charged planning results are supplied, and the paper no longer interprets confidence filtering or fallback as an automatic reliability guarantee.'
],['confidence','fallback_results'],['confidence','calibration'],'analyses/*/seed_*/selective_risk_coverage.csv; fixed_fallback_whole_policy.csv; Fig. 2; see response R1.6')

add('R2.6',[
 'The default success/runtime/path weights are now identified as an explicit runtime-oriented preference rather than empirically validated universal constants. A 45-setting sensitivity study for each collision rule holds seed-42 test maps fixed, recomputes labels and refits only on training maps. It compares retaining the default model with refitting for each preference.',
 'The labels are not invariant: minimum agreement with the default is 0.3476 under strict and 0.3082 under relaxed checking. Default-model regret reaches 0.4612 and 0.4906, respectively; refitted-model regret remains at most 0.0452 and 0.0502 over the evaluated grid. The manuscript reports these changes and limits robustness claims to the preferences actually tested. The application must declare its objective; changing that objective can require retraining. Full setting-level data and intervals accompany S1.'
],['utility','weight_results'],['weights'],'analyses/{strict,relaxed}/weight_sensitivity.csv; Fig. 3; see response R1.5')

add('R2.7',[
 'The corrected fixed fallback is evaluated as an executed planning policy, not only by classification scores. On strict seed 42 at τ = 0.5, fallback changes search runtime from 208.91 to 145.20 ms, conditional path mean from 584.68 to 588.06, success frequency from 0.9521 to 0.9549 and utility from 0.7279 to 0.7248. Its whole-policy accuracy/F1 are 0.6676/0.2718, compared with 0.7324/0.2493 without fallback. Thus the classification trade-off remains, and the runtime improvement comes with worse utility and longer conditional routes.',
 'Against fixed JPS, fallback still adds 63.1573 ms on the primary strict split (95% map interval 6.0442 to 143.1452); its paired-success path difference is −0.5316 (−1.3568 to 0.2610) and utility difference is 0.0094 (−0.0036 to 0.0238). Thresholds, relaxed-rule results, proper-training raw/calibrated fallback and overhead charges are supplied separately. These data do not demonstrate universal fallback benefit, and the revised claim has been limited accordingly. The previously adaptive rule is not represented as fixed Weighted A*.'
],['confidence','fallback_results','planning_results','overhead_results'],['planning','paired','confidence'],'analyses/*/fixed_fallback_whole_policy.csv; paired_cluster_comparisons.csv; analyses/selection_timing/*Fallback* outcomes')

add('R2.8',[
 'The revision adds strict no-corner-cutting evaluation, independently checked any-angle collision geometry and an externally enforced 10 s computational budget, while retaining relaxed geometry as sensitivity analysis. These address collision/budget fairness within the computational experiment. They do not establish practical robot deployment.',
 'Section 6 now explicitly discusses finite footprint/swept volume, motion constraints, dynamic obstacles, uncertain localization and maps, safety margins, sensing/control and replanning. The current routes are point-agent geometric paths on static grids; a finite robot requires a different feasibility layer and new portfolio measurements/labels. The budget is not a real-time control deadline. The abstract and conclusion withdraw robot-readiness, general safety and universal efficiency implications. No physical, closed-loop or sensor-derived validation is claimed; this limitation remains openly stated.'
],['geometry','validation','limitations','conclusion'],['integrity'],'Revised abstract and Section 6; see response R1.12')

assert set(R)==set(COMMENTS) and len(R)==20
doc=Document();sec=doc.sections[0];sec.top_margin=sec.bottom_margin=Inches(.8);sec.left_margin=sec.right_margin=Inches(.85)
normal=doc.styles['Normal'];normal.font.name='Times New Roman';normal.font.size=Pt(11)
normal.paragraph_format.line_spacing=1.08;normal.paragraph_format.space_after=Pt(7)
for name in ['Title','Heading 1','Heading 2','Heading 3']:
 doc.styles[name].font.name='Times New Roman';doc.styles[name].font.color.rgb=RGBColor(0,0,0)
for e in list(doc.styles.element.iter(qn('w:pBdr'))):e.getparent().remove(e)
doc.add_heading('Response to the Editor and Reviewers',0)
doc.add_paragraph('International Journal of Intelligent Robotics and Applications')
doc.add_paragraph('Submission ID: 3933358d-d510-46b8-9e47-d695a348c281')
doc.add_paragraph('Manuscript: Explainable Per-Instance Algorithm Selection for Grid-Based Robot Path Planning Under Map-Disjoint Evaluation')
doc.add_paragraph('Dear Editor and Reviewers,')
doc.add_paragraph('Thank you for the detailed assessment. The revision includes a complete correction and regeneration of the computational evidence after substantive implementation errors were found. The historical constant-length and zero-regret results are withdrawn. The revised manuscript presents the corrected benchmark, additional comparative analyses and narrower conclusions, including results that do not support the original superiority claims. Each comment is reproduced below, followed by the response, verified manuscript locations and supporting files in Supplementary Material S1.')
doc.add_paragraph('Page references refer to the accompanying rendered revised manuscript; section and table numbers also identify the changes independently of pagination. S1 evidence paths are relative to revision_work/project/ unless otherwise stated.')
for reviewer,count in [(1,12),(2,8)]:
 if reviewer==2:doc.add_page_break()
 doc.add_heading(f'Reviewer {reviewer}',1)
 for index in range(1,count+1):
  key=f'R{reviewer}.{index}';item=R[key];doc.add_heading(f'Comment {reviewer}.{index}',2)
  for part in COMMENTS[key].split('\n\n'):
   p=doc.add_paragraph();p.paragraph_format.left_indent=Inches(.18)
   p.paragraph_format.keep_with_next=True
   r=p.add_run(part);r.italic=True
  p=doc.add_paragraph();p.add_run('Response. ').bold=True
  p.add_run(item['paragraphs'][0])
  for text in item['paragraphs'][1:]:doc.add_paragraph(text)
  locations=[f"Section {LOC['sections'][k].split()[0]} (p. {PAGE['sections'][k]})" for k in item['sections']]
  locations += [f"Table {LOC['tables'][k]} (p. {PAGE['tables'][k]})" for k in item['tables']]
  if locations:
   p=doc.add_paragraph();p.add_run('Changes in manuscript. ').bold=True;p.add_run('; '.join(locations)+'.')
  p=doc.add_paragraph();p.add_run('Supporting evidence. ').bold=True;p.add_run(item['evidence']+'.')
  for r in p.runs:r.font.size=Pt(9)
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
doc.save(OUT/'Response_to_Reviewers.docx')
(OUT/'response_content.json').write_text(json.dumps(R,indent=2,ensure_ascii=False))
(OUT/'response_validation.json').write_text(json.dumps({'comments':20,'responses':20,'all_comment_keys_match':True,'manuscript_pdf_sha256':hashlib.sha256(PDF.read_bytes()).hexdigest(),'page_references_verified_from_pdf':True},indent=2))
print('Created 20-point response and verified manuscript page locations')
