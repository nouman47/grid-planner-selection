"""Check displayed table numbers independently against saved task-level evidence."""
import sys,json,re,hashlib
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.metrics import classification_report
from docx import Document
ROOT=Path(__file__).parent;P=ROOT/'project';O=ROOT/'submission_revision'
sys.path.insert(0,str(P))
from analysis_core import KEYS,PLANNERS,cluster_interval
doc=Document(O/'Revised_Manuscript.docx');T=[[[c.text for c in r.cells] for r in t.rows] for t in doc.tables]
checks=[]
def cell(t,r,c,x,places=4):
    actual=T[t-1][r][c]
    if isinstance(x,(list,tuple,np.ndarray)):
        found=[float(v) for v in re.findall(r'(?<!\w)[−-]?\d+(?:\.\d+)?',actual.replace('−','-'))]
        assert len(found)==len(x),(t,r,c,actual,x)
        assert np.allclose(found,x,rtol=0,atol=.501*10**(-places)),(t,r,c,found,x)
    else:assert abs(float(actual)-float(x))<=.501*10**(-places),(t,r,c,actual,x)
    checks.append([t,r,c])
def csv(policy,name):return pd.read_csv(P/'analyses'/policy/(name+'.csv'))
features=pd.read_csv(P/'data/features_strict.csv')
for r,family in enumerate(['dao','maze','street'],1):
    g=features[features.family==family];cell(1,r,1,g['map'].nunique(),0);cell(1,r,2,len(g),0)
cell(1,4,1,features['map'].nunique(),0);cell(1,4,2,len(features),0)
# Table 2 is a configuration table; check executable settings separately below.
runs=pd.read_csv(P/'results/full_v2/audited_runs.csv')
for r,policy in enumerate(['relaxed','strict'],1):
    g=runs[runs.policy==policy]
    for c,status in enumerate(['solved','no_path','timeout'],1):cell(3,r,c,(g.status==status).sum(),0)
    d=g.loc[g.success,'path_length'];cell(3,r,4,[d.min(),d.max()],2)
for j,policy in enumerate(['strict','relaxed']):
    labels=csv(policy,'task_labels')
    for c,partition in enumerate(['all','train','test']):
        frame=labels if partition=='all' else pd.read_csv(P/f'analyses/{policy}/seed_42/{partition}_keys.csv').merge(labels,on=KEYS,validate='one_to_one')
        for r,planner in enumerate(PLANNERS,1):cell(4,r,1+j*3+c,(frame.best_planner==planner).sum(),0)
        cell(4,7,1+j*3+c,frame.best_planner.isna().sum(),0)
models=['LogisticRegression','RandomForest','ExtraTrees','GradientBoosting','ExtraTreesBalanced','RandomForestBalanced','UtilityRegression']
for r,model in enumerate(models,1):
    for j,policy in enumerate(['strict','relaxed']):
        d=csv(policy,'model_comparison');d=d[d.model==model]
        for c,metric in enumerate(['accuracy','macro_f1']):cell(5,r,1+j*2+c,[d[metric].mean(),d[metric].std(ddof=1)])
for j,policy in enumerate(['strict','relaxed']):
    d=pd.read_csv(P/f'analyses/{policy}/seed_42/ExtraTrees_test_predictions.csv');d=d[d.label_valid]
    report=classification_report(d.best_planner,d.predicted_planner,labels=PLANNERS,zero_division=0,output_dict=True)
    for r,planner in enumerate(PLANNERS,1):
        for c,metric in enumerate(['support','precision','recall','f1-score']):cell(6,r,1+j*4+c,report[planner][metric],0 if c==0 else 3)
methods=['Fixed_'+x for x in PLANNERS]+['ExtraTrees','LogisticRegression','GradientBoosting','UtilityRegression','FixedWeightedFallback_0.5','TrainingSingleBest','TrainingMajority','UniformRandomExpected','VirtualBest']
oracle=pd.read_csv(P/'analyses/strict/seed_42/VirtualBest_outcomes.csv')
for r,method in enumerate(methods,1):
    d=pd.read_csv(P/f'analyses/strict/seed_42/{method}_outcomes.csv');assert d[KEYS].equals(oracle[KEYS])
    mask=d.path_length.notna()&(d.success_rate>0)
    vals=[d.success_rate.mean(),d.runtime_ms.mean(),np.average(d.loc[mask,'path_length'],weights=d.loc[mask,'success_rate']),d.utility.mean(),(oracle.utility-d.utility).mean()]
    for c,v in enumerate(vals,1):cell(7,r,c,v,2 if c in [2,3] else 4)
row=0
for policy in ['strict','relaxed']:
    base=pd.read_csv(P/f'analyses/{policy}/seed_42/TrainingSingleBest_outcomes.csv')
    for method in ['ExtraTrees','FixedWeightedFallback_0.5']:
        d=pd.read_csv(P/f'analyses/{policy}/seed_42/{method}_outcomes.csv');assert d[KEYS].equals(base[KEYS])
        for metric in ['runtime_ms','path_length','utility','success_rate']:
            row+=1;diff=d[metric]-base[metric]
            if metric=='path_length':diff=diff.where((d.success_rate>0)&(base.success_rate>0))
            point,low,high=cluster_interval(diff,d['map'],1000,42);cell(8,row,3,diff.notna().sum(),0);cell(8,row,4,[point,low,high])
charged=pd.read_csv(P/'analyses/additional_statistics/charged_family_comparisons.csv');row=0
for policy in ['strict','relaxed']:
    for family in ['dao','maze','street']:
        row+=1;d=pd.read_csv(P/f'analyses/{policy}/seed_42/ExtraTrees_outcomes.csv');d=d[d.family==family]
        b=pd.read_csv(P/f'analyses/{policy}/seed_42/TrainingSingleBest_outcomes.csv');b=b[b.family==family]
        cell(9,row,2,[d['map'].nunique(),len(d)],0);cell(9,row,3,d.utility.mean());cell(9,row,4,b.utility.mean())
        c=charged[(charged.policy==policy)&(charged.seed==42)&(charged.method=='ExtraTrees')&(charged.scope=='cached')&(charged.family==family)&(charged.metric=='utility')].iloc[0];cell(9,row,5,[c.difference,c.ci_low,c.ci_high])
row=0
for policy in ['strict','relaxed']:
    pred=pd.read_csv(P/f'analyses/{policy}/seed_42/ExtraTrees_test_predictions.csv',float_precision='round_trip');d=pred[pred.label_valid]
    for threshold in [.5,.6,.7,.8,.9]:
        row+=1;accepted=d.confidence>=threshold;acc=(d.loc[accepted,'predicted_planner']==d.loc[accepted,'best_planner']).mean()
        cell(10,row,1,threshold,1);cell(10,row,2,[accepted.sum(),len(d)],0);cell(10,row,3,accepted.mean());cell(10,row,4,acc)
        outcome=pd.read_csv(P/f'analyses/{policy}/seed_42/FixedWeightedFallback_{threshold}_outcomes.csv')
        joined=d[KEYS+['best_planner']].merge(outcome[KEYS+['planner']],on=KEYS,validate='one_to_one')
        cell(10,row,5,(joined.best_planner==joined.planner).mean());cell(10,row,6,outcome.utility.mean())
row=0
for policy in ['strict','relaxed']:
    for method in ['ProperTrainRaw','ProperTrainTemperature']:
        row+=1;d=csv(policy,'temperature_calibration');d=d[d.method==method]
        for c,metric in enumerate(['ece','brier','accuracy'],2):cell(11,row,c,[d[metric].mean(),d[metric].std(ddof=1)])
for row,policy in enumerate(['strict','relaxed'],1):
    d=csv(policy,'weight_sensitivity');cell(12,row,1,[d.valid_label_agreement_with_default.min(),d.valid_label_agreement_with_default.max()],3)
    for c,col in enumerate(['default_model_mean_regret','retrained_mean_regret'],2):cell(12,row,c,[d[col].min(),d[col].max()])
timing=pd.concat([pd.read_csv(P/f'analyses/{s}/charged_policy_summary.csv') for s in ['selection_timing','comparator_timing']]);row=0
for policy in ['strict','relaxed']:
    for method in ['ExtraTrees','LogisticRegression','GradientBoosting']:
        row+=1;d=timing[(timing.policy==policy)&(timing.method==method)]
        for scope,c in [('cached',2),('cold',3)]:cell(13,row,c,d.loc[d.scope==scope,'mean_selection_ms'].mean(),3);cell(13,row,c+2,d.loc[d.scope==scope,'mean_utility'].mean())
stability=pd.read_csv(P/'analyses/shap/ranking_stability.csv');repeat=pd.read_csv(P/'analyses/shap/small_cohort_permutation_repeat_check.csv')
for row,policy in enumerate(['strict','relaxed'],1):
    d=stability[stability.policy==policy];r=repeat[repeat.policy==policy]
    for c,v in enumerate([d.spearman_rho,d.top5_jaccard,r.rank_spearman],1):cell(14,row,c,[v.min(),v.max()],3)
# Verify complete exact reviewer quotation coverage and one answer for every source item.
response=Document(O/'Response_to_Reviewers.docx');texts=[p.text for p in response.paragraphs];comments=json.loads((O/'reviewer_comments.json').read_text());content=json.loads((O/'response_content.json').read_text())
assert len(comments)==len(content)==20
for key,comment in comments.items():
    for paragraph in comment.split('\n\n'):assert texts.count(paragraph)==1,(key,paragraph)
    assert all(p in texts or 'Response. '+p in texts for p in content[key]['paragraphs'])
body='\n'.join(p.text for p in doc.paragraphs);parts=body.split('References\n');assert len(parts)==2
refs=[int(x) for x in re.findall(r'^(\d+)\. ',parts[1],re.M)];assert refs==list(range(1,43))
cited=set()
for group in re.findall(r'\[([\d, –-]+)\]',parts[0]):
    if group=='0,1':continue # Utility clipping interval, not a reference citation.
    for item in group.split(','):
        vals=[int(v) for v in re.findall(r'\d+',item)]
        cited.update(range(vals[0],vals[-1]+1))
assert cited==set(refs),(cited,set(refs))
config=(P/'evaluate_models.py').read_text();assert 'n_estimators=500' in config and 'max_iter=5000' in config
report={'passed':True,'displayed_numeric_cells_checked':len(checks),'tables_checked':sorted(set(x[0] for x in checks)),'table_2':'configuration text checked against fitting source','all_20_source_comments_quoted_once':True,'all_20_responses_present':True,'numbered_references':42,'all_references_cited':True,'document_sha256':{n:hashlib.sha256((O/n).read_bytes()).hexdigest() for n in ['Revised_Manuscript.docx','Response_to_Reviewers.docx']}}
(O/'submission_validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
