"""Publication figures from verified, task-keyed analysis files."""
from pathlib import Path
import json
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).parent;P=ROOT/'project/analyses';OUT=ROOT/'submission_revision/figures';OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':240})
NAMES={'LogisticRegression':'Logistic regression','RandomForest':'Random forest','ExtraTrees':'Extra Trees','GradientBoosting':'Gradient boosting','ExtraTreesBalanced':'Balanced Extra Trees','RandomForestBalanced':'Balanced random forest','UtilityRegression':'Utility regression'}
def friendly(name):return 'mean orthogonal free degree' if name=='mean_free_degree4' else name.replace('_',' ')
def save(fig,name):fig.tight_layout();fig.savefig(OUT/(name+'.png'),bbox_inches='tight');fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight');plt.close(fig)

def main():
 fig,axes=plt.subplots(1,2,figsize=(9,4.2),sharey=True)
 for ax,policy in zip(axes,['strict','relaxed']):
  d=pd.read_csv(P/policy/'model_comparison.csv');names=list(NAMES);y=np.arange(len(names))
  for delta,col,color,label in [(-.13,'accuracy','#24587A','Accuracy'),(.13,'macro_f1','#B7692C','Six-class macro-F1')]:
   g=d.groupby('model')[col];m=g.mean().reindex(names);s=g.std().reindex(names)
   ax.errorbar(m,y+delta,xerr=s,fmt='o',capsize=2,color=color,label=label,markersize=4)
  ax.set_yticks(y,[NAMES[n] for n in names]);ax.invert_yaxis();ax.set_xlim(0,1);ax.set_title(policy.title()+' collision rule');ax.set_xlabel('Five-split mean ± sample SD');ax.grid(axis='x',alpha=.2)
 axes[0].legend(loc='lower right',fontsize=8);save(fig,'model_comparison')
 fig,axes=plt.subplots(2,2,figsize=(8,6.5))
 for row,policy in enumerate(['strict','relaxed']):
  d=pd.read_csv(P/policy/'seed_42/ExtraTrees_test_predictions.csv');d=d[d.label_valid];conf=d.confidence.to_numpy();correct=(d.predicted_planner==d.best_planner).to_numpy()
  x=[];y=[];n=[]
  for i in range(10):
   mask=(conf>=i/10)&((conf< (i+1)/10) if i<9 else (conf<=1))
   if mask.any():x.append(conf[mask].mean());y.append(correct[mask].mean());n.append(mask.sum())
  a=axes[row,0];a.plot([0,1],[0,1],color='gray',ls='--');a.scatter(x,y,s=np.array(n)*1.3+15,color='#24587A');a.set(xlim=(0,1),ylim=(-.02,1.05),xlabel='Mean confidence in bin',ylabel='Observed accuracy',title=policy.title()+' reliability')
  curve=pd.read_csv(P/policy/'seed_42/selective_risk_coverage.csv').dropna();a=axes[row,1];a.plot(curve.coverage,curve.risk,'o-',color='#B7692C',markersize=3);a.set(xlim=(0,1),ylim=(0,1),xlabel='Coverage of label-valid test tasks',ylabel='Selective error rate',title=policy.title()+' risk and coverage')
 save(fig,'confidence')
 fig,axes=plt.subplots(1,2,figsize=(8,3.5))
 for ax,policy in zip(axes,['strict','relaxed']):
  d=pd.read_csv(P/policy/'weight_sensitivity.csv');values=np.full((5,11),np.nan)
  for r in d.itertuples():values[round(r.w_success*10),round(r.w_runtime*10)]=r.default_model_mean_regret
  im=ax.imshow(values,origin='lower',aspect='auto',vmin=0,vmax=.5,cmap='viridis');ax.set_xticks(range(0,11,2),[f'{x/10:.1f}' for x in range(0,11,2)]);ax.set_yticks(range(5),[f'{x/10:.1f}' for x in range(5)]);ax.set(xlabel='Runtime weight',ylabel='Success weight',title=policy.title()+' default-model regret')
 fig.subplots_adjust(wspace=.45,right=.82,bottom=.2);cax=fig.add_axes([.88,.22,.025,.62]);fig.colorbar(im,cax=cax,label='Mean utility regret');fig.savefig(OUT/'weight_sensitivity.png',bbox_inches='tight');fig.savefig(OUT/'weight_sensitivity.pdf',bbox_inches='tight');plt.close(fig)
 rankings=pd.read_csv(P/'shap/feature_rankings.csv');fig,axes=plt.subplots(1,2,figsize=(9,4.5))
 for ax,policy in zip(axes,['strict','relaxed']):
  d=rankings[rankings.policy==policy];g=d.groupby('feature').mean_absolute_shap;mean=g.mean().nlargest(10).sort_values();sd=g.std().reindex(mean.index)
  ax.barh([friendly(n) for n in mean.index],mean,xerr=sd,color='#24587A',capsize=2);ax.set(title=policy.title()+' SHAP importance',xlabel='Mean absolute attribution ± split SD')
 save(fig,'shap_global')
 local=pd.read_csv(P/'shap/signed_local_explanations.csv');sample=pd.read_csv(P/'shap/strict_42_explanation_keys.csv').sort_values(['map','start_x','start_y','goal_x','goal_y']).drop_duplicates('family')
 fig,axes=plt.subplots(3,1,figsize=(8,8.5))
 for ax,task in zip(axes,sample.to_dict('records')):
  g=local[(local.policy=='strict')&(local.seed==42)]
  for key in ['map','start_x','start_y','goal_x','goal_y']:g=g[g[key]==task[key]]
  winning=g.groupby('planner').predicted_probability.first().idxmax();g=g[g.planner==winning].copy();order=g.shap.abs().nlargest(6).index;top=g.loc[order,['feature','shap']].copy();other=g.drop(order).shap.sum();top.loc[len(top.index)+1000]=['remaining features',other];top=top.sort_values('shap')
  ax.barh([friendly(n) for n in top.feature],top.shap,color=['#B7692C' if x<0 else '#24587A' for x in top.shap]);ax.axvline(0,color='gray',lw=.7)
  base=g.base_probability.iloc[0];pred=g.predicted_probability.iloc[0]
  winning_name={'theta_star':'Theta*','jps':'JPS','weighted_astar':'Weighted A*','astar':'A*','bidirectional_astar':'Bidirectional A*','dijkstra':'Dijkstra'}[winning]
  ax.set_title(f"{task['family'].upper()}  {task['map']}  {winning_name}\nBase {base:.3f} + contributions = predicted probability {pred:.3f}",fontsize=9);ax.set_xlabel('Signed probability contribution')
 save(fig,'shap_local')
 fig,axes=plt.subplots(1,2,figsize=(9,4))
 for ax,policy in zip(axes,['strict','relaxed']):
  d=pd.read_csv(P/policy/'ablations.csv');order=['navigation','navigation_environment','full','without_free_space','without_obstacle_density','without_both_occupancy'];y=np.arange(len(order))
  for delta,col,color in [(-.12,'accuracy','#24587A'),(.12,'macro_f1','#B7692C')]:
   g=d.groupby('configuration')[col];ax.errorbar(g.mean().reindex(order),y+delta,xerr=g.std().reindex(order),fmt='o',capsize=2,color=color,label=col.replace('_',' '))
  ax.set_yticks(y,[n.replace('_',' ') for n in order]);ax.invert_yaxis();ax.set(xlim=(0,1),xlabel='Five-split mean ± sample SD',title=policy.title()+' feature ablations')
 axes[0].legend(fontsize=8);save(fig,'ablations')
 print('Six publication figure sets generated')

if __name__=='__main__':main()
