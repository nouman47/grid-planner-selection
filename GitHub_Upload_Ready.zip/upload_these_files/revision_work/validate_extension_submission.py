"""Preserve all original table checks and independently check new displayed data."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
source=(ROOT/'validate_submission.py').read_text()
source=source.replace('range(1,43)','range(1,46)').replace("'numbered_references':42","'numbered_references':45")
extra=r'''
E=P/'extensions_v2/results'
# Table 15: replay actual runtime charging from original per-task utility data.
row=0
for policy in ['strict','relaxed']:
    u=pd.read_csv(P/f'analyses/{policy}/planner_utilities.csv')
    for method in ['CheapUtility','GuardedCheapUtility']:
        row+=1;costs=[];switches=[];diffs=[]
        for seed in [42,52,62,72,82]:
            decisions=pd.read_csv(E/f'{policy}_{seed}_{method}_decisions.csv')
            summary=pd.read_csv(E/'cost_policy_summary.csv');b=summary[(summary.policy==policy)&(summary.seed==seed)&(summary.method==method)].iloc[0].baseline
            chosen=decisions.merge(u,on=KEYS+['planner'],validate='one_to_one')
            span=u[u.success_rate>0].groupby(KEYS).runtime_ms.agg(lambda x:x.max()-x.min()).rename('span').reset_index()
            chosen=chosen.merge(span,on=KEYS,how='left',validate='one_to_one').fillna({'span':0})
            cost=chosen.selection_ms.to_numpy();rt=chosen.runtime_score.to_numpy();s=chosen.span.to_numpy()
            penalty=.5*np.minimum(cost/np.maximum(s,1e-30),rt)
            charged=chosen.utility.to_numpy()-penalty
            fixed=decisions[KEYS].merge(u[u.planner==b][KEYS+['utility']],on=KEYS,validate='one_to_one').utility.to_numpy()
            costs.append(cost.mean());switches.append((chosen.planner!=b).mean());diffs.append((charged-fixed).mean())
        cell(15,row,2,np.mean(costs),3);cell(15,row,3,np.mean(switches));cell(15,row,4,np.mean(diffs))
        coverage=pd.read_csv(E/'map_coverage.csv');g=coverage[coverage.policy==policy];cell(15,row,5,[g.map_coverage.min(),g.map_coverage.max()],3)
# Table 16: derive task medians again from all raw immutable transactions.
raw=pd.DataFrame([json.loads(p.read_text()) for p in sorted((E/'pipeline/records').glob('*.json'))])
names={'Fixed JPS':'FixedJPS','Original ET':'OriginalExtraTrees','Cheap utility':'CheapUtility','Guarded':'GuardedCheapUtility'}
for row,shown in enumerate(T[15][1:],1):
    policy,scope=shown[0].lower(),shown[1].lower();method=names[shown[2]]
    cohort=raw[(raw.policy==policy)&(raw.scope==scope)];g=cohort[cohort.method==method];base=cohort[cohort.method=='FixedJPS']
    assert len(g)==len(base)==213
    grouped=g.groupby(KEYS,sort=True);timed=grouped.parent_wall_ms.median();bt=base.groupby(KEYS,sort=True).parent_wall_ms.median();success=grouped.success.mean()
    length=g[g.success].groupby(KEYS,sort=True).path_length.median().dropna();weight=success.reindex(length.index)
    point,low,high=cluster_interval(timed.to_numpy()-bt.to_numpy(),[k[0] for k in timed.index],1000,42)
    cell(16,row,3,success.mean());cell(16,row,4,timed.mean(),2);cell(16,row,5,[point,low,high],2);cell(16,row,6,np.average(length,weights=weight),2)
# Table 17: count events from final episode-level evidence, not rounded summary rates.
episodes=pd.read_csv(E/'robot_simulation/episodes.csv')
for row,shown in enumerate(T[16][1:],1):
    method=names[shown[0]];condition=shown[1].replace(' ','_');g=episodes[(episodes.method==method)&(episodes.condition==condition)]
    assert len(g)==71
    eligible=g[g.status!='invalid_inflated_endpoint']
    cell(17,row,2,[g.goal_reached.sum(),len(g)],0);cell(17,row,3,[eligible.goal_reached.sum(),len(eligible)],0)
    cell(17,row,4,g.collision.sum(),0);cell(17,row,5,(g.status=='invalid_inflated_endpoint').sum(),0);cell(17,row,6,g.status.str.startswith('planning_').sum(),0)
budget=pd.read_csv(E/'pipeline/budget_portability.csv');assert budget.transactions.sum()==852 and (budget.budget_exceedance_rate==1).all()
assert 'all 852 guarded transactions' in body and len(doc.tables)==17
'''
source=source.replace('report={',extra+'\nreport={')
exec(compile(source,str(ROOT/'validate_submission.py'),'exec'),{'__file__':str(ROOT/'validate_submission.py'),'__name__':'__main__'})
